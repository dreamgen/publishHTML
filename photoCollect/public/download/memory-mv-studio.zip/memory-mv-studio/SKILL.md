---
name: memory-mv-studio
description: 用活動照片＋一首歌自動製作「照片回憶 MV」（歌詞字幕對齊、依歌曲段落分配照片、人臉運鏡、輸出 MP4），含活動前籌備與手機即時收照片。當使用者說「做回憶 MV」「活動回顧影片」「照片配歌做影片」「營隊／畢業／家庭日 MV」「幫我把照片做成 MV」「歌詞對齊字幕」「MV Studio」，或提供一首歌加一批活動照片時使用。
---

# 照片回憶 MV 製作（MV Studio 可攜版）

把「一首歌 + 一批活動照片」做成有歌詞字幕、照片依歌詞情境與拍攝時間排列、鏡頭朝人臉推進的回憶 MV。
本 Skill 內附完整程式（`app/`），可在 macOS、Windows、Linux 使用；網頁介面與指令列共用同一份專案資料。

## 0. 先決定安裝位置（每次啟用都先做）

程式與專案資料放在 `MV_HOME`（macOS／Linux 預設 `~/MVStudio`，Windows 預設 `C:\MVStudio`），**不要直接在 Skill 資料夾內執行**（Skill 更新時會覆蓋資料）。

macOS／Linux（bash）：
```bash
MV_HOME="${MV_HOME:-$HOME/MVStudio}"
SKILL_DIR="<這份 SKILL.md 所在資料夾>"
if [ ! -f "$MV_HOME/mvctl.py" ]; then
  mkdir -p "$MV_HOME" && cp -R "$SKILL_DIR/app/." "$MV_HOME/"
fi
cd "$MV_HOME" && ./setup.sh
```

Windows（PowerShell）：
```powershell
$MV_HOME = if ($env:MV_HOME) { $env:MV_HOME } else { "C:\MVStudio" }
$SKILL_DIR = "<這份 SKILL.md 所在資料夾>"
if (-not (Test-Path "$MV_HOME\mvctl.py")) {
  New-Item -ItemType Directory -Force -Path $MV_HOME | Out-Null
  Copy-Item -Path "$SKILL_DIR\app\*" -Destination $MV_HOME -Recurse -Force
}
cd $MV_HOME; .\setup.bat      # 或 powershell -NoProfile -ExecutionPolicy Bypass -File setup.ps1
```
- Windows 請**避開 OneDrive／桌面／文件**這類會同步的資料夾（照片多、venv 大，會卡住或被鎖檔）；`setup.ps1` 與 `mvctl doctor` 偵測到會警告。
- Windows 終端機若出現亂碼，先執行 `$env:PYTHONUTF8=1; [Console]::OutputEncoding=[System.Text.Encoding]::UTF8`（`setup.ps1` 已自動設定）。

- `setup.sh` 會建立 venv、安裝套件、下載繁體中文字型（`mvctl fonts`，Noto Sans TC）並執行 `mvctl.py doctor`。有 ❌ 就先解決（最常見：沒裝 FFmpeg、中文字型缺繁體字）。
- 之後所有指令都用 `cd "$MV_HOME" && ./venv/bin/python mvctl.py …`；**Windows 用 `venv\Scripts\python.exe mvctl.py …`**（例：`.\venv\Scripts\python.exe mvctl.py status <ID>`）。下文簡寫為 `mvctl`。
- 更新程式（保留專案）：`rsync -a --exclude venv --exclude mv_studio/projects "$SKILL_DIR/app/" "$MV_HOME/"`；Windows：`robocopy "$SKILL_DIR\app" $MV_HOME /E /XD venv projects`。

## 1. 判斷階段

已有專案就先跑 `mvctl status <ID>`（不知道 ID 用 `mvctl projects`），依輸出的「👉 下一步」接續，並**明確告訴使用者目前在哪個階段、為什麼**。
沒有專案則先問清楚三件事（缺一不可）：音樂檔、正確歌詞文字、照片資料夾（或「照片還沒收」→ 走階段 0）。然後：

```bash
mvctl new --name "<活動名稱>" --music <歌.mp3> --lyrics <歌詞.txt> --photos <照片資料夾>
```

## 2. 六個階段

| 階段 | 指令 | 產出 | 人工把關 |
|---|---|---|---|
| 0a 雲端收照片（選用） | `mvctl link <ID> --event <網址> --key <金鑰>` → `mvctl sync <ID>` | 活動資訊、小隊、拍攝清單；照片進 catalog | 確認環節與小隊對得上 |
| 0 活動前籌備（選用） | `mvctl event <ID> --schedule 流程表.txt --handbook 手冊.docx …` | 主題、小隊名單、拍攝清單、片頭／片尾圖、上傳 QR | 確認主題清單 |
| 1 歌詞強制對齊 | `mvctl align <ID>` | `generated.srt`、`*_校對用.mp4` | **把關點 1：看校對影片** |
| 2 主題與時槽規劃 | `mvctl themes` → `mvctl map` → `mvctl plan`（有雲端連結會自動 `push-requirements`） | `content_plan.json`、各主題照片需求表 | 確認主題對應與張數 |
| 3 照片視覺分析 | （有雲端：先 `mvctl sync <ID>`）`mvctl scan <ID> --focus` → 分析 → `mvctl import` | `photo_catalog.json` | 覆蓋率不足要提醒補照片 |
| 4 三優先排程 | `mvctl manifest <ID>` | `ordered_photos.json` | **把關點 2：人物均衡、副歌靈魂照片** |
| 5 渲染輸出 | `mvctl render <ID>` | MP4（1920×1080） | 播放抽查 |

細節規格（演算法、參數、檔案格式）見 `references/workflow.md`，只在需要時讀。

### 雲端收照片（選用）
使用者若給了**同步網址**（`https://…/api/sync/ev_…`）與**同步金鑰**，代表活動照片由參加者用手機傳到雲端，不必手動收照片。流程：
1. 建立專案後（`mvctl new …`；照片資料夾用預設即可）：`mvctl link <ID> --event "<同步網址>" --key "<同步金鑰>"`。
   - 會驗證金鑰、把活動名稱／日期／地點／主辦、流程表、小隊、拍攝清單寫進專案；專案沒有主題時以流程環節建立主題（關鍵字留空，之後視需要補）；並自動產生片頭／片尾圖。
   - 回報「同步金鑰不正確或已被主辦者重發」時，請使用者回雲端管理頁重新複製金鑰。金鑰存在 `project.json`，**不要貼到對話以外的地方或分享專案資料夾**。
2. `mvctl sync <ID>`：下載新照片進照片資料夾與 catalog（已下載的會略過；主辦者在雲端「排除」的照片會移到 `_excluded/`）。輸出會列各環節與各小隊張數，回報給使用者。
3. 活動進行中可 `mvctl sync <ID> --watch`（預設每 300 秒）持續同步，Ctrl+C 結束；也可以每隔一段時間手動重跑。
4. 階段 2 `mvctl plan` 之後，各主題需要的張數會自動回寫雲端（讓攝影師看到還缺幾張）；失敗只警告，也可手動 `mvctl push-requirements <ID>`。
5. **多日活動**：雲端流程表每天前有日期標題時，環節會是「第1天・報到」「第2天・報到」這種格式，`theme_hint` 依拍攝日期＋時間判斷；本地籌備用 `mvctl event <ID> --date 2026-11-20 --end-date 2026-11-22 --schedule 流程表.txt`，流程表每天前加一行日期（如 `11/20` 或 `Day 2`）。規劃主題時可依天分段（例如每天一段歌詞），或把各天同性質的環節對到同一個 MV 主題。
6. **輪站課程**：同一時段多個關卡同時上課、小隊輪流換關卡時，雲端的關卡（課程名稱）就是環節／MV 主題（`kind: station`），輪空時段可能歸到「自由活動」。`sync` 依「照片的小隊＋拍攝時段」查輪站表決定 `theme_hint`；判斷不了的照片（沒勾小隊）要靠視覺分析判斷是哪一關。建議 MV 為每個課程安排一段，讓每隊在每一關都有出場（manifest 的人物均衡會協助）。
7. 雲端來的照片已帶 `theme_hint`（依拍攝時間推得的環節）與小隊標籤，階段 3 的 subagent prompt 會附上作為提示，但**仍需視覺分析**才會進入排程。
8. 補收的照片：重跑 `sync` → `scan` → 分析 → `import` → `manifest` 即可增量追加。
9. 攝影師可在雲端「我上傳的照片」改小隊、環節、備註，或更換、刪除照片；重跑 `sync` 會更新 catalog（`cloud_groups`、`theme_hint`、`cloud_note`），被刪除或更換掉的舊照片會移到 `_excluded/`。之後要重跑 `scan` → 分析新照片 → `import` → `manifest`。
10. 主辦者若開了參與者相簿，`sync` 會帶回票數（`cloud_votes`，不含攝影者自選）與「MV 優先」標記（`cloud_priority`）。`manifest` 排程時 MV 優先 +3 分、每票 +0.15（最多 +1.5），讓大家選的照片優先入選；分析照片時也可把 `cloud_note` 當作情境提示。

### 階段 0：活動前籌備（照片尚未收集時）
1. 請使用者提供流程表（每行 `HH:MM-HH:MM 環節名稱`）、活動手冊／宣傳文案（.docx/.pdf/.txt 皆可）。（多日活動：每天的流程前加一行日期，如 `11/20` 或 `Day 2`，並用 `--end-date` 給最後一天）
2. `mvctl event <ID> --event-name … --date … --location … --schedule … --handbook …`
3. **務必先做階段 0 再設主題**：event 會把流程環節合併進主題清單。合併後用 `mvctl themes <ID>` 檢查，若出現意思重疊的主題（例如「闖關遊戲」與「團隊闖關」），用 `--set` 重新整理成一份，否則同類照片會被拆散到不同主題池。
4. 手機上傳：`mvctl serve --lan`（同一個 Wi-Fi；Windows 第一次會跳防火牆視窗，要按「允許」），把上傳連結／QR 給攝影師。若使用者有雲端收照片服務，改走上面「雲端收照片」。要用公網（Cloudflare Tunnel / ngrok）時加 `--public-url`。非本機連線只能使用上傳頁，管理介面不會外露。
5. 上傳的照片只帶「主題提示」，仍需經過階段 3 的視覺分析才會進入排程。

### 階段 1：歌詞強制對齊
- `mvctl align <ID>`（預設 Whisper `medium`；電腦較慢可 `--model small`，第一次會下載模型）。
- 完成後**停下來**請使用者播放 `*_校對用.mp4`（開啟字幕軌）確認。要修就直接改專案資料夾裡的 `generated.srt`，或在網頁「歌詞對齊」分頁微調。確認後才進入階段 2。
- 歌詞裡固定錯字可用 `fix_srt_with_dict.py` 批次修正。

### 階段 2：主題與時槽規劃
1. 主題：活動型 MV 依活動環節命名（6～9 個為宜）；情感型 MV 先跑 `mvctl themes <ID> --from-lyrics` 看歌詞高頻意象，再與使用者討論後 `--set "名稱=關鍵字,關鍵字|名稱=…"`。
2. `mvctl map <ID> --suggest` 自動依關鍵字指派每句歌詞的主題，**逐行列給使用者看**；關鍵字比對只算命中次數、平手取排在前面的主題，常需要用 `--assign 3=Outro 7=Game` 手動修正。
3. `mvctl plan <ID>` → 把「各主題需要幾張照片」表格回報給使用者。總長誤差應 < 0.05 秒。
4. 片頭／片尾：照片資料夾需有 `片頭.png`、`片尾.png`（1920×1080）。階段 0 會自動產生；沒有就請使用者提供或用 event 產生。

### 階段 3：照片視覺分析（Agent 模式，不需 API Key）
1. `mvctl scan <ID> --focus`：掃描新照片、產生 640px 縮圖、偵測人臉焦點，並輸出 `mv_studio/projects/<ID>/subagent_task.json`（已切好 shards 與完整 prompt）。
2. 依 shard 數量平行派出 subagent（每組 ≤15 張），把 `shards[i].prompt` 原封不動交給它；subagent 必須逐張看縮圖再評分。規則與輸出格式見 `references/photo_analysis_protocol.md`。
3. 把每個 subagent 回傳的 JSON 存成檔案，`mvctl import <ID> sub1.json sub2.json …`。
4. 若照片分批到齊，之後重跑 1～3 即可增量追加。
5. `mvctl status <ID>` 確認「已分析 = 已收錄 = 資料夾內」。某主題照片為 0 或明顯不足時，告訴使用者是哪個主題、還缺幾張，問要補照片還是接受重複使用。

（網頁介面另有 Gemini API 自動分析，需使用者自備 Key，放在環境變數 `GEMINI_API_KEY`，不要寫進專案檔。）

### 階段 4：三優先排程
- `mvctl manifest <ID> --report` 先看分配來源（FIXED / P1 / P2 / P3 / EMPTY），再 `mvctl manifest <ID>` 寫入。
- P3（重複使用）比例高或有 EMPTY 時，回報缺照片的主題並建議補拍。
- **把關點 2**：請使用者用 `mvctl serve` 開啟網頁「照片分配」分頁，看人物出場均衡儀表板與分鏡卡；要換照片用網頁拖拉或 `mvctl assign <ID> <slot_id> <檔名>`。

### 階段 5：渲染
- 渲染前先跑 `mvctl doctor`，「中文字型」必須是 ✅（繁體字檢驗通過）；不是的話先 `mvctl fonts`。
- `mvctl render <ID>`（可加 `--output 路徑`）。4 分鐘的歌在一般筆電約 5～15 分鐘；可用 `MV_RENDER_WORKERS` 調整平行數。
- `render` 開始前會檢查「所有字幕＋活動名稱」的每個字都畫得出來；有缺字會停下並列出缺哪些字。**不要**用 `--ignore-missing-glyphs` 硬跑，先照提示修好字型。
- 完成後抽查（每一項都要看）：
  - 比例 16:9、無黑邊、聲畫同步、直拍照片沒有躺著。
  - **字幕與片頭片尾沒有方框字**：特別看「啟、臺、裡、說、為、與、這、們」等繁體字。
  - **片頭卡、片尾卡完全靜止**：只有淡入淡出，文字邊緣不閃動。
  - **照片運鏡平順**：抽看人臉靠近畫面邊緣、或焦點在上下緣的照片，起步不能先往反方向跳一下再停住。

## 已知問題與防呆（請照做，避免重蹈覆轍）

| 問題 | 成因 | 系統內建的防護 | 製作者要做的事 |
|---|---|---|---|
| 字幕或片頭出現方框字（例如「啟」） | 日文字型（如 macOS「ヒラギノ丸ゴ」）沒有部分繁體字（日文寫作「啓」），畫出 .notdef 缺字框 | 字型改為**繁體中文優先**（內建 Noto Sans TC Black → 蘋方／微軟正黑體 → Noto CJK TC），並**實際檢驗每個要顯示的字**；TTC 字型集會挑 TC 字面；日文字型只當最後備援 | 安裝時讓 `setup` 執行 `mvctl fonts` 下載 Noto Sans TC；`doctor` 字型項目要 ✅；設定 `MV_FONT` 時也會被檢驗，缺字就自動跳過 |
| 片頭卡、片尾卡文字抖動 | 對文字卡套用 Ken Burns 緩慢縮放，1080p 整數像素取整讓文字邊緣每格跳動 | 固定素材（排程標記 `FIXED`，或檔名為「片頭」「片尾」）一律**完全靜態**，1:1 輸出，只保留淡入淡出 | 片頭片尾請做成 1920×1080 圖檔，檔名用 `片頭.png`／`片尾.png` |
| 照片運鏡抖動、起步反向跳 | 取景框用整數座標；焦點靠邊時移動量超出畫布被逐格卡扣（clamp），造成先反向再鎖死 | **浮點取景框＋雙三次次像素重採樣**、**Smoothstep 緩動**；運鏡終點先依最大縮放（1.14）限制在**安全邊界**內，全程單調、不撞邊 | 不需要手動處理；若仍覺得某張晃，到把關點 2 微調該張焦點或換照片 |

修改渲染程式（`lib/render.py`、`lib/portable.py`）時，不可移除以上任何一項防護；改完必跑 `python tests/test_render_guards.py`，全部通過才可使用。

## 3. 與使用者互動的原則
- 每個階段結束都用一兩句話回報結果與下一步；兩個把關點一定要停下來等使用者確認。
- 使用者可能不熟指令：需要他動手的地方（看校對影片、拖拉換照片）直接告訴他開哪個網址、點哪個分頁。
- 照片、歌詞屬於使用者與活動參與者，不上傳到 Skill 以外的服務；Gemini 自動分析只有在使用者明確要求並提供 Key 時才用。

## 4. 疑難排解
常見錯誤（找不到 FFmpeg、字幕變方框、HEIC 讀不到、編碼失敗、Whisper 太慢、手機連不上上傳頁、雲端同步失敗、Windows 的亂碼／OneDrive／防火牆／執行原則）見 `references/troubleshooting.md`。

## 5. 參考文件
- `references/workflow.md`：六階段完整規格與演算法參數
- `references/photo_analysis_protocol.md`：視覺分析 subagent 派工與評分規則
- `references/troubleshooting.md`：環境與錯誤排除
- `app/prompts/`：給使用者複製貼上的三段提示詞（A 安裝、B 製作、C 接續），含 `[下載網址]`、`[同步網址]`、`[同步金鑰]`、`[活動名稱]` 代入欄位
- `references/review-2026-10.md`：本版流程 Review、已修正項目與後續優化建議
