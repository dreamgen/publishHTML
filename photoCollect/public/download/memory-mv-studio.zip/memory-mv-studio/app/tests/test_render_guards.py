#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
渲染防呆回歸測試（修改 lib/render.py 或 lib/portable.py 後必跑）：
    python tests/test_render_guards.py

檢查三件曾經出過事的地方：
  1. 字型：選到的字型必須畫得出繁體探針字（曾因日文字型缺「啟」出現方框）
  2. 運鏡：各種焦點位置下，取景框全程在畫布內、移動方向單調（不撞邊回彈）、不做整數取整
  3. 片頭／片尾：排程標記 FIXED 的片段會被標為 static（完全靜態）
  4. 過場：快節奏不經黑場（短照片硬切、長照片溶接），幀數依累計時間軸不漂移
"""
import itertools
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "mv_studio"))

from lib import portable, render as R  # noqa: E402

fails = 0


def check(cond, msg):
    global fails
    print(("  ok   " if cond else "  FAIL ") + msg)
    if not cond:
        fails += 1


print("[1] 繁體字型")
fc = portable.choose_cjk_font("我們一起啟程，臺灣")
check(fc is not None, f"找得到中文字型：{fc}")
if fc:
    check(not fc.missing, f"繁體探針字全部可顯示（缺：{''.join(fc.missing) or '無'}）")

print("[2] 運鏡取景框")
W, H = R.TARGET_WIDTH, R.TARGET_HEIGHT
N = 120
progs = [i / (N - 1) for i in range(N)]
oob = reversal = integer_like = 0
for fx, fy in itertools.product([0.0, 0.05, 0.3, 0.5, 0.7, 0.95, 1.0], [0.0, 0.05, 0.38, 0.95, 1.0]):
    for zoom_in in (True, False):
        T = R._safe_target(fx * W, fy * H, R.ZOOM_MAX)
        boxes = [R.camera_box(p, zoom_in, *T) for p in progs]
        for b in boxes:
            if b[0] < -1e-6 or b[1] < -1e-6 or b[2] > W + 1e-6 or b[3] > H + 1e-6:
                oob += 1
        for k in (0, 1):
            cen = [(b[k] + b[k + 2]) / 2 for b in boxes]
            d = [y - x for x, y in zip(cen, cen[1:]) if abs(y - x) > 1e-9]
            reversal += sum(1 for a, c in zip(d, d[1:]) if (a > 0) != (c > 0))
        integer_like += all(abs(b[0] - round(b[0])) < 1e-9 for b in boxes[1:-1])
check(oob == 0, f"取景框不超出畫布（超出 {oob} 格）")
check(reversal == 0, f"移動方向單調、不回彈（反向 {reversal} 次）")
check(integer_like == 0, "取景框為浮點（次像素），未被取整")
check(abs(R._smoothstep(0.0)) < 1e-9 and abs(R._smoothstep(1.0) - 1) < 1e-9 and R._smoothstep(0.5) == 0.5, "Smoothstep 緩動曲線")

print("[3] 片頭／片尾靜態")
check({"片頭", "片尾"} <= R.STATIC_CARD_STEMS, "片頭、片尾檔名會被視為靜態")
src = (ROOT / "mv_studio" / "lib" / "manifest.py").read_text(encoding="utf-8")
check('"static": a.get("reason") == "FIXED"' in src, "排程輸出 FIXED 片段帶 static 旗標")

print("[4] 過場與幀數")
check(R.transition_length(1.0, 3.0) == 0.0, "任一張 ≤ HARD_CUT_THRESHOLD → 拍點硬切")
check(R.transition_length(R.HARD_CUT_THRESHOLD, 3.0) == 0.0, "剛好等於門檻也硬切")
x = R.transition_length(2.0, 3.0)
check(abs(x - 2.0 * R.XFADE_RATIO) < 1e-9, f"溶接長度隨較短者縮放（2.0s → {x:.2f}s）")
check(R.transition_length(30.0, 30.0) == R.XFADE_MAX, "溶接長度不超過上限")
check(R.XFADE_RATIO / 2 < 0.5, "前後兩段溶接各佔不到一半，不會在同一張內重疊")
durs = [3.0, 1.0, 0.8, 0.55, 2.5, 2.5, 1.5, 0.7, 0.7, 0.7]
t = 0.0
expect = 0
for d in durs:
    sf, n = R.frame_range(t, d)
    check(sf == expect, f"片段起始幀連續（t={t:.2f}s → 第 {sf} 幀）") if sf != expect else None
    expect = sf + n
    t += d
check(expect == round(sum(durs) * R.FRAME_RATE), f"總幀數 = 總時長×幀率（{expect} 幀，無累積漂移）")

print("\n全部通過" if fails == 0 else f"\n失敗 {fails} 項")
sys.exit(1 if fails else 0)
