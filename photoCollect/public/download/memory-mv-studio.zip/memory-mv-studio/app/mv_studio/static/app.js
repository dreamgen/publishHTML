// MV Studio — 前端邏輯 v3.0（純 vanilla JS，hash router）
// 重大升級：
//   - 照片分配分頁改為「主題群組視圖 + 大圖 Picker」
//   - Picker 支援鍵盤導覽、大圖預覽、分數顯示、排序篩選
//   - 主題覆蓋率儀表板
//   - 全屏照片預覽（照片分析分頁）
//   - 整體視覺升級

const state = {
  projectId: null,
  tab: "settings",
  proj: null,
  pollTimer: null,
  photosFilterPending: false,
  photosFilterTheme: "",

  // Picker 狀態
  pickerSlotId: null,
  pickerTheme: null,
  pickerItems: [],
  pickerSelectedIdx: -1,
  pickerCurrentAssigned: null,
};

const TABS = [
  ["event_prep",   "🎪 活動籌備 & 募集"],
  ["settings",     "⚙️ 專案設定"],
  ["lyrics",       "🎤 歌詞對齊"],
  ["content_plan", "🗂️ 內容規劃"],
  ["photos",       "📷 照片分析"],
  ["manifest",     "🎞️ 照片挑選"],
  ["render",       "🎬 開始渲染"],
];

// ===============================================================
// 共用工具
// ===============================================================

async function api(path, options) {
  const res = await fetch(path, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `請求失敗 (${res.status})`);
  return data;
}

function toast(msg, isError = false) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.remove("hidden");
  el.classList.toggle("error", isError);
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add("hidden"), 3400);
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function thumbUrl(projectId, filename) {
  return `/thumb/${projectId}/${encodeURIComponent(filename)}`;
}

function imageUrl(projectId, filename) {
  return `/image/${projectId}/${encodeURIComponent(filename)}`;
}

function clearPoll() {
  if (state.pollTimer) {
    clearInterval(state.pollTimer);
    state.pollTimer = null;
  }
  if (state._autoAnalyzePollTimer) {
    clearInterval(state._autoAnalyzePollTimer);
    state._autoAnalyzePollTimer = null;
  }
  if (state._subagentPollTimer) {
    clearInterval(state._subagentPollTimer);
    state._subagentPollTimer = null;
  }
  if (state._eventPollTimer) {
    clearInterval(state._eventPollTimer);
    state._eventPollTimer = null;
  }
}

function val(id) { return document.getElementById(id).value.trim(); }
function numVal(id) { return parseFloat(document.getElementById(id).value) || 0; }

// ===============================================================
// Router
// ===============================================================

function parseHash() {
  const h = location.hash.replace(/^#\/?/, "");
  const parts = h.split("/").filter(Boolean);
  if (parts[0] === "p" && parts[1]) {
    return { view: "project", projectId: parts[1], tab: parts[2] || "settings" };
  }
  return { view: "home" };
}

function navigate(hash) { location.hash = hash; }

async function router() {
  clearPoll();
  const r = parseHash();
  if (r.view === "home") {
    state.projectId = null;
    await renderHome();
  } else {
    state.projectId = r.projectId;
    state.tab = r.tab;
    await renderProject();
  }
}

window.addEventListener("hashchange", router);
document.addEventListener("DOMContentLoaded", () => {
  router();
  initFullscreenOverlay();
  initPickerModal();
  initFsBrowserModal();
});

// ===============================================================
// 首頁
// ===============================================================

function statusBadges(proj) {
  const s = proj.status || {};
  const items = [
    ["活動募集", s.event_prepared],
    ["歌詞對齊", s.lyrics_aligned],
    ["內容規劃", s.content_planned],
    ["照片標記", (s.photos_analyzed || 0) > 0 ? `${s.photos_analyzed} 張` : false],
    ["照片分配", s.manifest_built],
    ["已渲染",   s.rendered],
  ];
  return items.map(([label, done]) =>
    `<span class="status-badge ${done ? "done" : ""}">${label}${typeof done === "string" ? " " + done : ""}</span>`
  ).join("");
}

async function renderHome() {
  const app = document.getElementById("app");
  app.innerHTML = `
    <header class="topbar">
      <div class="brand">🎬 MV Studio</div>
    </header>
    <main>
      <div class="home-hero">
        <h1>我的 MV 專案</h1>
        <button id="btnNewProject" class="btn primary">＋ 新增專案</button>
      </div>
      <div id="projectGrid" class="project-grid"></div>
    </main>
  `;
  document.getElementById("btnNewProject").addEventListener("click", createProjectFlow);

  try {
    const data = await api("/api/projects");
    const grid = document.getElementById("projectGrid");
    if (data.projects.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <span class="icon">🎵</span>
          <div>還沒有任何專案</div>
          <div style="font-size:12px;color:var(--text-muted);margin-top:8px;">點「新增專案」開始製作第一支 MV</div>
        </div>`;
      return;
    }
    grid.innerHTML = "";
    data.projects.forEach((proj) => {
      const card = document.createElement("div");
      card.className = "project-card";
      card.innerHTML = `
        <h3>${esc(proj.song_title || proj.name)}</h3>
        <div class="sub">${esc(proj.name)} ・ 更新於 ${esc((proj.updated_at || "").slice(0, 16).replace("T", " "))}</div>
        <div class="status-badges">${statusBadges(proj)}</div>
      `;
      card.addEventListener("click", () => navigate(`#/p/${proj.id}/settings`));
      grid.appendChild(card);
    });
  } catch (e) {
    toast(e.message, true);
  }
}

async function createProjectFlow() {
  const name = prompt("專案名稱（例如歌曲名稱）：");
  if (!name) return;
  try {
    const proj = await api("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, song_title: name }),
    });
    navigate(`#/p/${proj.id}/settings`);
  } catch (e) {
    toast(e.message, true);
  }
}

// ===============================================================
// 專案工作區外殼
// ===============================================================

async function renderProject() {
  const app = document.getElementById("app");
  try {
    state.proj = await api(`/api/projects/${state.projectId}`);
  } catch (e) {
    app.innerHTML = `<div style="padding:60px;text-align:center;color:var(--red)">${esc(e.message)}</div>`;
    return;
  }
  const proj = state.proj;

  app.innerHTML = `
    <header class="topbar">
      <div class="brand" id="brandHome">🎬 MV Studio</div>
      <div class="song-title">${esc(proj.song_title || proj.name)}</div>
      <nav class="tabs">
        ${TABS.map(([key, label]) =>
          `<button class="tab-btn ${key === state.tab ? "active" : ""}" data-tab="${key}">${label}</button>`
        ).join("")}
      </nav>
    </header>
    <main id="tabContent"></main>
  `;
  document.getElementById("brandHome").addEventListener("click", () => navigate("#/"));
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => navigate(`#/p/${state.projectId}/${btn.dataset.tab}`));
  });

  const renderers = {
    event_prep:   renderEventPrepTab,
    settings:     renderSettingsTab,
    lyrics:       renderLyricsTab,
    content_plan: renderContentPlanTab,
    photos:       renderPhotosTab,
    manifest:     renderManifestTab,
    render:       renderRenderTab,
  };
  const fn = renderers[state.tab] || renderEventPrepTab;
  await fn(proj);
}

async function refreshProj() {
  state.proj = await api(`/api/projects/${state.projectId}`);
  return state.proj;
}

// ===============================================================
// 分頁 1：專案設定
// ===============================================================

async function renderSettingsTab(proj) {
  const sp = proj.slot_params || {};
  const el = document.getElementById("tabContent");
  el.innerHTML = `
    <div class="settings-form">
      <h2>基本資訊</h2>
      <label>專案名稱</label>
      <input type="text" id="f_name" value="${esc(proj.name)}" />
      <label>歌曲標題（顯示用）</label>
      <input type="text" id="f_song_title" value="${esc(proj.song_title)}" />

      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-top:28px;margin-bottom:14px;padding-bottom:8px;border-bottom:1px solid var(--border);">
        <h2 style="margin:0;padding:0;border:none;">素材路徑</h2>
        <button type="button" id="btnQuickFolderSetup" class="btn small primary" title="選擇一個包含音樂、照片或字幕的資料夾，自動偵測並填入下方所有欄位">
          ✨ 選擇專案資料夾一鍵帶入路徑
        </button>
      </div>

      <label>音樂檔路徑（mp3 / wav / m4a 等）</label>
      <div class="path-input-row">
        <input type="text" id="f_music_file" value="${esc(proj.music_file)}" placeholder="~/Downloads/歌名.mp3" />
        <button type="button" class="btn small btn-browse-fs" data-target="f_music_file" data-mode="audio" data-title="🎵 選擇音樂檔案">📂 瀏覽…</button>
        <button type="button" class="btn small btn-native-fs" data-target="f_music_file" data-mode="audio" title="使用系統原生視窗（macOS Finder／Windows 檔案總管） 選取音樂檔">🖥️ 系統視窗</button>
      </div>

      <label>照片資料夾路徑</label>
      <div class="path-input-row">
        <input type="text" id="f_photos_dir" value="${esc(proj.photos_dir)}" placeholder="~/Downloads/歌名_照片" />
        <button type="button" class="btn small btn-browse-fs" data-target="f_photos_dir" data-mode="dir" data-title="📸 選擇照片資料夾">📂 瀏覽…</button>
        <button type="button" class="btn small btn-native-fs" data-target="f_photos_dir" data-mode="dir" title="使用系統原生視窗（macOS Finder／Windows 檔案總管） 選取照片資料夾">🖥️ 系統視窗</button>
      </div>
      <p class="hint">若要讓 Agent 在對話中直接看照片做視覺分析標記，這個資料夾需在目前 session 存取得到（例如放進本專案資料夾或 Downloads 內）。</p>

      <label>Google 相簿公開分享網址（支援快速挑選，僅正式選中才下載原圖）</label>
      <div class="path-input-row">
        <input type="text" id="f_gphotos_url" value="${esc(proj.gphotos_url || '')}" placeholder="https://photos.app.goo.gl/... 或 https://photos.google.com/share/..." />
        <button type="button" id="btnImportGPhotosFromSettings" class="btn small primary" title="從 Google 相簿匯入照片清單">🌐 匯入相簿</button>
      </div>
      <p class="hint">可直接貼上 Google 相簿分享連結並點擊「匯入相簿」，系統將建立輕量預覽；僅正式挑選上時間軸的照片才下載最高畫質原圖！</p>

      <label>字幕檔（SRT）路徑（留空則用專案內自動產生的字幕）</label>
      <div class="path-input-row">
        <input type="text" id="f_srt_file" value="${esc(proj.srt_file)}" placeholder="留空 = 使用歌詞對齊產生的字幕" />
        <button type="button" class="btn small btn-browse-fs" data-target="f_srt_file" data-mode="srt" data-title="📝 選擇字幕檔案 (SRT)">📂 瀏覽…</button>
        <button type="button" class="btn small btn-native-fs" data-target="f_srt_file" data-mode="srt" title="使用系統原生視窗（macOS Finder／Windows 檔案總管） 選取字幕檔">🖥️ 系統視窗</button>
      </div>

      <label>輸出影片路徑（留空則自動存在專案資料夾 output/ 內）</label>
      <div class="path-input-row">
        <input type="text" id="f_output_file" value="${esc(proj.output_file)}" placeholder="留空 = 自動命名" />
        <button type="button" class="btn small btn-browse-fs" data-target="f_output_file" data-mode="output" data-title="💾 選擇輸出影片位置">📂 瀏覽…</button>
        <button type="button" class="btn small btn-native-fs" data-target="f_output_file" data-mode="output" title="使用系統原生視窗（macOS Finder／Windows 檔案總管） 設定輸出檔案位置">🖥️ 系統視窗</button>
      </div>

      <h2>片頭 / 片尾</h2>
      <div class="row2">
        <div>
          <label>片頭素材檔名（相對於照片資料夾）</label>
          <div class="path-input-row">
            <input type="text" id="f_title_card_file" value="${esc(proj.title_card_file)}" />
            <button type="button" class="btn small btn-browse-fs" data-target="f_title_card_file" data-mode="image" data-rel-photos="1" data-title="🖼️ 選擇片頭圖片">📂 挑選</button>
          </div>
        </div>
        <div>
          <label>片頭時長（秒）</label>
          <input type="number" step="0.1" id="f_title_card_duration" value="${proj.title_card_duration}" />
        </div>
      </div>
      <div class="row2">
        <div>
          <label>片尾素材檔名（相對於照片資料夾）</label>
          <div class="path-input-row">
            <input type="text" id="f_outro_file" value="${esc(proj.outro_file)}" />
            <button type="button" class="btn small btn-browse-fs" data-target="f_outro_file" data-mode="image" data-rel-photos="1" data-title="🖼️ 選擇片尾圖片">📂 挑選</button>
          </div>
        </div>
        <div>
          <label>片尾時長（秒）</label>
          <input type="number" step="0.1" id="f_outro_duration" value="${proj.outro_duration}" />
        </div>
      </div>

      <h2>時間槽切分參數</h2>
      <div class="row2">
        <div>
          <label>目標單張照片時長（秒）</label>
          <input type="number" step="0.1" id="f_target_slot" value="${sp.target_slot_duration ?? 3.5}" />
        </div>
        <div>
          <label>間隙合併門檻（秒）</label>
          <input type="number" step="0.1" id="f_gap_merge" value="${sp.gap_merge_threshold ?? 2.0}" />
        </div>
      </div>
      <div class="row2">
        <div>
          <label>間奏最短時長（秒）</label>
          <input type="number" step="0.1" id="f_min_slot" value="${sp.min_slot_duration ?? 2.0}" />
        </div>
        <div>
          <label>歌詞段落最短時長（秒）</label>
          <input type="number" step="0.1" id="f_min_lyric_slot" value="${sp.min_lyric_slot ?? 2.5}" />
        </div>
      </div>
      <div class="row2" style="margin-top:8px;align-items:center;">
        <div>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin-top:10px;">
            <input type="checkbox" id="f_beat_snap" ${(sp.beat_snap ?? true) ? "checked" : ""} />
            <span>🥁 啟用音樂節拍對齊（Beat-Snapping 間奏與長句切點踩拍）</span>
          </label>
        </div>
        <div>
          <label>👥 人物出場均衡加權（0 = 關閉，建議 2.5）</label>
          <input type="number" step="0.5" min="0" max="10" id="f_protagonist_weight" value="${sp.protagonist_weight ?? 2.5}" />
        </div>
      </div>

      <h2>🤖 AI 照片分析設定</h2>
      <p class="hint">設定後可在「📷 照片分析」分頁一鍵讓 Gemini AI 自動標記所有照片的主題與品質分。</p>
      <label>Gemini API Key（<a href="https://aistudio.google.com/app/apikey" target="_blank">取得免費 Key</a>）</label>
      <input type="password" id="f_gemini_api_key" value="${esc(proj.gemini_api_key || '')}" placeholder="AIza..." autocomplete="off" />
      <label>AI 分析模型</label>
      <select id="f_gemini_model" style="width:100%;padding:8px;">
        <option value="gemini-3.8-flash" ${(proj.gemini_model||'gemini-3.8-flash')==='gemini-3.8-flash'?'selected':''}>gemini-3.8-flash（最新最快，推薦）</option>
        <option value="gemini-3.5-flash" ${(proj.gemini_model||'')==='gemini-3.5-flash'?'selected':''}>gemini-3.5-flash</option>
        <option value="gemini-2.5-flash" ${(proj.gemini_model||'')==='gemini-2.5-flash'?'selected':''}>gemini-2.5-flash</option>
        <option value="gemini-2.5-pro" ${(proj.gemini_model||'')==='gemini-2.5-pro'?'selected':''}>gemini-2.5-pro（更精準，較慢）</option>
      </select>

      <div style="margin-top:20px;display:flex;gap:10px;">
        <button id="btnSaveSettings" class="btn primary">儲存設定</button>
        <button id="btnDeleteProject" class="btn danger">刪除此專案</button>
      </div>
      <div id="saveHint" class="save-hint"></div>
    </div>
  `;

  document.getElementById("btnSaveSettings").addEventListener("click", async () => {
    const patch = {
      name: val("f_name"), song_title: val("f_song_title"),
      music_file: val("f_music_file"), photos_dir: val("f_photos_dir"),
      gphotos_url: val("f_gphotos_url"),
      srt_file: val("f_srt_file"), output_file: val("f_output_file"),
      title_card_file: val("f_title_card_file"), outro_file: val("f_outro_file"),
      title_card_duration: numVal("f_title_card_duration"), outro_duration: numVal("f_outro_duration"),
      gemini_api_key: val("f_gemini_api_key"),
      gemini_model: document.getElementById("f_gemini_model").value,
      slot_params: {
        target_slot_duration: numVal("f_target_slot"),
        gap_merge_threshold: numVal("f_gap_merge"),
        min_slot_duration: numVal("f_min_slot"),
        min_lyric_slot: numVal("f_min_lyric_slot"),
        beat_snap: document.getElementById("f_beat_snap").checked,
        protagonist_weight: numVal("f_protagonist_weight"),
      },
    };
    try {
      await api(`/api/projects/${state.projectId}`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch),
      });
      document.getElementById("saveHint").textContent = "✓ 已儲存";
      setTimeout(() => (document.getElementById("saveHint").textContent = ""), 2000);
      await refreshProj();
    } catch (e) { toast(e.message, true); }
  });

  document.getElementById("btnImportGPhotosFromSettings")?.addEventListener("click", async () => {
    const url = val("f_gphotos_url");
    if (!url) { toast("請先輸入 Google 相簿網址", true); return; }
    try {
      toast("🌐 正在連接 Google 相簿並讀取照片清單，請稍候...");
      const res = await api(`/api/projects/${state.projectId}/photos/gphotos/import`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }),
      });
      toast(`✅ 成功匯入「${res.album_title}」，新增 ${res.added_count} 張照片！`);
      await refreshProj();
      await renderSettingsTab(state.proj);
    } catch (e) { toast(e.message, true); }
  });

  document.getElementById("btnDeleteProject").addEventListener("click", async () => {
    if (!confirm(`確定要刪除專案「${proj.name}」嗎？（資料夾會保留但不再顯示於清單）`)) return;
    try {
      await api(`/api/projects/${state.projectId}`, { method: "DELETE" });
      navigate("#/");
    } catch (e) { toast(e.message, true); }
  });

  // 綁定檔案瀏覽器按鈕與原生 Finder 選取按鈕
  el.querySelectorAll(".btn-browse-fs").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.dataset.target;
      const mode = btn.dataset.mode || "all";
      const title = btn.dataset.title || "📂 選擇路徑";
      const relPhotos = btn.dataset.relPhotos === "1";
      let initialPath = val(targetId);
      if (relPhotos) {
        const pdir = val("f_photos_dir");
        if (pdir) {
          initialPath = initialPath && !initialPath.startsWith("/") ? `${pdir}/${initialPath}` : (initialPath || pdir);
        }
      }
      if (!initialPath) {
        initialPath = val("f_photos_dir") || val("f_music_file") || "";
      }
      openFsBrowser({
        targetInputId: targetId,
        mode,
        title,
        initialPath,
        relativeToPhotosDir: relPhotos,
      });
    });
  });

  el.querySelectorAll(".btn-native-fs").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.dataset.target;
      const mode = btn.dataset.mode || "dir";
      const initialPath = val(targetId) || val("f_photos_dir") || val("f_music_file") || "";
      triggerNativePick(targetId, mode, initialPath);
    });
  });

  document.getElementById("btnQuickFolderSetup").addEventListener("click", () => {
    const initialPath = val("f_photos_dir") || val("f_music_file") || "";
    openFsBrowser({
      targetInputId: "f_photos_dir",
      mode: "dir",
      title: "✨ 選擇專案素材資料夾（可一鍵自動帶入音樂、照片與字幕）",
      initialPath,
      autoApplyCompanions: true,
    });
  });
}

// ===============================================================
// 分頁 2：歌詞對齊
// ===============================================================

async function renderLyricsTab(proj) {
  const el = document.getElementById("tabContent");
  let lyricsText = "";
  try {
    const r = await api(`/api/projects/${state.projectId}/lyrics/text`);
    lyricsText = r.text || "";
  } catch (e) { /* ignore */ }

  el.innerHTML = `
    <h2 style="margin-top:0;">1. 貼上歌詞文字</h2>
    <textarea id="lyricsText" rows="8" placeholder="每行一句歌詞，會用來跟音樂做逐字比對">${esc(lyricsText)}</textarea>
    <div style="margin:8px 0 24px;">
      <button id="btnSaveLyrics" class="btn">儲存歌詞文字</button>
    </div>

    <h2>2. 執行歌詞對齊（Whisper 語音辨識 + 動態規劃比對）</h2>
    <div class="toolbar">
      <label>模型大小
        <select id="modelSize">
          <option value="tiny">tiny（最快）</option>
          <option value="base">base</option>
          <option value="small">small</option>
          <option value="medium" selected>medium（建議）</option>
          <option value="large">large（最準但很慢）</option>
        </select>
      </label>
      <button id="btnStartAlign" class="btn primary">🎙️ 開始對齊</button>
      <span id="alignStatusPill" class="status-pill idle">尚未執行</span>
    </div>
    <div id="alignLog" class="log-console" style="display:none;"></div>

    <h2>3. 字幕預覽 / 手動微調</h2>
    <div id="srtArea"></div>
  `;

  document.getElementById("btnSaveLyrics").addEventListener("click", async () => {
    try {
      await api(`/api/projects/${state.projectId}/lyrics/text`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: document.getElementById("lyricsText").value }),
      });
      toast("歌詞已儲存");
    } catch (e) { toast(e.message, true); }
  });

  document.getElementById("btnStartAlign").addEventListener("click", async () => {
    try {
      await api(`/api/projects/${state.projectId}/lyrics/align/start`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: document.getElementById("modelSize").value }),
      });
      toast("已開始執行對齊（這可能需要數十秒到數分鐘）");
      pollAlignStatus();
    } catch (e) { toast(e.message, true); }
  });

  await loadSrtPreview();
  pollAlignStatus();
}

async function pollAlignStatus() {
  clearPoll();
  const tick = async () => {
    try {
      const s = await api(`/api/projects/${state.projectId}/lyrics/align/status`);
      const pill = document.getElementById("alignStatusPill");
      const logEl = document.getElementById("alignLog");
      if (!pill) { clearPoll(); return; }
      pill.className = `status-pill ${s.status}`;
      pill.textContent = { idle: "尚未執行", running: "執行中…", done: "已完成", error: "發生錯誤" }[s.status] || s.status;
      if (s.log && s.log.length) {
        logEl.style.display = "block";
        logEl.textContent = s.log.join("\n");
        logEl.scrollTop = logEl.scrollHeight;
      }
      if (s.status === "done") {
        clearPoll(); toast("歌詞對齊完成！"); await loadSrtPreview();
      } else if (s.status === "error") {
        clearPoll(); toast(s.error || "對齊失敗", true);
      }
    } catch (e) { /* ignore */ }
  };
  await tick();
  state.pollTimer = setInterval(tick, 2000);
}

async function loadSrtPreview() {
  const area = document.getElementById("srtArea");
  if (!area) return;
  try {
    const data = await api(`/api/projects/${state.projectId}/lyrics/srt`);
    if (!data.entries.length) {
      area.innerHTML = `<p class="hint">尚無字幕資料，請先完成上方的歌詞對齊。</p>`;
      return;
    }
    area.innerHTML = `
      <table class="srt-table">
        <thead><tr><th>#</th><th>開始</th><th>結束</th><th>文字</th></tr></thead>
        <tbody>
          ${data.entries.map((e) => `
            <tr data-idx="${e.idx}">
              <td>${e.idx}</td>
              <td><input type="text" class="time-input" data-role="start" value="${e.start.toFixed(2)}" /></td>
              <td><input type="text" class="time-input" data-role="end" value="${e.end.toFixed(2)}" /></td>
              <td><input type="text" data-role="text" value="${esc(e.text)}" /></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
      <div style="margin-top:10px;"><button id="btnSaveSrt" class="btn primary">儲存字幕修改</button></div>
    `;
    document.getElementById("btnSaveSrt").addEventListener("click", async () => {
      const rows = area.querySelectorAll("tbody tr");
      const entries = Array.from(rows).map((tr) => ({
        idx: parseInt(tr.dataset.idx, 10),
        start: parseFloat(tr.querySelector('[data-role="start"]').value),
        end: parseFloat(tr.querySelector('[data-role="end"]').value),
        text: tr.querySelector('[data-role="text"]').value,
      }));
      try {
        await api(`/api/projects/${state.projectId}/lyrics/srt`, {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ entries }),
        });
        toast("字幕已儲存");
      } catch (e) { toast(e.message, true); }
    });
  } catch (e) {
    area.innerHTML = `<p class="hint">尚無字幕資料。</p>`;
  }
}

// ===============================================================
// 分頁 3：內容規劃
// ===============================================================

async function renderContentPlanTab(proj) {
  const el = document.getElementById("tabContent");
  el.innerHTML = `
    <h2 style="margin-top:0;">1. 主題標籤管理</h2>
    <p class="hint">定義這首歌會用到的照片主題分類（例如 Intro / 溫馨互動 / 遊戲關卡…），並可填入關鍵字供自動建議比對。</p>
    <div id="themeEditor" class="theme-editor"></div>
    <div style="margin-bottom:24px;display:flex;gap:8px;flex-wrap:wrap;">
      <button id="btnAddTheme" class="btn small">＋ 新增主題標籤</button>
      <button id="btnLoadTemplate" class="btn small">載入參考範例（親子活動類）</button>
      <button id="btnSaveThemes" class="btn primary small">儲存主題標籤</button>
    </div>

    <h2>2. 由歌詞內容分析建議主題</h2>
    <p class="hint">直接分析歌詞重複出現的詞組，抓出可能適合當主題分類的候選字詞。</p>
    <div class="toolbar">
      <button id="btnAnalyzeCandidates" class="btn">🔍 分析歌詞產生建議</button>
    </div>
    <div id="candidatesArea" style="margin-bottom:24px;"></div>

    <h2>3. 逐行歌詞指派主題</h2>
    <div class="toolbar">
      <button id="btnSuggest" class="btn">✨ 依關鍵字自動建議</button>
      <label class="filter-label"><input type="checkbox" id="overwriteSuggest" /> 覆蓋已指派的行</label>
    </div>
    <div id="lyricsMapArea"></div>

    <h2>4. 建立時間軸（含音樂節拍對齊 Beat-Snapping）</h2>
    <p class="hint">依照上面的主題指派與時間槽參數，切分出完整的照片時槽時間軸（content_plan.json）。啟用節拍對齊時，系統會以 FFmpeg + 頻譜能量通量自動偵測鼓點重拍，讓間奏與長句切分點精準踩在音樂拍點上。</p>
    <div class="toolbar">
      <button id="btnBuildPlan" class="btn primary">🔨 建立 / 重新建立時間軸</button>
      <label class="filter-label" style="cursor:pointer;">
        <input type="checkbox" id="chkBeatSnapPlan" ${((proj.slot_params || {}).beat_snap ?? true) ? "checked" : ""} />
        🥁 啟用音樂節拍對齊（Beat-Snapping）
      </label>
    </div>
    <div id="planSummary" style="margin-top:16px;"></div>
  `;

  renderThemeEditor(proj.themes || []);

  document.getElementById("btnAddTheme").addEventListener("click", () => {
    document.getElementById("themeEditor").appendChild(themeRowEl({ name: "", keywords: [] }));
  });
  document.getElementById("btnLoadTemplate").addEventListener("click", async () => {
    if (!confirm("會覆蓋目前的主題標籤設定，確定嗎？")) return;
    try {
      const r = await api(`/api/projects/${state.projectId}/themes/template`, { method: "POST" });
      renderThemeEditor(r.themes); toast("已載入範例模板");
    } catch (e) { toast(e.message, true); }
  });
  document.getElementById("btnSaveThemes").addEventListener("click", saveThemes);
  document.getElementById("btnAnalyzeCandidates").addEventListener("click", analyzeCandidates);
  document.getElementById("btnSuggest").addEventListener("click", async () => {
    try {
      const overwrite = document.getElementById("overwriteSuggest").checked;
      await api(`/api/projects/${state.projectId}/lyrics_map/suggest`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ overwrite }),
      });
      toast("已套用自動建議"); await loadLyricsMap();
    } catch (e) { toast(e.message, true); }
  });
  document.getElementById("btnBuildPlan").addEventListener("click", async () => {
    try {
      const beatSnap = document.getElementById("chkBeatSnapPlan").checked;
      const r = await api(`/api/projects/${state.projectId}/content_plan/build`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ beat_snap: beatSnap }),
      });
      const rows = Object.entries(r.theme_requirements).map(([theme, v]) =>
        `<tr><td>${esc(theme)}</td><td><b>${v.photos_needed}</b></td><td>${v.total_seconds.toFixed(1)}s</td></tr>`
      ).join("");
      const beatBadge = r.bpm > 0
        ? `<span class="beat-summary-pill">🥁 偵測速度 <b>${r.bpm} BPM</b>（共 ${r.beats_count || 0} 拍，<b>${r.beat_snapped_slots || 0}</b> 個時槽切點已對齊重拍）</span>`
        : `<span class="beat-summary-pill muted">未啟用節拍對齊</span>`;
      document.getElementById("planSummary").innerHTML = `
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:10px;">
          <span style="color:var(--green);font-weight:600;">✅ 已建立時間軸：共 ${r.total_slots} 個時槽，音樂長度 ${r.total_duration.toFixed(1)} 秒</span>
          ${beatBadge}
        </div>
        <table class="lyrics-map-table">
          <thead><tr><th>主題</th><th>需求張數</th><th>總秒數</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      `;
      await refreshProj();
    } catch (e) { toast(e.message, true); }
  });

  await loadLyricsMap();
}

function themeRowEl(t) {
  const row = document.createElement("div");
  row.className = "theme-row";
  row.innerHTML = `
    <input type="text" class="theme-name" placeholder="主題名稱" value="${esc(t.name)}" />
    <input type="text" class="theme-keywords" placeholder="關鍵字（逗號分隔）" value="${esc((t.keywords || []).join("、"))}" />
    <button class="btn small danger btnRemoveTheme">移除</button>
  `;
  row.querySelector(".btnRemoveTheme").addEventListener("click", () => row.remove());
  return row;
}

function renderThemeEditor(themes) {
  const editor = document.getElementById("themeEditor");
  editor.innerHTML = "";
  themes.forEach((t) => editor.appendChild(themeRowEl(t)));
}

function collectThemesFromEditor() {
  return Array.from(document.querySelectorAll("#themeEditor .theme-row")).map((row) => ({
    name: row.querySelector(".theme-name").value.trim(),
    keywords: row.querySelector(".theme-keywords").value.split(/[、,]/).map((s) => s.trim()).filter(Boolean),
  })).filter((t) => t.name);
}

async function saveThemes() {
  try {
    const themes = collectThemesFromEditor();
    await api(`/api/projects/${state.projectId}/themes`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ themes }),
    });
    toast("主題標籤已儲存"); await refreshProj(); await loadLyricsMap();
  } catch (e) { toast(e.message, true); }
}

async function analyzeCandidates() {
  const area = document.getElementById("candidatesArea");
  area.innerHTML = "<span style='color:var(--text-dim)'>分析中...</span>";
  try {
    const data = await api(`/api/projects/${state.projectId}/themes/candidates`);
    if (!data.candidates.length) {
      area.innerHTML = `<p class="hint">目前歌詞行數太少，或找不到明顯重複出現的詞組。</p>`;
      return;
    }
    area.innerHTML = "";
    data.candidates.forEach((c) => {
      const card = document.createElement("div");
      card.className = "theme-row";
      card.style.flexDirection = "column"; card.style.alignItems = "stretch";
      card.innerHTML = `
        <div class="row" style="gap:8px;">
          <input type="text" class="theme-name cand-name" value="${esc(c.name)}" />
          <input type="text" class="theme-keywords cand-keywords" value="${esc(c.keywords.join("、"))}" />
          <span class="badge">出現於 ${c.line_count} 行</span>
          <button class="btn small primary btnAddCandidate">＋ 加入主題清單</button>
        </div>
        <div class="hint" style="margin-top:4px;">例如：${c.sample_lines.map((l) => `「${esc(l)}」`).join("　")}</div>
      `;
      card.querySelector(".btnAddCandidate").addEventListener("click", async () => {
        const name = card.querySelector(".cand-name").value.trim();
        const keywords = card.querySelector(".cand-keywords").value.split(/[、,]/).map((s) => s.trim()).filter(Boolean);
        if (!name) { toast("請先填寫主題名稱", true); return; }
        try {
          const r = await api(`/api/projects/${state.projectId}/themes/candidates/add`, {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, keywords }),
          });
          renderThemeEditor(r.themes);
          toast(`已加入主題「${name}」`);
          card.remove();
          await refreshProj();
        } catch (e) { toast(e.message, true); }
      });
      area.appendChild(card);
    });
  } catch (e) {
    area.innerHTML = `<p class="hint">${esc(e.message)}</p>`;
  }
}

async function loadLyricsMap() {
  const area = document.getElementById("lyricsMapArea");
  if (!area) return;
  try {
    const data = await api(`/api/projects/${state.projectId}/lyrics_map`);
    if (!data.entries.length) {
      area.innerHTML = `<p class="hint">尚無歌詞資料，請先完成「歌詞對齊」分頁的步驟。</p>`;
      return;
    }
    const themeOpts = (theme) => `<option value="">（未指派）</option>` +
      data.themes.map((t) => `<option value="${esc(t.name)}" ${t.name === theme ? "selected" : ""}>${esc(t.name)}</option>`).join("");
    area.innerHTML = `
      <table class="lyrics-map-table">
        <thead><tr><th>#</th><th>時間</th><th>歌詞</th><th>主題</th></tr></thead>
        <tbody>
          ${data.entries.map((e) => `
            <tr>
              <td>${e.idx}</td>
              <td>${e.start.toFixed(1)}–${e.end.toFixed(1)}s</td>
              <td>${esc(e.text)}</td>
              <td><select data-idx="${e.idx}">${themeOpts(e.theme)}</select></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
    area.querySelectorAll("select").forEach((sel) => {
      sel.addEventListener("change", async () => {
        try {
          await api(`/api/projects/${state.projectId}/lyrics_map/assign`, {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ idx: parseInt(sel.dataset.idx, 10), theme: sel.value || null }),
          });
        } catch (e) { toast(e.message, true); }
      });
    });
  } catch (e) {
    area.innerHTML = `<p class="hint">${esc(e.message)}</p>`;
  }
}

// ===============================================================
// 分頁 4：照片分析（帶全屏預覽）
// ===============================================================

async function renderPhotosTab(proj) {
  const el = document.getElementById("tabContent");
  const activeMode = state.aiAnalyzeMode || "subagent";
  el.innerHTML = `
    <!-- AI 雙模式分析中樞（Subagent 多代理 + Gemini API Key） -->
    <div class="auto-analyze-panel" id="autoAnalyzePanel">
      <div class="auto-analyze-header" style="justify-content:space-between;flex-wrap:wrap;gap:10px;">
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
          <span class="auto-analyze-title">🤖 AI 視覺分析中樞</span>
          <div class="ai-mode-tabs">
            <button class="ai-mode-btn ${activeMode === 'subagent' ? 'active' : ''}" data-mode="subagent">
              🚀 Agent 多代理分析（Subagent・免 API Key）
            </button>
            <button class="ai-mode-btn ${activeMode === 'apikey' ? 'active' : ''}" data-mode="apikey">
              🔑 Gemini API Key 直接分析
            </button>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <span class="status-pill idle" id="subagentSyncPill" style="display:${activeMode === 'subagent' ? 'inline-flex' : 'none'};">🔄 自動監聽 CLI 同步中</span>
          <span class="status-pill idle" id="autoAnalyzeStatus" style="display:${activeMode === 'apikey' ? 'inline-flex' : 'none'};">待機</span>
        </div>
      </div>

      <!-- 模式 1：CLI / Agent 多代理視覺分析 (Subagent Mode) -->
      <div id="subagentModePane" style="display:${activeMode === 'subagent' ? 'block' : 'none'};">
        <div class="subagent-workflow-bar">
          <div class="subagent-controls">
            <div>
              <label style="display:block;margin-bottom:4px;">每組 Subagent 張數</label>
              <select id="subagentMaxPer">
                <option value="10">10 張 / 組（精細）</option>
                <option value="15" selected>15 張 / 組（推薦）</option>
                <option value="20">20 張 / 組（大批次）</option>
              </select>
            </div>
            <label class="filter-label" style="margin-bottom:6px;cursor:pointer;">
              <input type="checkbox" id="subagentReanalyze" /> 包含已分析照片重新分組
            </label>
            <button id="btnPrepareSubagent" class="btn primary">⚡ 1. 準備 Subagent 批次任務</button>
            <button id="btnToggleSubagentImport" class="btn">📥 手動貼上 / 上傳 JSON 結果</button>
          </div>
          <div id="subagentSummaryStats" class="subagent-summary-stats"></div>
        </div>

        <!-- 主題覆蓋率迷你進度列 -->
        <div id="subagentCoverageStrip" class="subagent-coverage-strip"></div>

        <!-- 已產生的 Agent 對話指令與 Shards 明細 -->
        <div id="subagentTaskBox" class="subagent-task-box" style="display:none;">
          <div class="subagent-prompt-row">
            <div style="flex:1;min-width:0;">
              <div style="font-size:11px;color:var(--text-dim);margin-bottom:4px;">
                💬 <b>Step 2：複製下方指令貼給對話中的 Agent（Antigravity / Claude）</b>，Agent 將自動派發多代理看縮圖評分並匯入：
              </div>
              <div class="subagent-cmd-preview" id="subagentChatPromptText"></div>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;justify-content:flex-end;">
              <button id="btnCopyChatPrompt" class="btn primary small">📋 一鍵複製對話指令</button>
              <button id="btnToggleShards" class="btn small">📦 查看各組 Shard Prompt</button>
            </div>
          </div>
          <div id="subagentShardsDrawer" class="subagent-shards-drawer" style="display:none;"></div>
        </div>

        <!-- 手動貼上或上傳 Subagent JSON 結果區 -->
        <div id="subagentImportDrawer" class="subagent-import-drawer" style="display:none;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;flex-wrap:wrap;gap:8px;">
            <span style="font-size:12px;font-weight:600;">📥 貼上 Subagent 回傳的 JSON 或選擇 .json 檔案匯入</span>
            <div style="display:flex;gap:8px;align-items:center;">
              <input type="file" id="subagentFileInput" accept=".json" multiple style="font-size:11px;max-width:220px;" />
              <button id="btnSubmitSubagentImport" class="btn primary small">✓ 立即匯入 Catalog</button>
            </div>
          </div>
          <textarea id="subagentRawJson" rows="5" placeholder='貼上 {"analyses": [...]} 或多個 Subagent 回傳的 JSON 內容...'></textarea>
        </div>

        <div class="hint" style="margin-top:8px;padding:0 4px;">
          💡 <b>Subagent 協同優勢</b>：自動將照片轉為 640px 高速快取縮圖並依專案主題切分任務。當 Agent 在終端機執行 <code>analyze_batch_photos.py import --project ${esc(state.projectId)}</code> 時，本頁面會<b>自動偵測並即時刷新照片網格</b>。
        </div>
      </div>

      <!-- 模式 2：Gemini API Key 背景執行緒分析 -->
      <div id="apikeyModePane" style="display:${activeMode === 'apikey' ? 'block' : 'none'};">
        <div class="auto-analyze-body">
          <div class="auto-analyze-inputs">
            <div style="flex:1;min-width:0;">
              <label style="display:block;margin-bottom:4px;">Gemini API Key</label>
              <input type="password" id="autoApiKey"
                value="${esc(proj.gemini_api_key || '')}"
                placeholder="AIza...（或先在⚙️設定頁儲存）"
                style="width:100%;" autocomplete="off" />
            </div>
            <div>
              <label style="display:block;margin-bottom:4px;">模型</label>
              <select id="autoModel">
                <option value="gemini-3.8-flash" ${(proj.gemini_model||'gemini-3.8-flash')==='gemini-3.8-flash'?'selected':''}>3.8 Flash (最快，推薦)</option>
                <option value="gemini-3.5-flash" ${(proj.gemini_model||'')==='gemini-3.5-flash'?'selected':''}>3.5 Flash</option>
                <option value="gemini-2.5-flash" ${(proj.gemini_model||'')==='gemini-2.5-flash'?'selected':''}>2.5 Flash</option>
                <option value="gemini-2.5-pro" ${(proj.gemini_model||'')==='gemini-2.5-pro'?'selected':''}>2.5 Pro (準確)</option>
              </select>
            </div>
            <div>
              <label style="display:block;margin-bottom:4px;">並行數</label>
              <select id="autoWorkers">
                <option value="1">1（保守）</option>
                <option value="2">2</option>
                <option value="3" selected>3（推薦）</option>
                <option value="5">5（積極）</option>
              </select>
            </div>
            <div style="display:flex;gap:8px;">
              <button id="btnStartAutoAnalyze" class="btn primary">▶ 開始 AI 分析</button>
              <button id="btnCancelAutoAnalyze" class="btn" style="display:none;background:var(--red);">🛑 取消</button>
            </div>
          </div>
          <div id="autoAnalyzeProgress" style="display:none;margin-top:10px;">
            <div class="progress-bar-outer" style="height:14px;">
              <div id="autoAnalyzeBar" class="progress-bar-inner" style="width:0%"></div>
            </div>
            <div id="autoAnalyzeLabel" class="hint" style="margin-top:4px;"></div>
          </div>
          <div id="autoAnalyzeLog" class="log-console" style="display:none;max-height:160px;margin-top:8px;"></div>
        </div>
        <div class="hint" style="margin-top:8px;padding:0 4px;">
          💡 使用您的 Google AI Studio API Key 在背景執行緒直接呼叫 Gemini Vision 模型分析所有待分析照片。
        </div>
      </div>
    </div>

    <!-- 照片掃描工具列 -->
    <div class="toolbar" style="margin-top:16px;">
      <button id="btnScan" class="btn">🔍 掃描新照片</button>
      <button id="btnImportGPhotos" class="btn primary" title="從 Google 相簿公開分享連結匯入所有照片">🌐 匯入 Google 相簿</button>
      <button id="btnDetectFocus" class="btn" title="利用 YCbCr 膚色熱區與空間梯度自動偵測所有人臉/主體焦點座標 (focus_x, focus_y)">🎯 批次偵測人臉焦點</button>
      <label class="filter-label" title="開啟後點擊照片縮圖可直接設定 Ken Burns 縮放目標焦點（或按住 Alt/Option 點擊）">
        <input type="checkbox" id="toggleFocusEditMode" ${state.focusEditMode ? 'checked' : ''} /> 🎯 點擊縮圖設焦點
      </label>
      <div class="stats" id="catalogStats"></div>
      <div class="spacer"></div>
      <label class="filter-label">
        <input type="checkbox" id="filterPending" ${state.photosFilterPending ? 'checked' : ''} /> 只顯示待分析
      </label>
      <select id="filterTheme"><option value="">全部主題</option></select>
    </div>
    <div id="catalogGrid" class="grid"></div>
  `;

  // 模式切換綁定
  el.querySelectorAll(".ai-mode-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.aiAnalyzeMode = btn.dataset.mode;
      el.querySelectorAll(".ai-mode-btn").forEach((b) => b.classList.toggle("active", b.dataset.mode === state.aiAnalyzeMode));
      document.getElementById("subagentModePane").style.display = state.aiAnalyzeMode === "subagent" ? "block" : "none";
      document.getElementById("apikeyModePane").style.display = state.aiAnalyzeMode === "apikey" ? "block" : "none";
      document.getElementById("subagentSyncPill").style.display = state.aiAnalyzeMode === "subagent" ? "inline-flex" : "none";
      document.getElementById("autoAnalyzeStatus").style.display = state.aiAnalyzeMode === "apikey" ? "inline-flex" : "none";
    });
  });

  document.getElementById("btnScan").addEventListener("click", async () => {
    await scanPhotos();
    await loadSubagentStatus();
  });
  document.getElementById("btnImportGPhotos").addEventListener("click", async () => {
    const current = (state.proj && state.proj.gphotos_url) || "";
    const url = prompt("請輸入 Google 相簿公開分享網址（例如：https://photos.app.goo.gl/...）：", current);
    if (!url || !url.trim()) return;
    try {
      toast("🌐 正在解析 Google 相簿並匯入照片清單，請稍候...");
      const res = await api(`/api/projects/${state.projectId}/photos/gphotos/import`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim() }),
      });
      toast(`✅ 成功匯入「${res.album_title}」，共新增 ${res.added_count} 張照片！`);
      await refreshProj();
      await loadCatalog();
      await loadSubagentStatus();
    } catch (err) {
      toast(err.message, true);
    }
  });
  document.getElementById("btnDetectFocus").addEventListener("click", async () => {
    const btn = document.getElementById("btnDetectFocus");
    try {
      btn.disabled = true;
      btn.textContent = "偵測人臉焦點中…";
      const res = await api(`/api/projects/${state.projectId}/photos/detect_focus`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ overwrite: true }),
      });
      toast(`🎯 已自動偵測並更新 ${res.updated} / ${res.total} 張照片的人臉焦點座標！`);
      await loadCatalog();
    } catch (e) {
      toast(e.message, true);
    } finally {
      btn.disabled = false;
      btn.textContent = "🎯 批次偵測人臉焦點";
    }
  });
  document.getElementById("toggleFocusEditMode").addEventListener("change", (e) => {
    state.focusEditMode = e.target.checked;
    renderCatalogGrid();
    if (state.focusEditMode) {
      toast("🎯 焦點微調模式已開啟：直接點擊任何照片縮圖即可設定 Ken Burns 鏡頭推進焦點");
    }
  });
  document.getElementById("filterPending").addEventListener("change", (e) => {
    state.photosFilterPending = e.target.checked;
    renderCatalogGrid();
  });
  document.getElementById("filterTheme").addEventListener("change", (e) => {
    state.photosFilterTheme = e.target.value;
    renderCatalogGrid();
  });

  // Subagent 模式事件綁定
  document.getElementById("btnPrepareSubagent").addEventListener("click", prepareSubagentTask);
  document.getElementById("btnToggleSubagentImport").addEventListener("click", () => {
    const d = document.getElementById("subagentImportDrawer");
    d.style.display = d.style.display === "none" ? "block" : "none";
  });
  document.getElementById("btnCopyChatPrompt").addEventListener("click", () => {
    const txt = state._lastSubagentChatPrompt || "";
    if (!txt) return;
    navigator.clipboard.writeText(txt).then(() => toast("✓ 已複製對話指令！請直接貼入 Agent 對話視窗"));
  });
  document.getElementById("btnToggleShards").addEventListener("click", () => {
    const d = document.getElementById("subagentShardsDrawer");
    d.style.display = d.style.display === "none" ? "block" : "none";
  });
  document.getElementById("subagentFileInput").addEventListener("change", handleSubagentFileSelect);
  document.getElementById("btnSubmitSubagentImport").addEventListener("click", submitSubagentImport);

  // API Key 模式事件綁定
  document.getElementById("btnStartAutoAnalyze").addEventListener("click", startAutoAnalyze);
  document.getElementById("btnCancelAutoAnalyze").addEventListener("click", cancelAutoAnalyze);

  await loadCatalog();
  await loadSubagentStatus();
  pollSubagentSync();
  pollAutoAnalyzeStatus();
}

async function loadCatalog() {
  try {
    const data = await api(`/api/projects/${state.projectId}/photos`);
    state._themes = data.themes.map((t) => t.name);
    state._photos = data.photos;
    const sel = document.getElementById("filterTheme");
    if (sel && !sel.dataset.filled) {
      state._themes.forEach((t) => {
        const opt = document.createElement("option");
        opt.value = t; opt.textContent = t;
        sel.appendChild(opt);
      });
      sel.dataset.filled = "1";
    }
    const statsEl = document.getElementById("catalogStats");
    if (statsEl) statsEl.innerHTML = `總數 <b>${data.stats.total}</b> ・ 已分析 <b>${data.stats.analyzed}</b> ・ 待分析 <b>${data.stats.pending}</b>`;
    renderCatalogGrid();
  } catch (e) { toast(e.message, true); }
}

function themeSelectHtml(current) {
  const opts = [`<option value="">（未選擇）</option>`].concat(
    (state._themes || []).map((t) => `<option value="${esc(t)}" ${t === current ? "selected" : ""}>${esc(t)}</option>`)
  );
  return `<select data-role="theme">${opts.join("")}</select>`;
}

function renderCatalogGrid() {
  const grid = document.getElementById("catalogGrid");
  if (!grid) return;
  let photos = state._photos || [];
  if (state.photosFilterPending) photos = photos.filter((p) => !p.analyzed);
  if (state.photosFilterTheme) photos = photos.filter((p) => p.theme === state.photosFilterTheme);

  grid.innerHTML = "";
  photos.forEach((p) => {
    const fx = typeof p.focus_x === "number" ? p.focus_x : 0.5;
    const fy = typeof p.focus_y === "number" ? p.focus_y : 0.38;
    const prots = Array.isArray(p.protagonists) ? p.protagonists : [];

    const card = document.createElement("div");
    card.className = `photo-card ${p.analyzed ? "analyzed" : "pending"} ${state.focusEditMode ? "focus-edit-active" : ""}`;
    card.innerHTML = `
      <div class="thumb-wrap" title="${state.focusEditMode ? '點擊畫面設定 Ken Burns 鏡頭推進焦點' : '點擊放大預覽（按住 Alt 點擊可直接設定焦點）'}">
        <img loading="lazy" src="${thumbUrl(state.projectId, p.filename)}" onerror="this.style.opacity=0.2" alt="${esc(p.filename)}" />
        <div class="focus-reticle" style="left:${(fx * 100).toFixed(1)}%;top:${(fy * 100).toFixed(1)}%;" title="Ken Burns 鏡頭焦點 (${Math.round(fx * 100)}%, ${Math.round(fy * 100)}%)">
          <span class="focus-dot"></span>
        </div>
        <div class="thumb-overlay"><span>${state.focusEditMode ? "🎯 點擊設定焦點" : "🔍"}</span></div>
      </div>
      <div class="body">
        <div class="fname" title="${esc(p.filename)}">${esc(p.filename)}</div>
        <div class="row">
          ${!p.analyzed ? '<span class="badge pending">待分析</span>' : '<span class="badge done">已分析</span>'}
          ${p.source === 'google_photos' ? (p.downloaded ? '<span class="badge done" title="高畫質原圖已下載至本機">🌐 原圖已備</span>' : '<span class="badge" style="background:rgba(66,133,244,0.15);color:#8ab4f8;border:1px solid rgba(66,133,244,0.3);" title="Google 相簿照片（挑中才下載原圖）">🌐 Google相簿</span>') : ''}
          <span class="focus-coord-badge" title="Ken Burns 推進焦點座標 (X, Y)">🎯 ${Math.round(fx * 100)}%,${Math.round(fy * 100)}%</span>
        </div>
        ${p.description ? `<div style="font-size:11px;color:var(--text-dim);margin-bottom:4px;line-height:1.3;max-height:2.6em;overflow:hidden;text-overflow:ellipsis;" title="${esc(p.description)}">${esc(p.description)}</div>` : ''}
        <div class="row">${themeSelectHtml(p.theme)}</div>
        <div class="row">
          <label style="color:var(--text-dim);font-size:11px;">品質評分</label>
          <input type="number" min="0" max="10" step="0.5" data-role="quality" value="${p.quality_score ?? ""}" />
        </div>
        <div class="row" style="margin-top:2px;">
          <input type="text" data-role="protagonists" class="protagonist-input" placeholder="👥 人物/小隊（逗號分隔）" value="${esc(prots.join("、"))}" title="標記照片中的主角或小隊（如：第一小隊、小明），排程時會自動平衡出場次數" />
        </div>
      </div>
    `;
    const thumbWrap = card.querySelector(".thumb-wrap");
    thumbWrap.addEventListener("click", async (ev) => {
      if (state.focusEditMode || ev.altKey) {
        ev.stopPropagation();
        const rect = thumbWrap.getBoundingClientRect();
        const clickX = Math.max(0.08, Math.min(0.92, (ev.clientX - rect.left) / rect.width));
        const clickY = Math.max(0.08, Math.min(0.92, (ev.clientY - rect.top) / rect.height));
        const reticle = card.querySelector(".focus-reticle");
        if (reticle) {
          reticle.style.left = `${(clickX * 100).toFixed(1)}%`;
          reticle.style.top = `${(clickY * 100).toFixed(1)}%`;
        }
        await updatePhoto(p.filename, { focus_x: Number(clickX.toFixed(3)), focus_y: Number(clickY.toFixed(3)) }, true);
        return;
      }
      openFullscreen(imageUrl(state.projectId, p.filename));
    });
    const themeSel = card.querySelector('[data-role="theme"]');
    const qualityInput = card.querySelector('[data-role="quality"]');
    const protInput = card.querySelector('[data-role="protagonists"]');
    const doUpdate = () => updatePhoto(p.filename, {
      theme: themeSel.value || null,
      quality_score: qualityInput.value || null,
      protagonists: protInput.value,
    });
    themeSel.addEventListener("change", doUpdate);
    qualityInput.addEventListener("change", doUpdate);
    protInput.addEventListener("change", () => updatePhoto(p.filename, { protagonists: protInput.value }, true));
    grid.appendChild(card);
  });
}

async function updatePhoto(filename, fields, allowWithoutTheme = false) {
  if (!allowWithoutTheme && !fields.theme) { toast("請先選擇主題再儲存", true); return; }
  try {
    await api(`/api/projects/${state.projectId}/photos/update`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ filename, ...fields }),
    });
    toast(`已更新：${filename}`);
    await loadCatalog();
  } catch (e) { toast(e.message, true); }
}

async function scanPhotos() {
  try {
    const result = await api(`/api/projects/${state.projectId}/photos/scan`, { method: "POST" });
    toast(`掃描完成：新增 ${result.added_pending} 張待分析照片`);
    await loadCatalog();
  } catch (e) { toast(e.message, true); }
}

// ---------------------------------------------------------------
// Subagent 多代理分析整合（CLI <-> Web 雙向同步）
// ---------------------------------------------------------------

async function loadSubagentStatus() {
  try {
    const st = await api(`/api/projects/${state.projectId}/photos/subagent/status`);
    state._lastCatalogUpdatedAt = st.catalog_last_updated;
    state._lastAnalyzedCount = st.stats?.analyzed ?? 0;
    renderSubagentStatusUI(st);
  } catch (e) { /* ignore */ }
}

function renderSubagentStatusUI(st) {
  const statsEl = document.getElementById("subagentSummaryStats");
  if (statsEl && st.stats) {
    const s = st.stats;
    const estAgents = s.pending === 0 ? 0 : s.pending <= 15 ? 1 : s.pending <= 40 ? 2 : s.pending <= 60 ? 3 : Math.ceil(s.pending / 15);
    statsEl.innerHTML = `
      <span class="subagent-stat-pill">待分析 <b>${s.pending}</b> 張</span>
      <span class="subagent-stat-pill">已分析 <b>${s.analyzed}</b> / ${s.total} 張</span>
      <span class="subagent-stat-pill accent">建議派發 <b>${estAgents}</b> 個 Subagent</span>
    `;
  }

  const covEl = document.getElementById("subagentCoverageStrip");
  if (covEl && st.theme_coverage) {
    const entries = Object.entries(st.theme_coverage);
    if (entries.length) {
      covEl.innerHTML = entries.map(([theme, c]) => {
        const hasReq = c.photos_needed > 0;
        const ok = hasReq ? c.analyzed_count >= c.photos_needed : c.analyzed_count > 0;
        const cls = ok ? "ok" : (hasReq && c.deficit > 0 ? "deficit" : "neutral");
        const countTxt = hasReq ? `${c.analyzed_count}/${c.photos_needed}` : `${c.analyzed_count}`;
        return `<span class="cov-mini-badge ${cls}" title="${hasReq ? `時槽需求 ${c.photos_needed} 張，目前已分析 ${c.analyzed_count} 張` : `已分析 ${c.analyzed_count} 張`}">
          <b>${esc(theme)}</b> <span>${countTxt}</span>
        </span>`;
      }).join("");
    } else {
      covEl.innerHTML = "";
    }
  }

  if (st.task && st.task.agent_chat_prompt) {
    renderSubagentTaskBox(st.task);
  }
}

function renderSubagentTaskBox(task) {
  const box = document.getElementById("subagentTaskBox");
  const promptEl = document.getElementById("subagentChatPromptText");
  const drawer = document.getElementById("subagentShardsDrawer");
  if (!box || !promptEl || !drawer) return;

  state._lastSubagentChatPrompt = task.agent_chat_prompt;
  box.style.display = "block";
  promptEl.textContent = task.agent_chat_prompt;

  const shards = task.shards || [];
  const btnShards = document.getElementById("btnToggleShards");
  if (btnShards) {
    btnShards.textContent = `📦 查看 ${shards.length} 組 Shard Prompt`;
    btnShards.style.display = shards.length > 0 ? "inline-flex" : "none";
  }

  if (!shards.length) {
    drawer.innerHTML = `<div class="hint" style="padding:8px;">✅ 目前沒有待分析的照片分組（若要重新分析請勾選「包含已分析照片重新分組」）。</div>`;
    return;
  }

  drawer.innerHTML = shards.map((s) => `
    <div class="shard-item">
      <div class="shard-header">
        <span><b>Shard #${s.shard_id}</b>（${s.photo_count} 張照片：${esc(s.filenames.slice(0, 4).join(", "))}${s.filenames.length > 4 ? "…" : ""}）</span>
        <button class="btn small btnCopyShard" data-shard="${s.shard_id}">📋 複製 Shard #${s.shard_id} Prompt</button>
      </div>
    </div>
  `).join("");

  drawer.querySelectorAll(".btnCopyShard").forEach((btn) => {
    btn.addEventListener("click", () => {
      const sid = parseInt(btn.dataset.shard, 10);
      const found = shards.find((x) => x.shard_id === sid);
      if (found) {
        navigator.clipboard.writeText(found.prompt).then(() => toast(`✓ 已複製 Shard #${sid} 的完整視覺分析 Prompt`));
      }
    });
  });
}

async function prepareSubagentTask() {
  const btn = document.getElementById("btnPrepareSubagent");
  const maxPer = parseInt(document.getElementById("subagentMaxPer")?.value || "15", 10);
  const reanalyze = Boolean(document.getElementById("subagentReanalyze")?.checked);
  try {
    if (btn) { btn.disabled = true; btn.textContent = "準備縮圖與分組中…"; }
    const res = await api(`/api/projects/${state.projectId}/photos/subagent/prepare`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ max_per_agent: maxPer, reanalyze_all: reanalyze }),
    });
    renderSubagentTaskBox(res);
    await loadCatalog();
    await loadSubagentStatus();
    if (res.agent_chat_prompt) {
      try {
        await navigator.clipboard.writeText(res.agent_chat_prompt);
        toast(`⚡ 已產生 ${res.shards.length} 個 Subagent 分組並自動複製對話指令！`);
      } catch (_) {
        toast(`⚡ 已產生 ${res.shards.length} 個 Subagent 分組任務！請點擊複製對話指令`);
      }
    }
  } catch (e) {
    toast(e.message, true);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "⚡ 1. 準備 Subagent 批次任務"; }
  }
}

async function handleSubagentFileSelect(e) {
  const files = Array.from(e.target.files || []);
  if (!files.length) return;
  const texts = [];
  for (const f of files) {
    texts.push(await f.text());
  }
  const ta = document.getElementById("subagentRawJson");
  if (ta) ta.value = texts.join("\n\n");
  toast(`已讀取 ${files.length} 個 JSON 檔案，請點「✓ 立即匯入 Catalog」`);
}

async function submitSubagentImport() {
  const raw = (document.getElementById("subagentRawJson")?.value || "").trim();
  if (!raw) {
    toast("請先貼上 Subagent 回傳的 JSON 或選擇檔案", true);
    return;
  }
  const btn = document.getElementById("btnSubmitSubagentImport");
  try {
    if (btn) { btn.disabled = true; btn.textContent = "匯入中…"; }
    const res = await api(`/api/projects/${state.projectId}/photos/subagent/import`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ raw_json: raw, overwrite: true }),
    });
    toast(`🎉 成功匯入 ${res.total_processed} 張照片分析結果（總進度 ${res.total_analyzed}/${res.total_in_catalog}）！`);
    document.getElementById("subagentRawJson").value = "";
    document.getElementById("subagentImportDrawer").style.display = "none";
    await loadCatalog();
    await loadSubagentStatus();
    await refreshProj();
  } catch (e) {
    toast(e.message, true);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "✓ 立即匯入 Catalog"; }
  }
}

function pollSubagentSync() {
  if (state._subagentPollTimer) {
    clearInterval(state._subagentPollTimer);
    state._subagentPollTimer = null;
  }
  state._subagentPollTimer = setInterval(async () => {
    if (state.tab !== "photos" || !state.projectId) {
      clearInterval(state._subagentPollTimer);
      state._subagentPollTimer = null;
      return;
    }
    try {
      const st = await api(`/api/projects/${state.projectId}/photos/subagent/status`);
      const prevUpd = state._lastCatalogUpdatedAt;
      const prevAnalyzed = state._lastAnalyzedCount;
      if (
        (prevUpd && st.catalog_last_updated && st.catalog_last_updated !== prevUpd) ||
        (prevAnalyzed !== undefined && st.stats.analyzed !== prevAnalyzed)
      ) {
        state._lastCatalogUpdatedAt = st.catalog_last_updated;
        state._lastAnalyzedCount = st.stats.analyzed;
        const pill = document.getElementById("subagentSyncPill");
        if (pill) {
          pill.className = "status-pill done";
          pill.textContent = `✓ 已同步 (${st.stats.analyzed}/${st.stats.total})`;
        }
        toast(`🔄 偵測到 Catalog 更新（已分析 ${st.stats.analyzed}/${st.stats.total} 張），已自動刷新！`);
        renderSubagentStatusUI(st);
        await loadCatalog();
        await refreshProj();
      }
    } catch (_) { /* ignore */ }
  }, 3000);
}

// ---------------------------------------------------------------
// AI 自動分析
// ---------------------------------------------------------------

async function cancelAutoAnalyze() {
  try {
    const btnCancel = document.getElementById("btnCancelAutoAnalyze");
    if (btnCancel) { btnCancel.disabled = true; btnCancel.textContent = "取消中…"; }
    await api(`/api/projects/${state.projectId}/photos/auto_analyze/cancel`, { method: "POST" });
    toast("已送出取消請求");
  } catch (e) {
    toast(e.message, true);
  }
}

async function startAutoAnalyze() {
  const apiKey = (document.getElementById("autoApiKey")?.value || "").trim();
  const model  = document.getElementById("autoModel")?.value  || "gemini-3.5-flash";
  const workers = parseInt(document.getElementById("autoWorkers")?.value || "3", 10);

  if (!apiKey) {
    toast("請先填寫 Gemini API Key（或在⚙️設定頁預先儲存）", true);
    return;
  }

  try {
    const btn = document.getElementById("btnStartAutoAnalyze");
    const btnCancel = document.getElementById("btnCancelAutoAnalyze");
    if (btn) { btn.disabled = true; btn.textContent = "分析中…"; btn.style.display = "none"; }
    if (btnCancel) { btnCancel.disabled = false; btnCancel.textContent = "🛑 取消"; btnCancel.style.display = "block"; }

    await api(`/api/projects/${state.projectId}/photos/auto_analyze/start`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ api_key: apiKey, model, max_workers: workers }),
    });
    toast(`已啟動 AI 分析（${model}），正在背景處理…`);
    pollAutoAnalyzeStatus();
  } catch (e) {
    const btn = document.getElementById("btnStartAutoAnalyze");
    const btnCancel = document.getElementById("btnCancelAutoAnalyze");
    if (btn) { btn.disabled = false; btn.textContent = "▶ 開始 AI 分析"; btn.style.display = "block"; }
    if (btnCancel) { btnCancel.style.display = "none"; }
    toast(e.message, true);
  }
}

async function pollAutoAnalyzeStatus() {
  // 清除任何舊的 poll timer（避免重複）
  if (state._autoAnalyzePollTimer) {
    clearInterval(state._autoAnalyzePollTimer);
    state._autoAnalyzePollTimer = null;
  }
  let failCount = 0;

  const tick = async () => {
    try {
      const s = await api(`/api/projects/${state.projectId}/photos/auto_analyze/status`);
      failCount = 0;
      const pill   = document.getElementById("autoAnalyzeStatus");
      const logEl  = document.getElementById("autoAnalyzeLog");
      const progWrap = document.getElementById("autoAnalyzeProgress");
      const progBar  = document.getElementById("autoAnalyzeBar");
      const progLabel = document.getElementById("autoAnalyzeLabel");
      const btn    = document.getElementById("btnStartAutoAnalyze");
      const resetBtns = () => {
        if (btn) { btn.disabled = false; btn.textContent = "▶ 開始 AI 分析"; btn.style.display = "block"; }
        const btnCancel = document.getElementById("btnCancelAutoAnalyze");
        if (btnCancel) { btnCancel.style.display = "none"; }
      };

      if (!pill) { clearInterval(state._autoAnalyzePollTimer); return; }

      // 更新狀態 pill
      const statusMap = { idle: "待機", running: "分析中…", done: "已完成", error: "發生錯誤" };
      pill.className = `status-pill ${s.status}`;
      pill.textContent = statusMap[s.status] || s.status;

      // 進度條
      if (s.progress && s.progress.total > 0) {
        progWrap.style.display = "block";
        const pct = Math.round((s.progress.done / s.progress.total) * 100);
        progBar.style.width = `${pct}%`;
        progLabel.textContent = `${s.progress.phase || ""}  ${s.progress.done} / ${s.progress.total} 張`;
      }

      // Log 視窗
      if (s.log && s.log.length) {
        logEl.style.display = "block";
        logEl.textContent = s.log.join("\n");
        logEl.scrollTop = logEl.scrollHeight;
      }

      if (s.status === "done") {
        clearInterval(state._autoAnalyzePollTimer);
        state._autoAnalyzePollTimer = null;
        resetBtns();
        const res = s.result || {};
        toast(`🎉 AI 分析完成！成功 ${res.analyzed || 0} 張，失敗 ${res.failed || 0} 張。`);
        await loadCatalog();  // 刷新照片網格
      } else if (s.status === "error") {
        clearInterval(state._autoAnalyzePollTimer);
        state._autoAnalyzePollTimer = null;
        resetBtns();
        toast(s.error || "分析失敗", true);
      } else if (s.status === "running") {
        if (btn) { btn.disabled = true; btn.textContent = "分析中…"; btn.style.display = "none"; }
        const btnCancel = document.getElementById("btnCancelAutoAnalyze");
        if (btnCancel && btnCancel.textContent !== "取消中…") {
          btnCancel.disabled = false; btnCancel.textContent = "🛑 取消"; btnCancel.style.display = "block";
        }
      }
    } catch (e) {
      failCount++;
      if (failCount > 3) {
        clearInterval(state._autoAnalyzePollTimer);
        state._autoAnalyzePollTimer = null;
        const btn = document.getElementById("btnStartAutoAnalyze");
        if (btn) { btn.disabled = false; btn.textContent = "▶ 開始 AI 分析"; btn.style.display = "block"; }
        const btnCancel = document.getElementById("btnCancelAutoAnalyze");
        if (btnCancel) { btnCancel.style.display = "none"; }
        const pill = document.getElementById("autoAnalyzeStatus");
        if (pill) { pill.className = "status-pill error"; pill.textContent = "伺服器已斷線"; }
        toast("伺服器失去連線，請確認系統終端機是否已關閉", true);
      }
    }
  };

  await tick();
  state._autoAnalyzePollTimer = setInterval(tick, 2500);
}

// ===============================================================
// 全屏預覽
// ===============================================================

function initFullscreenOverlay() {
  const overlay = document.getElementById("fullscreenOverlay");
  const closeBtn = document.getElementById("fullscreenClose");
  if (!overlay || !closeBtn) return;

  const close = () => overlay.classList.add("hidden");
  closeBtn.addEventListener("click", close);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !overlay.classList.contains("hidden")) close();
  });
}

function openFullscreen(url) {
  const overlay = document.getElementById("fullscreenOverlay");
  const img = document.getElementById("fullscreenImg");
  img.src = url;
  overlay.classList.remove("hidden");
}

// ===============================================================
// 分頁 5：照片挑選（Manifest — 主題群組視圖）
// ===============================================================

async function renderManifestTab(proj) {
  const el = document.getElementById("tabContent");
  const defaultWeight = (proj.slot_params || {}).protagonist_weight ?? 2.5;
  el.innerHTML = `
    <div class="toolbar">
      <div class="duration-badge" id="durationBadge">— / — 秒</div>
      <div id="manifestBeatBadge"></div>
      <div class="spacer"></div>
      <label class="filter-label" title="排程時對低出場率人物/小隊的加權力道（0 = 不加權，建議 2.5）">
        👥 人物均衡權重
        <input type="number" id="manifestProtagonistWeight" step="0.5" min="0" max="10" value="${defaultWeight}" style="width:64px;padding:4px 6px;margin-left:4px;" />
      </label>
      <button id="btnAutobuild" class="btn warn">⚡ 重新自動分配（覆蓋手動調整）</button>
    </div>

    <!-- Google 相簿已挑選原圖下載狀態列 -->
    <div id="gphotosDlBar" class="gphotos-dl-bar" style="display:none;margin-bottom:14px;">
      <div style="display:flex;align-items:center;gap:12px;flex:1;min-width:0;">
        <span style="font-size:22px;">🌐</span>
        <div style="font-size:12px;line-height:1.45;" id="gphotosDlDesc"></div>
      </div>
      <button id="btnDownloadSelectedGPhotos" class="btn primary small" style="white-space:nowrap;">📥 下載已挑選照片原圖</button>
    </div>

    <!-- 主題覆蓋率儀表板 -->
    <div id="coverageDashboard" class="coverage-dashboard" style="margin-bottom:14px;"></div>

    <!-- 人物出場均衡度儀表板 -->
    <div id="protagonistDashboard" class="protagonist-dashboard" style="margin-bottom:24px;"></div>

    <!-- 主題群組時間軸 -->
    <div id="timelineGroups"></div>
  `;
  document.getElementById("btnAutobuild").addEventListener("click", autobuild);
  await loadManifest();
}

async function loadManifest() {
  const badge = document.getElementById("durationBadge");
  const beatEl = document.getElementById("manifestBeatBadge");
  try {
    const data = await api(`/api/projects/${state.projectId}/manifest`);
    const mismatch = Math.abs(data.total_duration_calc - data.total_duration) > 0.1;
    if (badge) {
      badge.textContent = `時間軸總長 ${data.total_duration_calc.toFixed(1)}s / 音樂長度 ${data.total_duration.toFixed(1)}s`;
      badge.classList.toggle("mismatch", mismatch);
    }
    if (beatEl) {
      if (data.bpm && data.bpm > 0) {
        beatEl.innerHTML = `<span class="beat-summary-pill">🥁 ${data.bpm} BPM ・ ${data.beat_snapped_slots || 0} 個時槽踩拍對齊</span>`;
      } else {
        beatEl.innerHTML = "";
      }
    }
    renderCoverageDashboard(data.slots);
    renderProtagonistDashboard(data.protagonist_stats || {});
    renderTimelineGroups(data.slots);

    // Google 相簿挑選狀態列渲染
    const gpStatus = data.gphotos_status;
    const dlBar = document.getElementById("gphotosDlBar");
    const dlDesc = document.getElementById("gphotosDlDesc");
    const dlBtn = document.getElementById("btnDownloadSelectedGPhotos");
    if (dlBar && gpStatus && gpStatus.has_manifest) {
      if (gpStatus.pending_count > 0) {
        dlBar.style.display = "flex";
        dlDesc.innerHTML = `<b>Google 相簿挑選進度</b>：時間軸共正式指派 <b>${gpStatus.total_selected}</b> 張照片，尚有 <b style="color:var(--orange)">${gpStatus.pending_count}</b> 張待下載原圖。<br/><span style="color:var(--text-dim);font-size:11px;">💡 輕量挑選模式：未挑中的照片不會下載，僅挑中這 ${gpStatus.total_selected} 張才會下載最高畫質原圖（開始渲染時亦會自動下載把關）。</span>`;
        dlBtn.disabled = false;
        dlBtn.textContent = `📥 立即下載這 ${gpStatus.pending_count} 張原圖`;
      } else if (gpStatus.total_selected > 0) {
        dlBar.style.display = "flex";
        dlDesc.innerHTML = `<b>Google 相簿挑選完成</b>：正式挑選的 <b>${gpStatus.downloaded_count}</b> 張照片原圖皆已全數下載就緒！`;
        dlBtn.disabled = true;
        dlBtn.textContent = `✓ 原圖已全數備妥`;
      } else {
        dlBar.style.display = "none";
      }

      if (dlBtn && !dlBtn.dataset.bound) {
        dlBtn.dataset.bound = "1";
        dlBtn.addEventListener("click", async () => {
          try {
            dlBtn.disabled = true;
            dlBtn.textContent = "⏳ 下載中...";
            toast("📥 正在下載已挑選的 Google 相簿原圖，請稍候...");
            const res = await api(`/api/projects/${state.projectId}/photos/gphotos/download_selected`, { method: "POST" });
            toast(`🎉 原圖下載完成！成功下載 ${res.downloaded} 張。`);
            await loadManifest();
          } catch (err) {
            toast(err.message, true);
            dlBtn.disabled = false;
          }
        });
      }
    }
  } catch (e) {
    const groups = document.getElementById("timelineGroups");
    if (groups) groups.innerHTML = `<p class="hint">${esc(e.message)}</p>`;
  }
}

function renderProtagonistDashboard(pstats) {
  const el = document.getElementById("protagonistDashboard");
  if (!el) return;
  const items = Array.isArray(pstats)
    ? pstats
    : Object.entries(pstats || {}).map(([name, v]) => ({ name, ...v }));
  if (!items.length) {
    el.innerHTML = `
      <div class="protagonist-empty-bar">
        <span>👥 <b>人物 / 小隊出場均衡度控制</b>：目前照片尚未標記人物或小隊標籤。可在「📷 照片分析」分頁透過 AI 分析或手動輸入標籤（如：第一小隊、王小明），排程時即會自動平衡各方出場次數。</span>
      </div>
    `;
    return;
  }
  const maxAssigned = Math.max(1, ...items.map((v) => v.assigned_slots || 0));
  const zeroCount = items.filter((v) => (v.assigned_slots || 0) === 0).length;
  el.innerHTML = `
    <div class="protagonist-panel">
      <div class="protagonist-panel-header">
        <span>👥 <b>人物 / 小隊出場均衡度儀表板</b>（共追蹤 ${items.length} 位人物/組別）</span>
        <span style="font-size:11px;color:${zeroCount > 0 ? 'var(--orange)' : 'var(--green)'};">
          ${zeroCount > 0 ? `⚠️ 尚有 ${zeroCount} 位/組未出場` : "✓ 所有標記人物/小隊皆有出場機會"}
        </span>
      </div>
      <div class="protagonist-pills">
        ${items.map((info) => {
          const name = info.name || "未命名";
          const cnt = info.assigned_slots || 0;
          const catCnt = info.catalog_photos || 0;
          const sec = info.total_seconds ? `・${info.total_seconds.toFixed(1)}s` : "";
          const pct = Math.round((cnt / maxAssigned) * 100);
          const cls = cnt === 0 ? "zero" : cnt === 1 ? "low" : "ok";
          return `
            <div class="protagonist-chip ${cls}" title="已出場 ${cnt} 次 (${info.total_seconds || 0}s) / 照片庫共有 ${catCnt} 張包含「${esc(name)}」">
              <div class="protagonist-chip-top">
                <span class="pname">${esc(name)}</span>
                <span class="pcount"><b>${cnt}</b> 次 <small>/ ${catCnt}張${sec}</small></span>
              </div>
              <div class="protagonist-mini-bar"><div style="width:${pct}%"></div></div>
            </div>
          `;
        }).join("")}
      </div>
    </div>
  `;
}

// 主題覆蓋率儀表板
function renderCoverageDashboard(slots) {
  const dashboard = document.getElementById("coverageDashboard");
  if (!dashboard) return;

  // 計算各主題需求 vs 已填滿
  const themeStats = {};
  slots.forEach((s) => {
    if (s.is_fixed) return;
    if (!themeStats[s.theme]) themeStats[s.theme] = { total: 0, filled: 0 };
    themeStats[s.theme].total++;
    if (!s.missing) themeStats[s.theme].filled++;
  });

  dashboard.innerHTML = "";
  Object.entries(themeStats).forEach(([theme, stat]) => {
    const pct = stat.total > 0 ? Math.round((stat.filled / stat.total) * 100) : 100;
    const status = pct >= 100 ? "complete" : pct === 0 ? "missing" : "partial";
    const card = document.createElement("div");
    card.className = `coverage-card ${status}`;
    card.innerHTML = `
      <div class="coverage-theme-name">
        <span>${esc(theme)}</span>
        <span class="coverage-count">${stat.filled}/${stat.total}</span>
      </div>
      <div class="coverage-bar-outer">
        <div class="coverage-bar-inner" style="width:${pct}%"></div>
      </div>
      ${stat.filled < stat.total ? `<div class="coverage-need">還缺 ${stat.total - stat.filled} 張</div>` : '<div style="font-size:10px;color:var(--green);">✓ 已填滿</div>'}
    `;
    // 點擊跳到該主題群組
    card.style.cursor = "pointer";
    card.addEventListener("click", () => {
      const group = document.querySelector(`[data-theme-group="${CSS.escape(theme)}"]`);
      if (group) group.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    dashboard.appendChild(card);
  });
}

// 主題群組視圖
function renderTimelineGroups(slots) {
  const container = document.getElementById("timelineGroups");
  if (!container) return;

  // 按主題分組
  const groups = {};
  const groupOrder = [];
  slots.forEach((s) => {
    if (!groups[s.theme]) {
      groups[s.theme] = [];
      groupOrder.push(s.theme);
    }
    groups[s.theme].push(s);
  });

  container.innerHTML = "";
  groupOrder.forEach((theme) => {
    const themeSlots = groups[theme];
    const totalDur = themeSlots.reduce((a, s) => a + s.duration, 0);
    const missingCount = themeSlots.filter((s) => s.missing && !s.is_fixed).length;

    const groupEl = document.createElement("div");
    groupEl.className = "theme-group";
    groupEl.dataset.themeGroup = theme;

    const headerEl = document.createElement("div");
    headerEl.className = "theme-group-header";
    headerEl.innerHTML = `
      <span class="theme-group-label theme-${CSS.escape(theme)}">${esc(theme)}</span>
      <span class="theme-group-meta">${themeSlots.length} 個時槽 ・ ${totalDur.toFixed(1)}s</span>
      ${missingCount > 0 ? `<span class="badge pending">缺 ${missingCount} 張</span>` : `<span class="badge done">全部填滿</span>`}
    `;
    groupEl.appendChild(headerEl);

    const slotsGrid = document.createElement("div");
    slotsGrid.className = "slots-grid";

    themeSlots.forEach((s) => {
      const card = buildSlotCard(s);
      slotsGrid.appendChild(card);
    });

    groupEl.appendChild(slotsGrid);
    container.appendChild(groupEl);
  });
}

function buildSlotCard(s) {
  const card = document.createElement("div");
  card.className = `slot-card ${s.missing ? "missing" : ""} ${s.is_fixed ? "fixed" : ""}`;
  const imgSrc = s.filename ? thumbUrl(state.projectId, s.filename) : "";
  const fx = typeof s.focus_x === "number" ? s.focus_x : 0.5;
  const fy = typeof s.focus_y === "number" ? s.focus_y : 0.38;
  const prots = Array.isArray(s.protagonists) ? s.protagonists : [];
  const beatChip = s.beat_snapped
    ? `<span class="slot-beat-badge" title="切點已對齊音樂重拍 (${s.beat_offset_ms > 0 ? '+' : ''}${s.beat_offset_ms || 0}ms)">🥁</span>`
    : "";
  card.innerHTML = `
    <div class="slot-thumb-box" style="position:relative;">
      <img loading="lazy" src="${imgSrc}" onerror="this.style.opacity=0.1" alt="${esc(s.filename || '')}" />
      ${!s.missing && !s.is_fixed ? `<span class="slot-focus-dot" style="left:${(fx * 100).toFixed(1)}%;top:${(fy * 100).toFixed(1)}%;" title="Ken Burns 鏡頭焦點 (${Math.round(fx * 100)}%, ${Math.round(fy * 100)}%)"></span>` : ""}
      ${beatChip}
    </div>
    ${s.missing && !s.is_fixed ? '<span class="missing-label">缺</span>' : ""}
    ${!s.is_fixed ? '<div class="choose-btn">📷</div>' : ""}
    <div class="meta">
      <div class="slot-sub" title="${esc(s.subtitle || "")}">${esc(s.subtitle || (s.is_gap ? "（間奏）" : s.is_fixed ? "（固定素材）" : ""))}</div>
      <div class="slot-info">
        <span>#${s.slot_id}</span>
        <span style="color:${s.missing ? 'var(--red)' : 'var(--text-muted)'};">${esc(s.filename ? shortenFilename(s.filename) : "（未分配）")}</span>
      </div>
      ${prots.length ? `<div class="slot-prots" title="主角/小隊：${esc(prots.join('、'))}">👥 ${esc(prots.slice(0, 2).join("・"))}${prots.length > 2 ? "…" : ""}</div>` : ""}
      ${!s.is_fixed ? `<input class="dur-input" type="number" step="0.1" min="0.1" value="${s.duration.toFixed(2)}" />` : `<div style="font-size:10px;color:var(--text-muted);margin-top:4px;">${s.duration.toFixed(2)}s</div>`}
    </div>
  `;
  if (!s.is_fixed) {
    card.addEventListener("click", (ev) => {
      if (ev.target.classList.contains("dur-input")) return;
      openPickerModal(s.slot_id, s.theme, s.filename, s.subtitle);
    });
    const durInput = card.querySelector(".dur-input");
    durInput.addEventListener("click", (ev) => ev.stopPropagation());
    durInput.addEventListener("change", () => updateDuration(s.slot_id, durInput.value));
  } else {
    // 固定素材點擊可全屏預覽
    card.addEventListener("click", () => {
      if (s.filename) openFullscreen(imageUrl(state.projectId, s.filename));
    });
    card.style.cursor = "zoom-in";
  }
  return card;
}

function shortenFilename(fn) {
  if (!fn) return "";
  const parts = fn.split(/[\\/]/);
  const base = parts[parts.length - 1];
  return base.length > 18 ? base.slice(0, 16) + "…" : base;
}

async function updateDuration(slotId, duration) {
  try {
    const data = await api(`/api/projects/${state.projectId}/manifest/duration`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ slot_id: slotId, duration }),
    });
    toast(`時長已更新（總長 ${data.total_duration_calc.toFixed(1)}s）`);
    await loadManifest();
  } catch (e) { toast(e.message, true); }
}

async function autobuild() {
  if (!confirm("這會重新以自動邏輯分配所有照片，覆蓋掉你目前手動調整的結果，確定要繼續嗎？")) return;
  try {
    const weightEl = document.getElementById("manifestProtagonistWeight");
    const protagonist_weight = weightEl ? parseFloat(weightEl.value) || 0 : 2.5;
    const data = await api(`/api/projects/${state.projectId}/manifest/autobuild`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ protagonist_weight }),
    });
    toast(`自動分配完成（P1=${data.stats.P1} P2=${data.stats.P2} P3=${data.stats.P3}，人物均衡權重=${protagonist_weight}）`);
    await loadManifest();
  } catch (e) { toast(e.message, true); }
}

// ===============================================================
// 升級版 Picker Modal
// ===============================================================

function initPickerModal() {
  const overlay = document.getElementById("pickerModal");
  const closeBtn = document.getElementById("pickerClose");
  const confirmBtn = document.getElementById("pickerConfirm");
  const prevBtn = document.getElementById("pickerPrev");
  const nextBtn = document.getElementById("pickerNext");
  const sortSel = document.getElementById("pickerSort");
  const themeFilter = document.getElementById("pickerThemeFilter");

  if (!overlay) return;

  closeBtn.addEventListener("click", closePickerModal);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closePickerModal(); });

  confirmBtn.addEventListener("click", () => {
    const sel = state.pickerItems[state.pickerSelectedIdx];
    if (sel) assignPhoto(state.pickerSlotId, sel.filename);
  });

  prevBtn.addEventListener("click", () => navigatePickerItem(-1));
  nextBtn.addEventListener("click", () => navigatePickerItem(1));

  sortSel.addEventListener("change", renderPickerGrid);
  themeFilter.addEventListener("change", renderPickerGrid);

  // 鍵盤導覽
  document.addEventListener("keydown", (e) => {
    if (overlay.classList.contains("hidden")) return;
    if (e.key === "Escape") { closePickerModal(); return; }
    if (e.key === "ArrowLeft")  { navigatePickerItem(-1); return; }
    if (e.key === "ArrowRight") { navigatePickerItem(1);  return; }
    if (e.key === "Enter") {
      const sel = state.pickerItems[state.pickerSelectedIdx];
      if (sel) assignPhoto(state.pickerSlotId, sel.filename);
    }
  });
}

async function openPickerModal(slotId, theme, currentFilename, subtitle) {
  state.pickerSlotId = slotId;
  state.pickerTheme = theme;
  state.pickerCurrentAssigned = currentFilename || null;
  state.pickerSelectedIdx = -1;

  const overlay = document.getElementById("pickerModal");
  document.getElementById("pickerTitle").textContent = `Slot #${slotId} — ${theme} 主題`;
  document.getElementById("pickerSub").textContent = subtitle ? `「${subtitle}」` : "";
  document.getElementById("pickerPreviewImg").style.display = "none";
  document.getElementById("pickerPreviewPlaceholder").style.display = "block";
  document.getElementById("pickerNav").style.display = "none";
  document.getElementById("previewFilename").textContent = "—";
  document.getElementById("previewBadges").innerHTML = "";
  document.getElementById("pickerConfirm").disabled = true;
  document.getElementById("pickerGrid").innerHTML = '<div style="padding:20px;color:var(--text-dim)">載入中...</div>';

  // 填充主題篩選器
  const themeFilter = document.getElementById("pickerThemeFilter");
  themeFilter.innerHTML = '<option value="">全部主題</option>';
  (state._themes || []).forEach((t) => {
    const opt = document.createElement("option");
    opt.value = t; opt.textContent = t;
    if (t === theme) opt.selected = true;
    themeFilter.appendChild(opt);
  });

  overlay.classList.remove("hidden");

  try {
    const data = await api(`/api/projects/${state.projectId}/photos/picker?theme=${encodeURIComponent(theme)}`);
    state.pickerItems = data.items;
    renderPickerGrid();

    // 如果已有分配的照片，自動預覽
    if (currentFilename) {
      const idx = state.pickerItems.findIndex((it) => it.filename === currentFilename);
      if (idx >= 0) selectPickerItem(idx);
    }
  } catch (e) {
    document.getElementById("pickerGrid").innerHTML = `<p style="color:var(--red);padding:12px;">${esc(e.message)}</p>`;
  }
}

function renderPickerGrid() {
  const sortMode = document.getElementById("pickerSort").value;
  const themeMode = document.getElementById("pickerThemeFilter").value;
  const grid = document.getElementById("pickerGrid");

  let items = [...state.pickerItems];

  // 主題篩選
  if (themeMode) items = items.filter((it) => it.theme === themeMode);

  // 排序
  if (sortMode === "fit") {
    items.sort((a, b) => (b.fit_score || 0) - (a.fit_score || 0));
  } else if (sortMode === "quality") {
    items.sort((a, b) => (b.quality_score || 0) - (a.quality_score || 0));
  } else if (sortMode === "used") {
    items.sort((a, b) => (a.used_count || 0) - (b.used_count || 0));
  }

  document.getElementById("pickerCount").textContent = `${items.length} 張`;

  grid.innerHTML = "";
  if (items.length === 0) {
    grid.innerHTML = '<p style="color:var(--text-dim);padding:12px;font-size:12px;">沒有符合條件的已分析照片。</p>';
    return;
  }

  // 建立顯示序列（用於鍵盤導覽，以顯示後的 items 為主）
  state._filteredPickerItems = items;

  items.forEach((it, displayIdx) => {
    const card = document.createElement("div");
    const isAssigned = it.filename === state.pickerCurrentAssigned;
    card.className = `picker-thumb${isAssigned ? " current-assigned" : ""}`;
    card.dataset.filename = it.filename;

    card.innerHTML = `
      <img loading="lazy" src="${thumbUrl(state.projectId, it.filename)}" onerror="this.style.opacity=0.2" alt="${esc(it.filename)}" />
      ${it.used_count > 0 ? `<div class="used-badge">已用 ${it.used_count}x</div>` : ""}
      ${it.theme ? `<div class="theme-dot">${esc(it.theme)}</div>` : ""}
      ${it.source === 'google_photos' ? `<div style="position:absolute;top:6px;left:6px;background:rgba(20,24,35,0.85);color:#8ab4f8;border:1px solid rgba(66,133,244,0.4);border-radius:4px;padding:1px 5px;font-size:10px;font-weight:600;">🌐 Google</div>` : ''}
      <div class="pt-meta">${esc(shortenFilename(it.filename))}</div>
      <div class="pt-scores">
        <span class="fit-score">適配 ${(it.fit_score || 0).toFixed(1)}</span>
        <span class="quality">Q ${(it.quality_score || 0).toFixed(1)}</span>
      </div>
    `;

    card.addEventListener("click", () => {
      // 找到在 state.pickerItems 中的真實 idx
      const realIdx = state.pickerItems.findIndex((x) => x.filename === it.filename);
      if (realIdx >= 0) selectPickerItem(realIdx);
      state._filteredPickerItems = items;
      state._filteredSelectedIdx = displayIdx;
    });
    grid.appendChild(card);
  });
}

function selectPickerItem(idx) {
  if (idx < 0 || idx >= state.pickerItems.length) return;
  state.pickerSelectedIdx = idx;
  const item = state.pickerItems[idx];

  // 更新縮圖選中狀態（遍歷顯示中的縮圖）
  document.querySelectorAll(".picker-thumb").forEach((el) => {
    el.classList.toggle("selected", el.dataset.filename === item.filename);
  });

  // 大圖預覽
  const img = document.getElementById("pickerPreviewImg");
  const placeholder = document.getElementById("pickerPreviewPlaceholder");
  img.style.opacity = "0";
  img.style.display = "block";
  placeholder.style.display = "none";
  img.onload = () => { img.style.opacity = "1"; };
  img.src = imageUrl(state.projectId, item.filename);

  // 顯示導覽按鈕
  document.getElementById("pickerNav").style.display = "flex";

  // 更新資訊列
  const prots = Array.isArray(item.protagonists) ? item.protagonists : [];
  const fx = typeof item.focus_x === "number" ? item.focus_x : 0.5;
  const fy = typeof item.focus_y === "number" ? item.focus_y : 0.38;
  document.getElementById("previewFilename").textContent = item.filename;
  document.getElementById("previewBadges").innerHTML = `
    <span class="preview-score-badge">主題 <span>${esc(item.theme || "—")}</span></span>
    <span class="preview-score-badge">適配分 <span>${(item.fit_score || 0).toFixed(1)}</span></span>
    <span class="preview-score-badge">品質分 <span>${(item.quality_score || 0).toFixed(1)}</span></span>
    <span class="preview-score-badge">已用 <span>${item.used_count || 0}</span> 次</span>
    ${item.source === 'google_photos' ? `<span class="preview-score-badge" style="background:rgba(66,133,244,0.15);color:#8ab4f8;border:1px solid rgba(66,133,244,0.35);">🌐 Google 相簿${item.downloaded ? '（原圖已就緒）' : '（確認挑中才下載原圖）'}</span>` : ''}
    <span class="preview-score-badge">🎯 焦點 <span>${Math.round(fx * 100)}%, ${Math.round(fy * 100)}%</span></span>
    ${prots.length ? `<span class="preview-score-badge">👥 人物 <span>${esc(prots.join("、"))}</span></span>` : ""}
    ${item.description ? `<div style="margin-top:8px;font-size:12px;color:var(--text-dim);line-height:1.4;">📝 ${esc(item.description)}</div>` : ''}
  `;

  // 啟用確認按鈕
  const confirmBtn = document.getElementById("pickerConfirm");
  confirmBtn.disabled = false;
  confirmBtn.textContent = item.filename === state.pickerCurrentAssigned ? "✓ 保持此照片" : "✓ 選用此照片";
}

function navigatePickerItem(direction) {
  // 優先在篩選後的列表中導覽
  const filtered = state._filteredPickerItems || state.pickerItems;
  if (!filtered.length) return;

  let curDisplayIdx = state._filteredSelectedIdx ?? -1;
  curDisplayIdx = (curDisplayIdx + direction + filtered.length) % filtered.length;
  state._filteredSelectedIdx = curDisplayIdx;

  const item = filtered[curDisplayIdx];
  const realIdx = state.pickerItems.findIndex((x) => x.filename === item.filename);
  if (realIdx >= 0) selectPickerItem(realIdx);

  // 讓對應縮圖滾入可見範圍
  const thumb = document.querySelector(`.picker-thumb[data-filename="${CSS.escape(item.filename)}"]`);
  if (thumb) thumb.scrollIntoView({ block: "nearest" });
}

function closePickerModal() {
  document.getElementById("pickerModal").classList.add("hidden");
  state.pickerSlotId = null;
  state.pickerItems = [];
  state.pickerSelectedIdx = -1;
  state._filteredPickerItems = null;
  state._filteredSelectedIdx = -1;
}

async function assignPhoto(slotId, filename) {
  try {
    await api(`/api/projects/${state.projectId}/manifest/assign`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slot_id: slotId, filename }),
    });
    toast(`✓ 已指派「${shortenFilename(filename)}」到 Slot #${slotId}`);
    closePickerModal();
    await loadManifest();
  } catch (e) { toast(e.message, true); }
}

// ===============================================================
// 分頁 6：渲染
// ===============================================================

async function renderRenderTab(proj) {
  const el = document.getElementById("tabContent");
  el.innerHTML = `
    <div class="toolbar">
      <button id="btnStartRender" class="btn primary">🎬 開始渲染</button>
      <span id="renderStatusPill" class="status-pill idle">尚未執行</span>
    </div>
    <div id="renderProgressWrap" style="display:none;margin-bottom:16px;">
      <div class="progress-bar-outer"><div id="renderProgressBar" class="progress-bar-inner" style="width:0%"></div></div>
      <div id="renderProgressLabel" class="hint" style="margin-top:6px;"></div>
    </div>
    <div id="renderLog" class="log-console" style="display:none;"></div>
    <div id="renderPreviewArea"></div>
  `;
  document.getElementById("btnStartRender").addEventListener("click", async () => {
    try {
      await api(`/api/projects/${state.projectId}/render/start`, { method: "POST" });
      toast("已開始渲染，這可能需要數分鐘，請耐心等候");
      pollRenderStatus();
    } catch (e) { toast(e.message, true); }
  });
  pollRenderStatus();
}

async function pollRenderStatus() {
  clearPoll();
  const tick = async () => {
    try {
      const s = await api(`/api/projects/${state.projectId}/render/status`);
      const pill = document.getElementById("renderStatusPill");
      if (!pill) { clearPoll(); return; }
      pill.className = `status-pill ${s.status}`;
      pill.textContent = { idle: "尚未執行", running: "渲染中…", done: "已完成", error: "發生錯誤" }[s.status] || s.status;

      const wrap = document.getElementById("renderProgressWrap");
      if (s.progress && s.progress.total > 0) {
        wrap.style.display = "block";
        const pct = Math.round((s.progress.done / s.progress.total) * 100);
        document.getElementById("renderProgressBar").style.width = `${pct}%`;
        document.getElementById("renderProgressLabel").textContent = `${s.progress.phase || ""} ${s.progress.done}/${s.progress.total}`;
      }

      const logEl = document.getElementById("renderLog");
      if (s.log && s.log.length) {
        logEl.style.display = "block";
        logEl.textContent = s.log.join("\n");
        logEl.scrollTop = logEl.scrollHeight;
      }

      if (s.status === "done") {
        clearPoll(); toast("🎉 渲染完成！"); showRenderPreview();
      } else if (s.status === "error") {
        clearPoll(); toast(s.error || "渲染失敗", true);
      }
    } catch (e) { /* ignore */ }
  };
  await tick();
  await showRenderPreview(true);
  state.pollTimer = setInterval(tick, 2000);
}

async function showRenderPreview(quiet = false) {
  const area = document.getElementById("renderPreviewArea");
  if (!area) return;
  try {
    const s = await api(`/api/projects/${state.projectId}/render/status`);
    if (s.status !== "done" && !(s.result && s.result.output_file)) {
      if (!quiet) area.innerHTML = "";
      return;
    }
    area.innerHTML = `
      <h2>預覽</h2>
      <video class="render-video" controls src="/api/projects/${state.projectId}/render/preview"></video>
      <div style="margin-top:12px;">
        <a href="/api/projects/${state.projectId}/render/download" class="btn">⬇️ 下載影片</a>
      </div>
    `;
  } catch (e) { /* ignore */ }
}

// ===============================================================
// 📂 檔案 / 資料夾瀏覽器 Modal（免 Copy-Paste 直接點選路徑）
// ===============================================================

const fsState = {
  targetInputId: null,
  mode: "all",          // 'dir' | 'audio' | 'srt' | 'image' | 'output' | 'all'
  relativeToPhotosDir: false,
  autoApplyCompanions: false,
  currentDir: "",
  parentDir: null,
  entries: [],
  companions: {},
  currentStats: {},
  selectedPath: "",
  searchQuery: "",
};

function initFsBrowserModal() {
  const modal = document.getElementById("fsBrowserModal");
  if (!modal) return;

  const close = () => modal.classList.add("hidden");
  document.getElementById("fsModalClose").addEventListener("click", close);
  document.getElementById("fsCancelBtn").addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });

  document.getElementById("fsUpBtn").addEventListener("click", () => {
    if (fsState.parentDir) loadFsDirectory(fsState.parentDir);
  });

  document.getElementById("fsSearchInput").addEventListener("input", (e) => {
    fsState.searchQuery = e.target.value.trim().toLowerCase();
    renderFsEntries();
  });

  document.getElementById("fsShowAllChk").addEventListener("change", () => {
    loadFsDirectory(fsState.currentDir);
  });

  document.getElementById("fsSelectedPathInput").addEventListener("input", (e) => {
    fsState.selectedPath = e.target.value.trim();
  });

  document.getElementById("fsConfirmBtn").addEventListener("click", () => {
    applyFsSelection(fsState.selectedPath, fsState.autoApplyCompanions);
  });

  document.getElementById("fsCompanionFillBtn").addEventListener("click", () => {
    applyFsSelection(fsState.selectedPath, true);
  });

  document.getElementById("fsNativePickBtn").addEventListener("click", async () => {
    await triggerNativePick(fsState.targetInputId, fsState.mode, fsState.currentDir, true);
  });

  document.addEventListener("keydown", (e) => {
    if (modal.classList.contains("hidden")) return;
    if (e.key === "Escape") close();
  });
}

async function openFsBrowser({
  targetInputId,
  mode = "all",
  title = "📂 選擇路徑",
  initialPath = "",
  relativeToPhotosDir = false,
  autoApplyCompanions = false,
  onSelectCallback = null,
}) {
  fsState.targetInputId = targetInputId;
  fsState.mode = mode;
  fsState.relativeToPhotosDir = relativeToPhotosDir;
  fsState.autoApplyCompanions = autoApplyCompanions;
  fsState.onSelectCallback = onSelectCallback;
  fsState.searchQuery = "";

  const searchEl = document.getElementById("fsSearchInput");
  if (searchEl) searchEl.value = "";
  const showAllChk = document.getElementById("fsShowAllChk");
  if (showAllChk) showAllChk.checked = false;

  document.getElementById("fsModalTitle").textContent = title;
  const subMap = {
    dir: "點擊資料夾進入瀏覽，或按「✓ 確定選用此路徑」選取目前所在的資料夾",
    audio: "支援 .mp3 / .wav / .m4a / .aac / .flac 音樂檔案（雙擊檔案可直接選用）",
    srt: "支援 .srt / .txt 字幕或歌詞檔案（雙擊檔案可直接選用）",
    doc: "支援 .docx / .doc / .pdf / .txt / .md / .rtf 活動手冊或流程檔案（雙擊可直接匯入文字）",
    image: "選擇片頭或片尾圖片（若位於照片資料夾內會自動轉為相對檔名）",
    output: "選擇輸出資料夾並在下方確認或修改輸出 .mp4 檔名",
  };
  document.getElementById("fsModalSub").textContent = subMap[mode] || "點擊項目以選取路徑";

  const pathInput = document.getElementById("fsSelectedPathInput");
  pathInput.readOnly = mode !== "output";

  document.getElementById("fsBrowserModal").classList.remove("hidden");
  await loadFsDirectory(initialPath);
}

async function loadFsDirectory(targetPath = "") {
  const listEl = document.getElementById("fsEntryList");
  listEl.innerHTML = `<div style="padding:24px;color:var(--text-dim);">讀取目錄中…</div>`;

  const showAll = document.getElementById("fsShowAllChk")?.checked ? "1" : "0";
  const qs = new URLSearchParams({
    path: targetPath || "",
    mode: fsState.mode,
    show_all: showAll,
    project_id: state.projectId || "",
  });

  try {
    const data = await api(`/api/fs/list?${qs.toString()}`);
    if (data.error) {
      toast(data.error, true);
    }
    fsState.currentDir = data.current_path;
    fsState.parentDir = data.parent_path;
    fsState.entries = data.entries || [];
    fsState.companions = data.companions || {};
    fsState.currentStats = data.current_dir_stats || {};

    document.getElementById("fsUpBtn").disabled = !fsState.parentDir;

    // 預設選取路徑
    if (fsState.mode === "dir") {
      setFsSelectedPath(fsState.currentDir);
    } else if (fsState.mode === "output") {
      const songTitle = val("f_song_title") || val("f_name") || "output";
      const defaultName = data.preselect || `${songTitle}_MV.mp4`;
      setFsSelectedPath(`${fsState.currentDir}/${defaultName}`);
    } else if (data.preselect) {
      setFsSelectedPath(`${fsState.currentDir}/${data.preselect}`);
    } else {
      setFsSelectedPath("");
    }

    renderFsBreadcrumbs(data.breadcrumbs || []);
    renderFsShortcuts(data.shortcuts || []);
    renderFsDirBanner();
    renderFsEntries();
    updateFsCompanionButton();
  } catch (e) {
    listEl.innerHTML = `<div style="padding:24px;color:var(--red);">${esc(e.message)}</div>`;
  }
}

function setFsSelectedPath(p) {
  fsState.selectedPath = p || "";
  const inp = document.getElementById("fsSelectedPathInput");
  if (inp) inp.value = fsState.selectedPath;
  const confirmBtn = document.getElementById("fsConfirmBtn");
  if (confirmBtn) confirmBtn.disabled = !fsState.selectedPath;
}

function renderFsBreadcrumbs(crumbs) {
  const el = document.getElementById("fsBreadcrumbs");
  if (!el) return;
  el.innerHTML = crumbs.map((c, idx) => `
    <button type="button" class="fs-crumb ${idx === crumbs.length - 1 ? "active" : ""}" data-path="${esc(c.path)}">
      ${esc(c.name === "/" ? "💻 /" : c.name)}
    </button>
  `).join('<span class="fs-crumb-sep">/</span>');

  el.querySelectorAll(".fs-crumb").forEach((btn) => {
    btn.addEventListener("click", () => loadFsDirectory(btn.dataset.path));
  });
  el.scrollLeft = el.scrollWidth;
}

function renderFsShortcuts(shortcuts) {
  const el = document.getElementById("fsShortcuts");
  if (!el) return;
  el.innerHTML = shortcuts.map((s) => `
    <button type="button" class="fs-shortcut-btn ${s.path === fsState.currentDir ? "active" : ""}" data-path="${esc(s.path)}" title="${esc(s.path)}">
      <span>${s.icon || "📁"}</span>
      <span class="fs-shortcut-label">${esc(s.label)}</span>
    </button>
  `).join("");
  el.querySelectorAll(".fs-shortcut-btn").forEach((btn) => {
    btn.addEventListener("click", () => loadFsDirectory(btn.dataset.path));
  });
}

function renderFsDirBanner() {
  const banner = document.getElementById("fsDirBanner");
  if (!banner) return;
  const st = fsState.currentStats || {};
  const badges = [];
  if (st.photo_count > 0) badges.push(`📸 包含 <b>${st.photo_count}</b> 張圖片`);
  if (st.audio_count > 0) badges.push(`🎵 包含 <b>${st.audio_count}</b> 首音訊`);
  if (st.srt_count > 0) badges.push(`📝 包含 <b>${st.srt_count}</b> 個字幕檔`);

  if (fsState.mode === "dir") {
    banner.style.display = "flex";
    banner.innerHTML = `
      <div>
        <span>📂 目前資料夾：<b>${esc(fsState.currentDir)}</b></span>
        ${badges.length ? `<span style="margin-left:10px;color:var(--green);">${badges.join(" ・ ")}</span>` : `<span style="margin-left:10px;color:var(--text-muted);">（可直接點右下角選用此資料夾，或點下方子資料夾進入）</span>`}
      </div>
      <button type="button" class="btn small primary" id="btnSelectCurrentDirNow">✓ 直接選用此資料夾</button>
    `;
    document.getElementById("btnSelectCurrentDirNow").addEventListener("click", () => {
      applyFsSelection(fsState.currentDir, fsState.autoApplyCompanions);
    });
  } else if (badges.length) {
    banner.style.display = "flex";
    banner.innerHTML = `
      <div>📂 <b>${esc(fsState.currentDir)}</b> <span style="margin-left:8px;color:var(--text-dim);">${badges.join(" ・ ")}</span></div>
    `;
  } else {
    banner.style.display = "none";
    banner.innerHTML = "";
  }
}

function renderFsEntries() {
  const listEl = document.getElementById("fsEntryList");
  if (!listEl) return;

  let items = fsState.entries || [];
  if (fsState.searchQuery) {
    items = items.filter((it) => it.name.toLowerCase().includes(fsState.searchQuery));
  }

  if (!items.length) {
    listEl.innerHTML = `<div style="padding:28px;text-align:center;color:var(--text-muted);">此目錄下沒有符合條件的項目（可勾選右上角「顯示所有檔案」查看全部）</div>`;
    return;
  }

  const iconMap = {
    dir: "📁",
    audio: "🎵",
    srt: "📝",
    image: "🖼️",
    video: "🎬",
    other: "📄",
  };

  listEl.innerHTML = "";
  items.forEach((item) => {
    const row = document.createElement("div");
    const isSelected = item.path === fsState.selectedPath;
    row.className = `fs-entry-row ${item.is_dir ? "is-dir" : "is-file"} ${isSelected ? "selected" : ""}`;

    const metaBadges = [];
    if (item.is_dir) {
      if (item.photo_count > 0) metaBadges.push(`<span class="fs-tag photo">📸 ${item.photo_count} 張</span>`);
      if (item.audio_count > 0) metaBadges.push(`<span class="fs-tag audio">🎵 ${item.audio_count} 首</span>`);
      if (item.srt_count > 0) metaBadges.push(`<span class="fs-tag srt">📝 SRT</span>`);
      if (item.subdir_count > 0 && !metaBadges.length) metaBadges.push(`<span class="fs-tag muted">${item.subdir_count} 個子夾</span>`);
    } else {
      if (item.size_human) metaBadges.push(`<span class="fs-size">${esc(item.size_human)}</span>`);
    }

    row.innerHTML = `
      <span class="fs-icon">${iconMap[item.kind] || "📄"}</span>
      <span class="fs-name" title="${esc(item.path)}">${esc(item.name)}</span>
      <div class="fs-badges">${metaBadges.join("")}</div>
      <span class="fs-mtime">${esc(item.mtime || "")}</span>
      ${item.is_dir && fsState.mode === "dir" ? `<button type="button" class="btn small btnPickSubdir" title="直接選用此資料夾">選用此夾</button>` : ""}
    `;

    if (item.is_dir) {
      const pickBtn = row.querySelector(".btnPickSubdir");
      if (pickBtn) {
        pickBtn.addEventListener("click", (ev) => {
          ev.stopPropagation();
          applyFsSelection(item.path, fsState.autoApplyCompanions);
        });
      }
      row.addEventListener("click", () => {
        loadFsDirectory(item.path);
      });
    } else {
      row.addEventListener("click", () => {
        if (fsState.mode === "dir") {
          setFsSelectedPath(fsState.currentDir);
          return;
        }
        setFsSelectedPath(item.path);
        listEl.querySelectorAll(".fs-entry-row").forEach((r) => r.classList.remove("selected"));
        row.classList.add("selected");
      });
      row.addEventListener("dblclick", () => {
        if (fsState.mode === "dir") return;
        applyFsSelection(item.path, fsState.autoApplyCompanions);
      });
    }

    listEl.appendChild(row);
  });
}

function updateFsCompanionButton() {
  const btn = document.getElementById("fsCompanionFillBtn");
  if (!btn) return;
  const c = fsState.companions || {};
  const count = [c.music_file, c.photos_dir, c.srt_file].filter(Boolean).length;
  if (count >= 2) {
    btn.style.display = "inline-flex";
    const parts = [];
    if (c.music_file) parts.push("音樂");
    if (c.photos_dir) parts.push(`${c.photo_count}張照片`);
    if (c.srt_file) parts.push("SRT字幕");
    btn.textContent = `✨ 一鍵帶入同夾素材 (${parts.join(" + ")})`;
  } else {
    btn.style.display = "none";
  }
}

function applyFsSelection(chosenPath, withCompanions = false) {
  if (!chosenPath) {
    toast("請先選擇有效的路徑", true);
    return;
  }
  if (typeof fsState.onSelectCallback === "function") {
    const cb = fsState.onSelectCallback;
    fsState.onSelectCallback = null;
    document.getElementById("fsBrowserModal").classList.add("hidden");
    cb(chosenPath);
    return;
  }
  let finalValue = chosenPath;
  if (fsState.relativeToPhotosDir) {
    const pdir = val("f_photos_dir").replace(/\/+$/, "");
    if (pdir && chosenPath.startsWith(pdir + "/")) {
      finalValue = chosenPath.slice(pdir.length + 1);
    }
  }

  const inputEl = document.getElementById(fsState.targetInputId);
  if (inputEl) {
    inputEl.value = finalValue;
  }

  const filled = [];
  if (withCompanions && fsState.companions) {
    const c = fsState.companions;
    if (c.music_file && document.getElementById("f_music_file")) {
      document.getElementById("f_music_file").value = c.music_file;
      filled.push("音樂檔");
    }
    if (c.photos_dir && document.getElementById("f_photos_dir")) {
      document.getElementById("f_photos_dir").value = c.photos_dir;
      filled.push("照片資料夾");
    }
    if (c.srt_file && document.getElementById("f_srt_file")) {
      document.getElementById("f_srt_file").value = c.srt_file;
      filled.push("SRT 字幕");
    }
    if (c.title_card_file && document.getElementById("f_title_card_file")) {
      document.getElementById("f_title_card_file").value = c.title_card_file;
    }
    if (c.outro_file && document.getElementById("f_outro_file")) {
      document.getElementById("f_outro_file").value = c.outro_file;
    }
  }

  document.getElementById("fsBrowserModal").classList.add("hidden");
  if (filled.length > 1) {
    toast(`✨ 已自動帶入：${filled.join("、")}（請記得點「儲存設定」）`);
  } else {
    toast(`✓ 已選取路徑：${finalValue}（請記得點「儲存設定」）`);
  }
}

async function triggerNativePick(targetInputId, mode, initialDir = "", closeFsModalOnSuccess = false) {
  try {
    toast("正在開啟系統檔案選取視窗…");
    const songTitle = val("f_song_title") || val("f_name") || "output";
    const res = await api("/api/fs/native_pick", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mode,
        initial_dir: initialDir,
        default_name: `${songTitle}_MV.mp4`,
      }),
    });
    if (res.cancelled) return;
    if (res.fallback && !closeFsModalOnSuccess) {
      // 系統對話框不可用（例如沒有 tkinter）：退回內建檔案瀏覽器
      toast(res.error || "改用內建檔案瀏覽器");
      openFsBrowser({ targetInputId, mode, title: "📂 選擇路徑", initialPath: initialDir });
      return;
    }
    if (!res.ok || !res.path) {
      toast(res.error || "選取失敗", true);
      return;
    }
    const inputEl = document.getElementById(targetInputId);
    if (inputEl) {
      inputEl.value = res.path;
      toast(`✓ 已選取：${res.path}`);
    }
    if (closeFsModalOnSuccess) {
      document.getElementById("fsBrowserModal")?.classList.add("hidden");
    }
  } catch (e) {
    toast(e.message, true);
  }
}

// ===============================================================
// 分頁 0：🎪 活動籌備 & 即時照片募集（Pre-Event & Live Upload Portal）
// ===============================================================

async function renderEventPrepTab(proj) {
  const el = document.getElementById("tabContent");
  const ev = proj.event_info || {};
  const groupsStr = Array.isArray(ev.expected_groups) ? ev.expected_groups.join("、") : (ev.expected_groups || "");

  el.innerHTML = `
    <div class="event-prep-layout">
      <!-- 左側：活動前資料輸入與一鍵建置 -->
      <div class="event-form-col">
        <div class="event-section-card">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:12px;">
            <h2 style="margin:0;padding:0;border:none;">1. 活動基本資訊</h2>
            <button type="button" id="btnFillSampleEvent" class="btn small">✨ 載入範例活動企劃</button>
          </div>
          <div class="row2">
            <div>
              <label>活動名稱</label>
              <input type="text" id="ev_name" value="${esc(ev.event_name || proj.song_title || proj.name)}" placeholder="例如：2026 碧山露營場親子成長營" />
            </div>
            <div>
              <label>活動日期</label>
              <input type="text" id="ev_date" value="${esc(ev.event_date || '')}" placeholder="例如：2026-05-25" />
            </div>
          </div>
          <div class="row2">
            <div>
              <label>活動地點</label>
              <input type="text" id="ev_location" value="${esc(ev.event_location || '')}" placeholder="例如：台北內湖・碧山露營場" />
            </div>
            <div>
              <label>主辦單位 / 班級團隊</label>
              <input type="text" id="ev_organizer" value="${esc(ev.organizer || '')}" placeholder="例如：同心同德班級團隊" />
            </div>
          </div>
          <label>活動標語 / Slogan（將自動顯示於片頭卡與手機上傳頁面）</label>
          <input type="text" id="ev_slogan" value="${esc(ev.slogan || '')}" placeholder="例如：大手牽小手，陪伴是最美的風景" />
        </div>

        <div class="event-section-card">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
            <h2 style="margin:0;padding:0;border:none;">2. 活動流程表（Schedule）</h2>
            <button type="button" class="btn small btn-import-doc" data-target="ev_schedule_text" data-title="📂 選擇流程表檔案 (.txt / .docx / .pdf / .md)">📂 從檔案匯入流程表</button>
          </div>
          <p class="hint" style="margin-top:0;">輸入時間區間與活動項目（如 <code>09:00-09:30 報到相見歡</code>），系統會自動建立拍攝主題，並在攝影師上傳照片時<b>自動依 EXIF 拍攝時間對照流程表分類主題</b>！</p>
          <textarea id="ev_schedule_text" rows="6" placeholder="09:00-09:30 報到迎賓與相見歡&#10;09:30-10:30 破冰早操與團隊默契&#10;10:30-12:00 狀元會考分站闖關&#10;14:00-15:30 週末海邊親子淨灘&#10;15:30-16:30 溫馨感恩分享與大合照">${esc(ev.schedule_text || '')}</textarea>
        </div>

        <div class="event-section-card">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
            <h2 style="margin:0;padding:0;border:none;">3. 宣傳文案 / 活動精神（Promo Copy）</h2>
            <button type="button" class="btn small btn-import-doc" data-target="ev_promo_copy" data-title="📂 選擇宣傳文案檔案 (.txt / .docx / .pdf / .md)">📂 從檔案匯入文案</button>
          </div>
          <textarea id="ev_promo_copy" rows="4" placeholder="貼上活動宣傳文案、海報介紹或希望捕捉的感動畫面描述…">${esc(ev.promo_copy || '')}</textarea>
        </div>

        <div class="event-section-card">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
            <h2 style="margin:0;padding:0;border:none;">4. 活動手冊 / 秩序冊 & 小隊分組名單</h2>
            <button type="button" class="btn small btn-import-doc" data-target="ev_handbook_text" data-title="📂 選擇活動手冊檔案 (.docx / .pdf / .txt / .md)">📂 從檔案匯入手冊</button>
          </div>
          <textarea id="ev_handbook_text" rows="5" placeholder="貼上活動手冊內容、關卡說明或小隊分組名單（系統會自動掃描「第一小隊、第二小隊…」等組別標籤）">${esc(ev.handbook_text || '')}</textarea>

          <label style="margin-top:12px;">👥 預計參與小隊 / 主角標籤（逗號或頓號分隔，將顯示在手機上傳頁供點選，並用於「人物出場均衡控制」）</label>
          <input type="text" id="ev_expected_groups" value="${esc(groupsStr)}" placeholder="例如：第一小隊、第二小隊、第三小隊、第四小隊（留空將從手冊自動萃取）" />

          <label style="margin-top:12px;">💬 給拍攝夥伴的上傳頁面提示語</label>
          <input type="text" id="ev_upload_note" value="${esc(ev.upload_note || '歡迎上傳活動精采照片！可一次選取多張照片，並勾選所屬活動環節或小隊。')}" />
        </div>

        <div class="event-action-box">
          <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:12px;">
            <label class="filter-label" style="cursor:pointer;">
              <input type="checkbox" id="chkSyncEventThemes" checked />
              🏷️ 自動將流程與手冊解析出的「活動環節」同步加入專案主題標籤（Themes）
            </label>
            <label class="filter-label" style="cursor:pointer;">
              <input type="checkbox" id="chkGenEventCards" checked />
              🎨 自動根據活動名稱、標語與日期生成 1920×1080「片頭.png」與「片尾.png」
            </label>
          </div>
          <button type="button" id="btnPrepareEventEnv" class="btn primary" style="width:100%;padding:12px;font-size:15px;font-weight:700;">
            🚀 一鍵準備照片收集環境 & 產生拍攝上傳 URL
          </button>
        </div>

        <!-- 解析出的拍攝清單與流程對照預覽 -->
        <div id="eventChecklistPreview"></div>
      </div>

      <!-- 右側：即時照片募集看板 & QR Code 上傳中心 -->
      <div class="event-portal-col">
        <div class="event-portal-card" id="eventPortalCard">
          <div style="padding:24px;text-align:center;color:var(--text-dim);">載入照片募集環境資訊中…</div>
        </div>
      </div>
    </div>
  `;

  // 綁定匯入文件按鈕
  el.querySelectorAll(".btn-import-doc").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.dataset.target;
      const title = btn.dataset.title;
      openFsBrowser({
        targetInputId: targetId,
        mode: "doc",
        title,
        initialPath: val("f_photos_dir") || "",
        onSelectCallback: async (chosenPath) => {
          try {
            toast(`📄 正在擷取文件內容：${chosenPath}…`);
            const res = await api(`/api/projects/${state.projectId}/event/extract_doc`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ path: chosenPath }),
            });
            const ta = document.getElementById(targetId);
            if (ta) {
              ta.value = ta.value.trim() ? `${ta.value.trim()}\n\n${res.text}` : res.text;
            }
            toast(`✓ 已成功匯入「${res.filename}」文字內容！`);
          } catch (e) {
            toast(e.message, true);
          }
        },
      });
    });
  });

  // 載入範例活動企劃
  document.getElementById("btnFillSampleEvent").addEventListener("click", () => {
    document.getElementById("ev_name").value = "2026 親子保鮮期・戶外成長體驗營";
    document.getElementById("ev_date").value = new Date().toISOString().slice(0, 10);
    document.getElementById("ev_location").value = "台北內湖・碧山露營場";
    document.getElementById("ev_organizer").value = "同心同德班級團隊";
    document.getElementById("ev_slogan").value = "大手牽小手，陪伴是最美的風景";
    document.getElementById("ev_schedule_text").value = [
      "09:00-09:30 報到迎賓與相見歡",
      "09:30-10:20 魔法禮儀工作坊（請、謝謝、對不起）",
      "10:20-11:30 快樂讀經與經典朗讀",
      "11:30-13:00 狀元會考分站闖關挑戰",
      "14:00-15:30 週末海邊親子淨灘行動",
      "15:30-16:30 暖心連結語分享與圓滿大合照",
    ].join("\n");
    document.getElementById("ev_promo_copy").value = "放下手機不分心，先接住孩子的情緒，搭起親子信任的橋樑。透過魔法禮儀、經典讀經、狀元闖關與海灘淨灘，讓孩子充滿效能感與自信笑容！";
    document.getElementById("ev_handbook_text").value = "【分組名單】本營隊共分為：第一小隊、第二小隊、第三小隊、第四小隊。請各小隊隊輔與攝影志工在每個關卡至少為所屬小隊拍攝 4 張以上清晰橫式合照與特寫。";
    document.getElementById("ev_expected_groups").value = "第一小隊、第二小隊、第三小隊、第四小隊";
    toast("✨ 已填入範例活動企劃資料，請點下方「🚀 一鍵準備照片收集環境」！");
  });

  document.getElementById("btnPrepareEventEnv").addEventListener("click", prepareEventEnvFlow);

  await loadEventPortalStats();
  startEventPortalPoll();
}

function collectEventForm() {
  const groupsRaw = val("ev_expected_groups");
  const groups = groupsRaw
    ? groupsRaw.split(/[、,，;；\n]+/).map((s) => s.trim()).filter(Boolean)
    : [];
  return {
    event_name: val("ev_name"),
    event_date: val("ev_date"),
    event_location: val("ev_location"),
    organizer: val("ev_organizer"),
    slogan: val("ev_slogan"),
    schedule_text: document.getElementById("ev_schedule_text")?.value.trim() || "",
    promo_copy: document.getElementById("ev_promo_copy")?.value.trim() || "",
    handbook_text: document.getElementById("ev_handbook_text")?.value.trim() || "",
    expected_groups: groups,
    upload_note: val("ev_upload_note"),
    public_base_url: document.getElementById("ev_public_base_url")?.value.trim() || (state.proj?.event_info?.public_base_url || ""),
    upload_enabled: document.getElementById("ev_upload_enabled") ? document.getElementById("ev_upload_enabled").checked : true,
  };
}

async function prepareEventEnvFlow() {
  const btn = document.getElementById("btnPrepareEventEnv");
  const syncThemes = document.getElementById("chkSyncEventThemes")?.checked ?? true;
  const genCards = document.getElementById("chkGenEventCards")?.checked ?? true;
  const event_info = collectEventForm();

  try {
    if (btn) { btn.disabled = true; btn.textContent = "⏳ 正在解析企劃、建立照片目錄與生成片頭片尾…"; }
    const res = await api(`/api/projects/${state.projectId}/event/prepare`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event_info, sync_themes: syncThemes, generate_cards: genCards }),
    });
    if (res.event_info?.expected_groups?.length) {
      const gInput = document.getElementById("ev_expected_groups");
      if (gInput) gInput.value = res.event_info.expected_groups.join("、");
    }
    toast(`🎉 活動照片收集環境已就緒！共建立 ${res.themes?.length || 0} 個活動主題，上傳 URL 已開放`);
    await refreshProj();
    await loadEventPortalStats();
  } catch (e) {
    toast(e.message, true);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "🚀 一鍵準備照片收集環境 & 產生拍攝上傳 URL"; }
  }
}

async function loadEventPortalStats() {
  try {
    const data = await api(`/api/projects/${state.projectId}/event`);
    renderEventPortalCard(data);
    renderEventChecklistPreview(data.event_info || {}, data.by_theme || {});
  } catch (e) {
    /* ignore */
  }
}

function renderEventChecklistPreview(ev, byTheme) {
  const box = document.getElementById("eventChecklistPreview");
  if (!box) return;
  const list = ev.shot_checklist || [];
  if (!list.length) {
    box.innerHTML = "";
    return;
  }
  box.innerHTML = `
    <div class="event-section-card" style="margin-top:16px;">
      <h2 style="margin:0 0 10px 0;padding:0;border:none;">📋 自動產生的攝影師拍攝指南（已同步顯示於手機上傳頁）</h2>
      <div style="display:flex;flex-direction:column;gap:8px;">
        ${list.map((c) => {
          const cnt = byTheme[c.theme] || 0;
          return `
            <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
              <div>
                <div style="font-weight:600;font-size:13px;">
                  ${c.time_range ? `<span class="badge" style="margin-right:6px;">⏰ ${esc(c.time_range)}</span>` : ""}
                  <span>${esc(c.title)}</span>
                  <span style="color:var(--accent);font-size:11.5px;margin-left:6px;">#${esc(c.theme)}</span>
                </div>
                <div style="font-size:11.5px;color:var(--text-dim);margin-top:3px;">💡 ${esc(c.tip)}</div>
              </div>
              <span class="badge ${cnt > 0 ? "done" : "pending"}" style="white-space:nowrap;">已收 ${cnt} 張</span>
            </div>
          `;
        }).join("")}
      </div>
    </div>
  `;
}

function renderEventPortalCard(data) {
  const card = document.getElementById("eventPortalCard");
  if (!card) return;
  const ev = data.event_info || {};
  const up = data.upload || {};
  const byTheme = data.by_theme || {};
  const byGroup = data.by_group || {};
  const byUploader = data.by_uploader || {};
  const recent = data.recent_photos || [];

  card.innerHTML = `
    <div class="portal-header">
      <div>
        <span class="badge done" style="margin-bottom:6px;display:inline-block;">📡 即時照片收集伺服器運行中</span>
        <h3 style="margin:0;font-size:17px;">📸 拍攝人員專屬上傳入口</h3>
      </div>
      <label class="filter-label" style="cursor:pointer;">
        <input type="checkbox" id="ev_upload_enabled" ${ev.upload_enabled !== false ? "checked" : ""} /> 開放上傳
      </label>
    </div>

    <div class="qr-box">
      <div class="qr-svg-wrap">${up.qr_svg || ""}</div>
      <div class="qr-info">
        <div style="font-size:12px;color:var(--text-dim);margin-bottom:4px;">📱 手機連上同一 Wi-Fi 掃描 QR Code 或開啟網址：</div>
        <div class="upload-url-box" id="primaryUploadUrlText">${esc(up.primary_url || up.lan_url)}</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">
          <button type="button" class="btn small primary" id="btnCopyUploadUrl">📋 複製上傳網址</button>
          <a href="${esc(up.local_url)}" target="_blank" class="btn small" style="text-decoration:none;">🔗 開啟上傳頁預覽</a>
          <button type="button" class="btn small" id="btnCopyLineMsg">💬 複製 LINE 募集公告</button>
        </div>
        <div style="margin-top:10px;">
          <label style="font-size:11px;color:var(--text-muted);margin:0 0 3px 0;">🌐 外部公網轉發網址（選填，如 Cloudflare Tunnel / ngrok）：</label>
          <div style="display:flex;gap:6px;">
            <input type="text" id="ev_public_base_url" value="${esc(ev.public_base_url || '')}" placeholder="https://xxx.trycloudflare.com" style="font-size:11.5px;padding:5px 8px;margin:0;" />
            <button type="button" class="btn small" id="btnSavePublicUrl">更新</button>
          </div>
        </div>
      </div>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border);">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
        <span style="font-weight:700;font-size:13.5px;">📊 即時募集進度（共 <b style="color:var(--green);font-size:16px;">${data.total_photos || 0}</b> 張）</span>
        <span style="font-size:11px;color:var(--text-muted);">🔄 每 4 秒自動刷新</span>
      </div>

      <!-- 各活動環節募集統計 -->
      <div style="font-size:11.5px;color:var(--text-dim);margin-bottom:4px;">依活動環節：</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;">
        ${Object.entries(byTheme).map(([t, cnt]) => `
          <span class="cov-mini-badge ${cnt > 0 ? "ok" : ""}"><b>${esc(t)}</b> <span>${cnt} 張</span></span>
        `).join("") || `<span class="hint">尚無主題分類</span>`}
      </div>

      <!-- 各小隊募集統計 -->
      ${Object.keys(byGroup).length ? `
        <div style="font-size:11.5px;color:var(--text-dim);margin-bottom:4px;">依小隊 / 主角：</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;">
          ${Object.entries(byGroup).map(([g, cnt]) => `
            <span class="cov-mini-badge ${cnt > 0 ? "ok" : "deficit"}"><b>👥 ${esc(g)}</b> <span>${cnt} 張</span></span>
          `).join("")}
        </div>
      ` : ""}

      <!-- 上傳貢獻排行榜 -->
      ${Object.keys(byUploader).length ? `
        <div style="font-size:11.5px;color:var(--text-dim);margin-bottom:4px;">參與上傳夥伴：</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;">
          ${Object.entries(byUploader).map(([u, cnt]) => `
            <span class="subagent-stat-pill">📸 <b>${esc(u)}</b> ${cnt} 張</span>
          `).join("")}
        </div>
      ` : ""}

      <!-- 最新上傳縮圖牆 -->
      <div style="font-size:11.5px;color:var(--text-dim);margin-bottom:6px;">最新收到的照片：</div>
      <div class="portal-recent-grid">
        ${recent.length ? recent.slice(0, 8).map((p) => `
          <div class="portal-recent-thumb" title="${esc(p.filename)} (${esc(p.uploader || '')})">
            <img loading="lazy" src="${thumbUrl(state.projectId, p.filename)}" alt="${esc(p.filename)}" />
            <div class="portal-recent-cap">${esc(p.theme || "待分析")}</div>
          </div>
        `).join("") : `<div style="grid-column:1/-1;padding:14px;text-align:center;color:var(--text-muted);font-size:12px;background:var(--bg);border-radius:8px;">等待第一張照片上傳中…</div>`}
      </div>
    </div>
  `;

  document.getElementById("btnCopyUploadUrl")?.addEventListener("click", () => {
    navigator.clipboard.writeText(up.primary_url || up.lan_url).then(() => toast("✓ 已複製拍攝上傳網址！"));
  });

  document.getElementById("btnCopyLineMsg")?.addEventListener("click", () => {
    const checklistLines = (ev.shot_checklist || []).slice(0, 6).map((c) => `  ・${c.time_range ? c.time_range + " " : ""}${c.title}`).join("\n");
    const msg = [
      `🎬【${ev.event_name || "活動回憶 MV"}】照片即時募集開跑！`,
      ev.event_date ? `📅 日期：${ev.event_date}` : "",
      ev.event_location ? `📍 地點：${ev.event_location}` : "",
      "",
      "請各位攝影夥伴與老師家長，隨時點開下方專屬連結，直接從手機相簿批次選取照片上傳（免登入）：",
      `👉 ${up.primary_url || up.lan_url}`,
      "",
      checklistLines ? `📸 重點拍攝環節：\n${checklistLines}` : "",
      "謝謝大家一起紀錄最美好的回憶！✨",
    ].filter(Boolean).join("\n");
    navigator.clipboard.writeText(msg).then(() => toast("✓ 已複製 LINE 群組募集公告文案！"));
  });

  document.getElementById("btnSavePublicUrl")?.addEventListener("click", prepareEventEnvFlow);
  document.getElementById("ev_upload_enabled")?.addEventListener("change", prepareEventEnvFlow);
}

function startEventPortalPoll() {
  if (state._eventPollTimer) {
    clearInterval(state._eventPollTimer);
    state._eventPollTimer = null;
  }
  state._eventPollTimer = setInterval(async () => {
    if (state.tab !== "event_prep" || !state.projectId) {
      clearInterval(state._eventPollTimer);
      state._eventPollTimer = null;
      return;
    }
    try {
      const data = await api(`/api/projects/${state.projectId}/event`);
      const prevTotal = state._lastEventPhotoTotal;
      if (prevTotal !== undefined && data.total_photos !== prevTotal) {
        toast(`📸 收到新上傳的照片！目前已募集 ${data.total_photos} 張`);
      }
      state._lastEventPhotoTotal = data.total_photos;
      // 避免覆蓋正在輸入的 public_base_url 焦點
      if (document.activeElement?.id !== "ev_public_base_url") {
        renderEventPortalCard(data);
        renderEventChecklistPreview(data.event_info || {}, data.by_theme || {});
      }
    } catch (_) { /* ignore */ }
  }, 4000);
}
