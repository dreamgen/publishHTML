#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/manifest.py
================
時間軸照片分配（三優先策略 + 人物/小隊出場均衡度控制 Protagonist Balancing）：
  P1 (最優)：主題匹配 + 尚未使用   → 優先挑選低出場率人物與高品質照片，再依 EXIF 時間順序排列播放
  P2 (次優)：主題不符但尚未使用    → 依 fit×0.6 + quality×0.4 + 低出場率人物加權 挑選最合適照片
  P3 (兜底)：已使用過的照片        → 依加權分數與低出場率人物補償進行 Round-robin 輪替

同時將每張照片的人臉/主體重心座標 (focus_x, focus_y) 與人物標籤 (protagonists)
寫入 ordered_photos_detail.json 與 ordered_photos.json，供渲染引擎執行智慧焦點追蹤 Ken Burns。
"""

import json
from collections import defaultdict
from datetime import datetime, timezone, timedelta

P3_FIT_WEIGHT = 0.6
P3_QUALITY_WEIGHT = 0.4
DEFAULT_PROTAGONIST_WEIGHT = 2.5


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def _sort_key(photo: dict) -> str:
    return photo.get("exif_time") or photo.get("file_mtime") or ""


# 雲端相簿的加分：主辦者標「MV 優先」+3.0；相簿票數每票 +0.15、最多 +1.5（不含攝影者自選）
CLOUD_PRIORITY_BONUS = 3.0
CLOUD_VOTE_BONUS = 0.15
CLOUD_VOTE_BONUS_MAX = 1.5


def _cloud_bonus(photo: dict) -> float:
    bonus = CLOUD_PRIORITY_BONUS if photo.get("cloud_priority") else 0.0
    try:
        votes = int(photo.get("cloud_votes") or 0)
    except (TypeError, ValueError):
        votes = 0
    return bonus + min(CLOUD_VOTE_BONUS_MAX, max(0, votes) * CLOUD_VOTE_BONUS)


def _protagonist_bonus(photo: dict, protag_counts: dict) -> float:
    """
    計算照片中人物/小隊的「低出場率補償紅利」 ∈ [0.0, 1.0]：
    - 若照片包含尚未出場過（count=0）的人物/小隊，獲得滿分 1.0 紅利
    - 隨著該人物出場次數增加，紅利依 1 / (1 + count) 遞減
    """
    tags = photo.get("protagonists") or []
    if not tags:
        return 0.0
    min_c = min(protag_counts.get(t, 0) for t in tags)
    avg_c = sum(protag_counts.get(t, 0) for t in tags) / len(tags)
    return 0.7 * (1.0 / (1.0 + min_c)) + 0.3 * (1.0 / (1.0 + avg_c))


def _record_protagonists(photo: dict, duration: float, protag_counts: dict, protag_seconds: dict):
    for t in (photo.get("protagonists") or []):
        protag_counts[t] = protag_counts.get(t, 0) + 1
        protag_seconds[t] = round(protag_seconds.get(t, 0.0) + duration, 3)


def compute_protagonist_stats(assignments: list, photos) -> list[dict]:
    """
    統計目錄中所有已標記人物/小隊的總照片數、實際獲選出場次數與總曝光秒數。
    支援 photos 為 list[dict] 或 dict[filename, dict]。
    """
    if isinstance(photos, dict):
        photo_by_name = photos
        photo_list = list(photos.values())
    else:
        photo_list = list(photos or [])
        photo_by_name = {p["filename"]: p for p in photo_list}
    catalog_counts = defaultdict(int)
    for p in photo_list:
        for t in (p.get("protagonists") or []):
            catalog_counts[t] += 1

    assigned_counts = defaultdict(int)
    assigned_seconds = defaultdict(float)
    for a in assignments:
        fn = a.get("filename")
        p = photo_by_name.get(fn) if fn else None
        tags = a.get("protagonists") if a.get("protagonists") is not None else ((p or {}).get("protagonists") or [])
        dur = float(a.get("duration") or 0.0)
        for t in tags:
            assigned_counts[t] += 1
            assigned_seconds[t] = round(assigned_seconds[t] + dur, 2)

    all_tags = sorted(set(catalog_counts.keys()) | set(assigned_counts.keys()))
    out = []
    for t in all_tags:
        out.append({
            "name": t,
            "catalog_photos": catalog_counts.get(t, 0),
            "assigned_slots": assigned_counts.get(t, 0),
            "total_seconds": round(assigned_seconds.get(t, 0.0), 1),
        })
    out.sort(key=lambda x: (-x["assigned_slots"], -x["catalog_photos"], x["name"]))
    return out


def assign_photos(slots: list, photos: list, protagonist_weight: float = DEFAULT_PROTAGONIST_WEIGHT) -> tuple:
    pool = [p for p in photos if p.get("analyzed") and p.get("theme")]
    any_protagonists = any(bool(p.get("protagonists")) for p in pool)

    theme_pool: dict = defaultdict(list)
    for p in pool:
        theme_pool[p["theme"]].append(p)
    for theme in theme_pool:
        theme_pool[theme].sort(key=_sort_key)

    # 統計每個主題總共需要多少個非固定時槽
    theme_slot_needs = defaultdict(int)
    for s in slots:
        if not s.get("assigned_photo"):
            theme_slot_needs[s["theme"]] += 1

    used = {s.get("assigned_photo") for s in slots if s.get("assigned_photo")}
    protag_counts: dict = defaultdict(int)
    protag_seconds: dict = defaultdict(float)

    # ── P1 預先挑選（兼顧「人物出場均衡 / 照片品質」與「EXIF 時間順序」）──
    # 當某主題的可用照片數 > 需求槽數，或有標記人物標籤時，
    # 先依「人物稀缺紅利 + 適配分 + 品質分」選出該主題要用的 K 張最佳照片，
    # 再將這 K 張照片按 EXIF 時間升冪排好，確保同一主題內依然維持真實時間流！
    p1_queues: dict = {}
    for theme, needed_k in theme_slot_needs.items():
        cands = [p for p in theme_pool.get(theme, []) if p["filename"] not in used]
        if len(cands) <= needed_k and not any_protagonists:
            chosen_for_theme = list(cands)
            for p in chosen_for_theme:
                used.add(p["filename"])
                _record_protagonists(p, 3.5, protag_counts, protag_seconds)
        else:
            remaining = list(cands)
            chosen_for_theme = []
            take_n = min(len(remaining), needed_k)
            for _ in range(take_n):
                def _p1_score(p):
                    fit = float((p.get("fit_scores") or {}).get(theme, 8.0))
                    qual = float(p.get("quality_score") or 7.0)
                    p_bonus = _protagonist_bonus(p, protag_counts) if protagonist_weight > 0 else 0.0
                    return fit * 0.45 + qual * 0.35 + protagonist_weight * 3.5 * p_bonus + _cloud_bonus(p)

                best_p = max(remaining, key=_p1_score)
                remaining.remove(best_p)
                chosen_for_theme.append(best_p)
                used.add(best_p["filename"])
                _record_protagonists(best_p, 3.5, protag_counts, protag_seconds)

            # 選出的 K 張照片重新按 EXIF 拍攝時間升冪排序，維持活動時間軸敘事
            chosen_for_theme.sort(key=_sort_key)
        p1_queues[theme] = chosen_for_theme

    rr_counters: dict = defaultdict(int)
    assignments = []
    stats = {"P1": 0, "P2": 0, "P3": 0, "FIXED": 0, "EMPTY": 0}

    for slot in slots:
        sid = slot["slot_id"]
        theme = slot["theme"]
        dur = slot["duration"]
        sub = slot.get("subtitle")
        fixed = slot.get("assigned_photo")

        if fixed:
            assignments.append({
                "slot_id": sid, "filename": fixed,
                "duration": dur, "theme": theme,
                "subtitle": sub, "reason": "FIXED",
                "focus_x": 0.5, "focus_y": 0.5,
                "protagonists": [],
            })
            stats["FIXED"] += 1
            continue

        chosen = None
        reason = None

        # P1：從已按人物均衡挑選並按 EXIF 排序的佇列取出
        q = p1_queues.get(theme, [])
        if q:
            chosen = q.pop(0)
            reason = "P1:theme_match_unused"
            stats["P1"] += 1

        # P2：跨主題尚未使用照片（加權適配分 + 品質分 + 低出場人物紅利）
        if chosen is None:
            all_unused = [p for p in pool if p["filename"] not in used]
            if all_unused:
                all_unused.sort(
                    key=lambda p: (
                        p.get("fit_scores", {}).get(theme, 0) * P3_FIT_WEIGHT +
                        (p.get("quality_score") or 5.0) * P3_QUALITY_WEIGHT +
                        protagonist_weight * 2.5 * _protagonist_bonus(p, protag_counts) + _cloud_bonus(p)
                    ),
                    reverse=True
                )
                chosen = all_unused[0]
                used.add(chosen["filename"])
                _record_protagonists(chosen, dur, protag_counts, protag_seconds)
                reason = "P2:best_fit_unused"
                stats["P2"] += 1

        # P3：輪替重用（優先補償出場次數較少的人物與高分照片）
        if chosen is None:
            rr_pool = list(theme_pool.get(theme, []))
            if not rr_pool:
                rr_pool = list(pool)
            if rr_pool:
                rr_pool.sort(
                    key=lambda p: (
                        p.get("fit_scores", {}).get(theme, 0) * P3_FIT_WEIGHT +
                        (p.get("quality_score") or 5.0) * P3_QUALITY_WEIGHT +
                        protagonist_weight * 2.0 * _protagonist_bonus(p, protag_counts) + _cloud_bonus(p)
                    ),
                    reverse=True
                )
                idx = rr_counters[theme] % len(rr_pool)
                chosen = rr_pool[idx]
                rr_counters[theme] += 1
                _record_protagonists(chosen, dur, protag_counts, protag_seconds)
                reason = f"P3:round_robin[{idx}]"
                stats["P3"] += 1

        if chosen:
            assignments.append({
                "slot_id": sid,
                "filename": chosen["filename"],
                "duration": dur,
                "theme": theme,
                "subtitle": sub,
                "reason": reason,
                "quality_score": chosen.get("quality_score"),
                "fit_score": chosen.get("fit_scores", {}).get(theme),
                "focus_x": chosen.get("focus_x", 0.5),
                "focus_y": chosen.get("focus_y", 0.38),
                "protagonists": chosen.get("protagonists", []),
            })
        else:
            assignments.append({
                "slot_id": sid, "filename": "__MISSING__",
                "duration": dur, "theme": theme,
                "subtitle": sub, "reason": "EMPTY:no_photo_in_catalog",
                "focus_x": 0.5, "focus_y": 0.5,
                "protagonists": [],
            })
            stats["EMPTY"] += 1

    stats["protagonist_stats"] = compute_protagonist_stats(assignments, photos)
    return assignments, stats


def load_assignments(detail_path, plan: dict, catalog_photos: list = None) -> list:
    if detail_path.exists():
        data = json.loads(detail_path.read_text(encoding="utf-8"))
        assignments = data.get("assignments", [])
    else:
        assignments = []
        for slot in plan["timeline"]:
            fixed = slot.get("assigned_photo")
            assignments.append({
                "slot_id": slot["slot_id"],
                "filename": fixed if fixed else None,
                "duration": slot["duration"],
                "theme": slot["theme"],
                "subtitle": slot.get("subtitle"),
                "reason": "FIXED" if fixed else None,
                "focus_x": 0.5,
                "focus_y": 0.38,
                "protagonists": [],
            })

    if catalog_photos:
        photo_map = {p["filename"]: p for p in catalog_photos if isinstance(p, dict) and "filename" in p}
        for a in assignments:
            fn = a.get("filename")
            if fn and fn in photo_map:
                cp = photo_map[fn]
                if a.get("focus_x") is None and cp.get("focus_x") is not None:
                    a["focus_x"] = cp["focus_x"]
                if a.get("focus_y") is None and cp.get("focus_y") is not None:
                    a["focus_y"] = cp["focus_y"]
                if not a.get("protagonists") and cp.get("protagonists"):
                    a["protagonists"] = cp["protagonists"]
    return assignments


def save_assignments(detail_path, ordered_path, plan: dict, assignments: list, stats: dict = None, catalog_photos: list = None) -> dict:
    assignments_sorted = sorted(assignments, key=lambda a: a["slot_id"])
    total_cal = round(sum(a["duration"] for a in assignments_sorted), 3)

    photo_map = {p["filename"]: p for p in (catalog_photos or [])}
    for a in assignments_sorted:
        fn = a.get("filename")
        if fn and fn in photo_map:
            cp = photo_map[fn]
            if a.get("focus_x") is None and cp.get("focus_x") is not None:
                a["focus_x"] = cp["focus_x"]
            if a.get("focus_y") is None and cp.get("focus_y") is not None:
                a["focus_y"] = cp["focus_y"]
            if not a.get("protagonists") and cp.get("protagonists"):
                a["protagonists"] = cp["protagonists"]

    if catalog_photos is not None:
        stats = dict(stats or {})
        stats["protagonist_stats"] = compute_protagonist_stats(assignments_sorted, catalog_photos)

    detail_output = {
        "generated_at": _now_tw(),
        "song_title": plan.get("song_title"),
        "total_slots": len(assignments_sorted),
        "total_duration": total_cal,
        "stats": stats or {},
        "assignments": assignments_sorted,
    }
    detail_path.parent.mkdir(parents=True, exist_ok=True)
    detail_path.write_text(json.dumps(detail_output, ensure_ascii=False, indent=2), encoding="utf-8")

    ordered = [
        {
            "filename": a["filename"] or "__MISSING__",
            "duration": round(a["duration"], 3),
            "focus_x": round(float(a.get("focus_x") if a.get("focus_x") is not None else 0.5), 3),
            "focus_y": round(float(a.get("focus_y") if a.get("focus_y") is not None else 0.38), 3),
            # 固定素材（片頭卡、片尾卡）渲染時完全靜態，只淡入淡出
            "static": a.get("reason") == "FIXED",
        }
        for a in assignments_sorted
    ]
    ordered_path.write_text(json.dumps(ordered, ensure_ascii=False, indent=2), encoding="utf-8")
    return detail_output


def slots_in_use_count(assignments: list) -> dict:
    counts = {}
    for a in assignments:
        fn = a.get("filename")
        if fn:
            counts[fn] = counts.get(fn, 0) + 1
    return counts
