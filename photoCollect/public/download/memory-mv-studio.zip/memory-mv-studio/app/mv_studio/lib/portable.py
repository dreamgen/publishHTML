#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/portable.py
===============
跨平台相容層（macOS / Windows / Linux）。

集中處理三件原本寫死在 macOS 的事：
  1. 中文字型尋找：繁體中文優先、實際缺字檢驗（可用環境變數 MV_FONT 指定字型檔）
  2. 最終合併的影片編碼器（macOS 用 VideoToolbox，其餘平台用 libx264；
     可用 MV_FINAL_ENCODER=cpu|videotoolbox|nvenc 強制指定）
  3. HEIC/HEIF 照片讀取（有安裝 pillow-heif 就自動註冊）
"""

import os
import sys
import glob
from pathlib import Path

IS_MAC = sys.platform == "darwin"
IS_WIN = sys.platform.startswith("win")

# ─────────────────────────────────────────────────────────────
# 中文字型：繁體中文優先 ＋ 實際缺字檢驗
# ─────────────────────────────────────────────────────────────
# 教訓：曾經優先選用 macOS 日文字型「ヒラギノ丸ゴ ProN」，它沒有繁體「啟」（日文作「啓」），
# 字幕出現 .notdef 方框。所以：
#   1. 候選清單一律「繁體中文字型」在前，日文／簡體字型只當最後備援；
#   2. 不再只看檔案是否存在，而是實際檢查字型能不能畫出「繁體探針字＋要顯示的文字」；
#   3. TTC 字型集會逐一檢查每個字面（index），挑真正涵蓋繁體的那一個。
TC_PROBE = "啟體臺灣說為與這們裡會發歡迎謝錄"

# 安裝包內建字型資料夾（setup 或 `mvctl fonts` 下載 Noto Sans TC 到這裡）
APP_FONT_DIR = Path(__file__).resolve().parents[2] / "fonts"
NOTO_TC_URL = "https://raw.githubusercontent.com/google/fonts/main/ofl/notosanstc/NotoSansTC%5Bwght%5D.ttf"
NOTO_TC_FILE = "NotoSansTC-Variable.ttf"

_SYSTEM_TC = [
    # macOS（PingFang.ttc 內含 TC 字面；STHeiti 也涵蓋繁體）
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    # Windows（微軟正黑體）
    "C:/Windows/Fonts/msjhbd.ttc",
    "C:/Windows/Fonts/msjh.ttc",
    # Linux（Noto CJK 的 TTC 內含 TC 字面）
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc",
]
_LAST_RESORT = [
    # 日文、簡體或明體字型：只在上面全都不存在時使用，且仍要通過缺字檢驗
    "/System/Library/Fonts/Supplemental/Songti.ttc",
    "C:/Windows/Fonts/mingliu.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/ヒラギノ丸ゴ ProN W4.ttc",
]


def font_candidates() -> list[str]:
    """依優先序回傳字型路徑：MV_FONT → 內建 Noto Sans TC → 使用者字型夾的繁中字型 → 系統繁中字型 → 最後備援。"""
    cands = []
    env_font = os.environ.get("MV_FONT", "").strip()
    if env_font:
        cands.append(env_font)
    if APP_FONT_DIR.exists():
        cands.extend(sorted(glob.glob(str(APP_FONT_DIR / "NotoSansTC*.?tf"))))
    user_dirs = [
        Path.home() / "Library" / "Fonts",
        Path.home() / ".fonts",
        Path.home() / ".local" / "share" / "fonts",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts" if IS_WIN else None,
    ]
    for d in user_dirs:
        if d and d.exists():
            for pat in ("NotoSansTC-Black*.?tf", "NotoSansTC*.?tf", "jf-openhuninn*.tt?", "NotoSansCJK*.tt?"):
                cands.extend(sorted(glob.glob(str(d / pat))))
    cands.extend(_SYSTEM_TC)
    cands.extend(_LAST_RESORT)
    seen, out = set(), []
    for c in cands:
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    return out


def _open_face(path: str, index: int, size: int):
    from PIL import ImageFont
    font = ImageFont.truetype(path, size, index=index)
    # 可變字型（例如 Noto Sans TC [wght]）調到最粗，字幕描邊後才清楚
    try:
        axes = font.get_variation_axes()
        if axes:
            font.set_variation_by_axes([a.get("maximum", 900) if "eight" in str(a.get("name", "")).lower() or i == 0 else a.get("default", 0)
                                        for i, a in enumerate(axes)])
    except Exception:
        pass
    return font


def _glyph_sig(font, ch):
    try:
        m = font.getmask(ch)
        return (m.size, bytes(m))
    except Exception:
        return None


def missing_glyphs(font, text: str) -> list[str]:
    """回傳字型畫不出來的字（會變成 .notdef 方框或空白）。只檢查非 ASCII、非空白字元。"""
    notdef = {_glyph_sig(font, "\U0010FFFD"), _glyph_sig(font, "\uFFFF")}
    miss = []
    for ch in sorted(set(text or "")):
        if ord(ch) < 128 or ch.isspace():
            continue
        sig = _glyph_sig(font, ch)
        if sig is None or sig in notdef or sig[0] == (0, 0):
            miss.append(ch)
    return miss


class FontChoice:
    """選定的字型：路徑＋TTC 字面 index；用 .load(size) 取得 Pillow 字型（可變字型自動設最粗）。"""

    def __init__(self, path: str, index: int = 0, missing=None):
        self.path, self.index, self.missing = path, index, list(missing or [])

    def load(self, size: int):
        return _open_face(self.path, self.index, size)

    def __str__(self):
        return self.path + (f"（字面 {self.index}）" if self.index else "")


_choice_cache: dict = {}


def choose_cjk_font(text: str = "") -> FontChoice | None:
    """挑第一個能畫出「繁體探針字＋text 全部字元」的字型；都不行就挑缺字最少的並記錄缺字。"""
    need = TC_PROBE + (text or "")
    key = "".join(sorted(set(need)))
    if key in _choice_cache:
        return _choice_cache[key]
    best = None
    for path in font_candidates():
        if not os.path.exists(path):
            continue
        passing = []
        for idx in range(0, 16 if path.lower().endswith(".ttc") else 1):
            try:
                f = _open_face(path, idx, 48)
            except Exception:
                break  # TTC 沒有更多字面
            miss = missing_glyphs(f, need)
            if not miss:
                passing.append((idx, " ".join(f.getname())))
            elif best is None or len(miss) < len(best.missing):
                best = FontChoice(path, idx, miss)
        if passing:
            # 同一個 TTC 有多個字面都涵蓋時（例如 Noto CJK 的 JP/KR/SC/TC），優先繁體字面，字形才是台灣習慣寫法
            tc = [i for i, name in passing if any(k in name for k in (" TC", "Traditional", "Hant", "JhengHei", "HK"))]
            _choice_cache[key] = FontChoice(path, (tc or [passing[0][0]])[0])
            return _choice_cache[key]
    _choice_cache[key] = best
    return best


def find_cjk_font(text: str = "") -> str | None:
    """相容舊介面：回傳選定字型的路徑。新程式請用 choose_cjk_font()（含 TTC index）。"""
    c = choose_cjk_font(text)
    return c.path if c else None


def download_noto_tc(timeout: int = 120) -> Path:
    """下載 Noto Sans TC（SIL OFL 授權，可自由散布）到 app/fonts/。"""
    import urllib.request
    APP_FONT_DIR.mkdir(parents=True, exist_ok=True)
    dest = APP_FONT_DIR / NOTO_TC_FILE
    tmp = dest.with_suffix(".part")
    req = urllib.request.Request(NOTO_TC_URL, headers={"User-Agent": "MVStudio-fonts/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 16)
            if not b:
                break
            f.write(b)
    if tmp.stat().st_size < 1_000_000:
        raise RuntimeError("下載的字型檔大小異常")
    tmp.replace(dest)
    _choice_cache.clear()
    return dest


def final_encoder_args(bitrate: str = "6000k") -> list[str]:
    """最終合併用的 FFmpeg 影片編碼參數。失敗時呼叫端仍應 fallback 到 libx264。"""
    mode = os.environ.get("MV_FINAL_ENCODER", "auto").strip().lower()
    if mode == "auto":
        mode = "videotoolbox" if IS_MAC else "cpu"
    if mode == "videotoolbox":
        return ["-c:v", "h264_videotoolbox", "-b:v", bitrate, "-pix_fmt", "yuv420p"]
    if mode == "nvenc":
        return ["-c:v", "h264_nvenc", "-b:v", bitrate, "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p"]


def register_heif() -> bool:
    """若有安裝 pillow-heif，讓 Pillow 能直接開啟 iPhone HEIC 照片。"""
    try:
        from pillow_heif import register_heif_opener  # type: ignore
        register_heif_opener()
        return True
    except Exception:
        return False


HEIF_ENABLED = register_heif()


def open_upright(path):
    """開啟照片並依 EXIF Orientation 轉正（手機直拍照片常只寫旋轉標記，不轉正會躺著出現在影片裡）。"""
    from PIL import Image, ImageOps
    img = Image.open(path)
    try:
        return ImageOps.exif_transpose(img)
    except Exception:
        return img
