#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/render.py
=============
渲染引擎，generalize 自 make_parent_child_mv.py：
逐張照片用 Pillow 渲染 Ken Burns 特效 + 硬字幕 + 交叉溶接／拍點硬切，透過 FFmpeg pipe 編碼成小片段，
最後 concat 所有片段並混入背景音樂，輸出最終 MV。

與原始腳本的差異：所有路徑/參數改為函式參數（每個專案可不同），
並透過 ctx（JobContext）即時回報 log 與進度，供網頁前端輪詢顯示。
"""

import os
import sys
import shutil
import subprocess
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from lib import photos as photos_lib

TARGET_WIDTH = 1920
TARGET_HEIGHT = 1080
FRAME_RATE = 30
# 片段一律用 CPU libx264 編碼（不碰 VideoToolbox），因此可以安全地平行處理。
# 可用環境變數 MV_RENDER_WORKERS 調整；設 1 即回到舊版序列模式。
MAX_WORKERS = max(1, int(os.environ.get("MV_RENDER_WORKERS", "0") or 0) or min(4, max(1, (os.cpu_count() or 2) // 2)))

from . import portable


def check_dependencies():
    for tool in ("ffmpeg", "ffprobe"):
        try:
            subprocess.run([tool, "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            raise RuntimeError(f"找不到 {tool}，請先安裝 FFmpeg（macOS: brew install ffmpeg／Windows: winget install Gyan.FFmpeg／Linux: apt install ffmpeg）")


def get_media_duration(path) -> float:
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", check=True)
    return float(result.stdout.strip())


def _load_font(size: int, text: str = ""):
    """舊介面：回傳 (字型, FontChoice)。字型由 portable.choose_cjk_font 依繁體缺字檢驗挑選。"""
    choice = portable.choose_cjk_font(text)
    if choice:
        return choice.load(size), choice
    return ImageFont.load_default(), None


# Ken Burns 參數：最大縮放比例（1.0 → ZOOM_MAX 或反向）
ZOOM_MAX = 1.14
# 片頭卡／片尾卡的檔名（不含副檔名）；這些片段完全靜態
STATIC_CARD_STEMS = {"片頭", "片尾", "title_card", "outro_card"}
# 每張照片額外的小幅平移（以畫布寬高比例計），交替四個方向增加變化；會先併入目標點再做安全邊界約束
PAN_FRAC = 0.012


def _smoothstep(t: float) -> float:
    """S 形緩動：起步與結束都是零速度，不會有「一開始就猛衝」或「最後急停」。"""
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    return t * t * (3.0 - 2.0 * t)


def _safe_target(cx: float, cy: float, zmax: float):
    """把運鏡終點限制在「最大縮放時取景框仍完全在畫布內」的安全範圍。

    取景框中心從畫布中心線性移向目標點、縮放也與進度同步時，只要終點落在
    最大縮放的安全帶內，整段路徑每一格都不會碰到畫布邊緣，因此不需要逐格 clamp，
    也就不會出現「先往反方向跳一下再卡住」的回彈。"""
    half_w = TARGET_WIDTH / (2.0 * zmax)
    half_h = TARGET_HEIGHT / (2.0 * zmax)
    return (min(max(cx, half_w), TARGET_WIDTH - half_w),
            min(max(cy, half_h), TARGET_HEIGHT - half_h))


def camera_box(prog: float, zoom_in: bool, target_cx: float, target_cy: float, zmax: float = ZOOM_MAX):
    """回傳第 prog（0–1）時的浮點取景框 (x0, y0, x1, y1)。全程單調、不取整。"""
    e = _smoothstep(prog)
    u = e if zoom_in else 1.0 - e            # u=0：全畫布；u=1：最大縮放、對準目標
    z = 1.0 + (zmax - 1.0) * u
    w, h = TARGET_WIDTH / z, TARGET_HEIGHT / z
    cx = TARGET_WIDTH / 2.0 + (target_cx - TARGET_WIDTH / 2.0) * u
    cy = TARGET_HEIGHT / 2.0 + (target_cy - TARGET_HEIGHT / 2.0) * u
    return (cx - w / 2.0, cy - h / 2.0, cx + w / 2.0, cy + h / 2.0)


# ── 過場設定（1.4.3：快節奏防閃爍）──────────────────────────────────────
# 舊版每張照片都「黑→亮→黑」，淡化固定 0.5 秒；快節奏（照片 1～2 秒）時一直經過黑場而閃爍。
# 新版：相鄰照片以「拍點為中心」交叉溶接；任一張太短則直接在拍點硬切；
# 只有整支 MV 的開頭與結尾保留黑場淡入淡出。總時長、照片對拍點、字幕時間都不變。
EDGE_FADE_MAX = 0.5          # 整支 MV 開頭/結尾的黑場淡入淡出上限（秒）
HARD_CUT_THRESHOLD = 1.2     # 相鄰兩張任一張 ≤ 此秒數 → 拍點硬切，不溶接
XFADE_RATIO = 0.2            # 溶接長度 = 相鄰兩張中較短者秒數 × 此比例
XFADE_MAX = 0.6              # 溶接長度上限（秒）


def transition_length(dur_a: float, dur_b: float) -> float:
    """兩張相鄰照片之間的溶接總長度（秒）；0 代表拍點硬切。"""
    shorter = min(dur_a, dur_b)
    if shorter <= HARD_CUT_THRESHOLD:
        return 0.0
    return min(XFADE_MAX, XFADE_RATIO * shorter)


def frame_range(timeline_start: float, duration: float):
    """依累計時間軸計算片段的 (起始幀, 幀數)，避免逐片 int() 捨去累積成畫面早於音樂/字幕。"""
    start_frame = int(round(timeline_start * FRAME_RATE))
    end_frame = int(round((timeline_start + duration) * FRAME_RATE))
    return start_frame, max(1, end_frame - start_frame)


class PhotoScene:
    """單張照片的預處理結果（模糊底圖＋前景＋安全焦點），可依進度產生任一時刻的畫格。"""

    def __init__(self, photo_path: Path, clip_id: int, focus_x: float = None, focus_y: float = None,
                 static: bool = False):
        self.static = static
        self.zoom_in = (clip_id % 2 == 0)

        img = portable.open_upright(photo_path).convert("RGB")
        img_w, img_h = img.size
        img_aspect = img_w / img_h
        canvas_aspect = TARGET_WIDTH / TARGET_HEIGHT

        if focus_x is None or focus_y is None:
            est_fx, est_fy = photos_lib.estimate_photo_focus(photo_path)
            if focus_x is None:
                focus_x = est_fx
            if focus_y is None:
                focus_y = est_fy
        focus_x = max(0.05, min(0.95, float(focus_x)))
        focus_y = max(0.05, min(0.95, float(focus_y)))

        if img_aspect > canvas_aspect:
            new_w = int(img_w * TARGET_HEIGHT / img_h)
            crop_x = (new_w - TARGET_WIDTH) // 2
            bg_img = img.resize((new_w, TARGET_HEIGHT)).crop((crop_x, 0, crop_x + TARGET_WIDTH, TARGET_HEIGHT))
        else:
            new_h = int(img_h * TARGET_WIDTH / img_w)
            crop_y = (new_h - TARGET_HEIGHT) // 2
            bg_img = img.resize((TARGET_WIDTH, new_h)).crop((0, crop_y, TARGET_WIDTH, crop_y + TARGET_HEIGHT))
        bg_img = bg_img.filter(ImageFilter.BoxBlur(20))

        if img_aspect > canvas_aspect:
            fg_w = TARGET_WIDTH
            fg_h = int(img_h * TARGET_WIDTH / img_w)
        else:
            fg_h = TARGET_HEIGHT
            fg_w = int(img_w * TARGET_HEIGHT / img_h)
        fg_img = img.resize((fg_w, fg_h))

        pad_x = (TARGET_WIDTH - fg_w) // 2
        pad_y = (TARGET_HEIGHT - fg_h) // 2
        self.base_canvas = bg_img.copy()
        self.base_canvas.paste(fg_img, (pad_x, pad_y))

        # 人臉/主體重心在 1920x1080 畫布上的目標像素座標，
        # 加上依片段序號交替的小幅平移後，再約束到最大縮放的安全範圍內（全程不撞邊）
        pan_mode = clip_id % 4
        pan_x = (PAN_FRAC * TARGET_WIDTH) * (1 if pan_mode == 0 else (-1 if pan_mode == 1 else 0))
        pan_y = (PAN_FRAC * TARGET_HEIGHT) * (-1 if pan_mode == 2 else (1 if pan_mode == 3 else 0))
        self.target_cx, self.target_cy = _safe_target(
            pad_x + focus_x * fg_w + pan_x, pad_y + focus_y * fg_h + pan_y, ZOOM_MAX)
        if static and (img_w, img_h) == (TARGET_WIDTH, TARGET_HEIGHT):
            # 片頭／片尾卡：直接用原圖（通常本來就是 1920x1080），不疊模糊背景
            self.base_canvas = img.copy()

    def frame(self, prog: float) -> Image.Image:
        """prog：0.0（片頭）~ 1.0（片尾），超出範圍會被夾住（溶接時鄰張停在首/末格）。"""
        if self.static:
            return self.base_canvas.copy()
        prog = 0.0 if prog < 0.0 else (1.0 if prog > 1.0 else prog)
        # Face-Aware Ken Burns：浮點取景框＋雙三次次像素重採樣＋Smoothstep 緩動
        box = camera_box(prog, self.zoom_in, self.target_cx, self.target_cy)
        return self.base_canvas.resize((TARGET_WIDTH, TARGET_HEIGHT), Image.Resampling.BICUBIC, box=box)


def _draw_subtitle(frame_img, text, font, font_choice, font_size):
    draw = ImageDraw.Draw(frame_img)
    bbox = draw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]

    current_font = font
    max_allowed_w = TARGET_WIDTH - 120
    if text_w > max_allowed_w and font_choice:
        scaled_size = int(font_size * max_allowed_w / text_w)
        current_font = font_choice.load(scaled_size)
        bbox = draw.textbbox((0, 0), text, font=current_font)
        text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]

    x_pos = (TARGET_WIDTH - text_w) // 2
    y_pos = TARGET_HEIGHT - text_h - 100
    draw.text((x_pos, y_pos), text, fill="white", font=current_font,
              stroke_width=7, stroke_fill="black")


def make_photo_clip(photo_path: Path, duration: float, clip_id: int, temp_dir: Path,
                     srt_entries: list, timeline_start: float = 0.0,
                     font_size: int = 84, focus_x: float = None, focus_y: float = None,
                     static: bool = False, font_choice=None,
                     prev: dict = None, nxt: dict = None,
                     is_first: bool = True, is_last: bool = True) -> Path:
    """產生單一照片片段。

    static=True（片頭卡、片尾卡）：完全不運鏡，畫面 1:1 固定。
    prev / nxt：相鄰照片的 task 資訊 dict（photo_path, duration, clip_id, timeline_start,
    focus_x, focus_y, static, xfade）或 None。xfade>0 時以兩張交界（拍點）為中心交叉溶接：
    本張片尾後半段漸疊下一張、片頭前半段由上一張漸退，交界那一格各 50%。
    is_first / is_last：是否為整支 MV 的第一／最後一張（只有這兩處做黑場淡入淡出）。
    單獨呼叫（不給 prev/nxt）時預設頭尾都淡黑，與舊版單片段行為相同。"""
    output_path = temp_dir / f"clip_photo_{clip_id:04d}.mp4"

    scene = PhotoScene(photo_path, clip_id, focus_x, focus_y, static)
    xf_in = float(prev.get("xfade", 0.0)) if prev else 0.0
    xf_out = float(nxt.get("xfade", 0.0)) if nxt else 0.0
    # 鄰張只在需要溶接時才載入（每個工作緒各自載入，避免跨執行緒共用影像物件）
    prev_scene = PhotoScene(prev["photo_path"], prev["clip_id"], prev.get("focus_x"), prev.get("focus_y"),
                            prev.get("static", False)) if xf_in > 0.0 else None
    next_scene = PhotoScene(nxt["photo_path"], nxt["clip_id"], nxt.get("focus_x"), nxt.get("focus_y"),
                            nxt.get("static", False)) if xf_out > 0.0 else None

    timeline_end = timeline_start + duration
    start_frame, num_frames = frame_range(timeline_start, duration)

    cmd = [
        "ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
        "-s", f"{TARGET_WIDTH}x{TARGET_HEIGHT}", "-r", str(FRAME_RATE),
        "-i", "-",
        "-c:v", "libx264", "-preset", "superfast", "-crf", "18", "-pix_fmt", "yuv420p",
        # 靜態片頭／片尾卡用 stillimage 調校（有溶接時畫面會變動，就不用）
        *(["-tune", "stillimage"] if static and not (prev_scene or next_scene) else []),
        str(output_path)
    ]
    # 注意：stderr 導向暫存檔而非 PIPE，避免大量診斷輸出塞滿 pipe buffer 造成死鎖
    # （若用 PIPE 又不即時讀取，加上手動 close() 後呼叫 communicate() 在部分 Python
    #   版本會直接拋出 "ValueError: flush of closed file"）。
    stderr_tmp = tempfile.TemporaryFile()
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=stderr_tmp)

    if font_choice is None:
        font_choice = portable.choose_cjk_font(" ".join(e.get("text", "") for e in (srt_entries or [])))
    font = font_choice.load(font_size) if font_choice else ImageFont.load_default()

    black_canvas = Image.new("RGB", (TARGET_WIDTH, TARGET_HEIGHT), "black")
    edge_fade = min(EDGE_FADE_MAX, duration / 2.0)

    for f in range(start_frame, start_frame + num_frames):
        t_frame = f / FRAME_RATE
        t_clip = t_frame - timeline_start

        frame_img = scene.frame(t_clip / duration)

        # 交叉溶接（以交界拍點為中心）
        if next_scene is not None and t_frame > timeline_end - xf_out / 2.0:
            a = (t_frame - (timeline_end - xf_out / 2.0)) / xf_out            # 0 → 0.5
            other = next_scene.frame((t_frame - nxt["timeline_start"]) / nxt["duration"])
            frame_img = Image.blend(frame_img, other, max(0.0, min(0.5, a)))
        elif prev_scene is not None and t_frame < timeline_start + xf_in / 2.0:
            a = (t_frame - (timeline_start - xf_in / 2.0)) / xf_in            # 0.5 → 1
            other = prev_scene.frame((t_frame - prev["timeline_start"]) / prev["duration"])
            frame_img = Image.blend(other, frame_img, max(0.5, min(1.0, a)))

        # 字幕在溶接之後才畫，避免字幕跟著照片淡掉
        active_sub = None
        for sub in srt_entries:
            if sub["start"] <= t_frame <= sub["end"]:
                active_sub = sub["text"]
                break
        if active_sub:
            _draw_subtitle(frame_img, active_sub, font, font_choice, font_size)

        # 只有整支 MV 的開頭/結尾做黑場淡入淡出
        if edge_fade > 0.0:
            if is_first and t_clip < edge_fade:
                frame_img = Image.blend(black_canvas, frame_img, max(0.0, t_clip / edge_fade))
            elif is_last and t_clip > duration - edge_fade:
                alpha = max(0.0, min(1.0, (duration - t_clip) / edge_fade))
                frame_img = Image.blend(black_canvas, frame_img, alpha)

        proc.stdin.write(frame_img.tobytes())

    try:
        proc.stdin.close()
    except (BrokenPipeError, OSError):
        pass
    proc.wait()

    if proc.returncode != 0:
        stderr_tmp.seek(0)
        stderr_data = stderr_tmp.read()
        stderr_tmp.close()
        raise RuntimeError(f"FFmpeg 失敗 (clip {clip_id:04d}): {stderr_data.decode('utf-8', errors='ignore')[-800:]}")
    stderr_tmp.close()
    if not output_path.exists() or output_path.stat().st_size < 1000:
        raise RuntimeError(f"產生的片段 {clip_id:04d} 是空的或遺失")

    return output_path


def render_project(photos_dir: Path, srt_file: Path, music_file: Path, output_file: Path,
                    ordered_photos: list, srt_entries: list, ctx) -> dict:
    """
    ordered_photos: [{"filename": str, "duration": float}, ...]（依播放順序）
    srt_entries: parse_srt() 的結果
    ctx: JobContext（需有 .log() 與 .progress()）
    """
    ctx.log("🔎 檢查 FFmpeg / FFprobe 是否安裝...")
    check_dependencies()

    if not music_file.exists():
        raise FileNotFoundError(f"找不到背景音樂：{music_file}")
    if not ordered_photos:
        raise ValueError("ordered_photos 是空的，請先完成照片分配")

    music_duration = get_media_duration(music_file)
    ctx.log(f"🎵 背景音樂長度：{music_duration:.2f} 秒")

    temp_dir = Path(tempfile.mkdtemp(prefix="mv_render_"))
    ctx.log(f"📁 暫存目錄：{temp_dir}")

    default_fallback = None
    for entry in ordered_photos:
        fname = entry.get("filename") if isinstance(entry, dict) else str(entry)
        p = photos_dir / fname
        if p.exists():
            default_fallback = p
            break

    # 依「全部字幕文字＋繁體探針字」挑字型：確認每個字都畫得出來，避免方框缺字
    all_text = "".join(e.get("text", "") for e in (srt_entries or []))
    font_choice = portable.choose_cjk_font(all_text)
    if font_choice is None:
        ctx.log("⚠️ 找不到任何中文字型，字幕會變成方框；請執行 mvctl fonts 下載 Noto Sans TC")
    elif font_choice.missing:
        ctx.log(f"⚠️ 字型 {font_choice} 仍缺這些字：{''.join(font_choice.missing)}（請執行 mvctl fonts 或設定 MV_FONT）")
    else:
        ctx.log(f"🔤 字幕字型：{font_choice}（已檢查全部 {len(set(all_text))} 個字皆可正常顯示）")

    tasks = []
    current_time = 0.0
    last_valid = default_fallback
    for idx, entry in enumerate(ordered_photos):
        if isinstance(entry, dict):
            filename = entry.get("filename", "")
            duration = float(entry.get("duration", 3.5))
            fx = entry.get("focus_x")
            fy = entry.get("focus_y")
            static = bool(entry.get("static"))
        else:
            filename = str(entry)
            duration = 3.5
            fx, fy = None, None
            static = False
        # 片頭卡／片尾卡一律靜態（舊的 ordered_photos.json 沒有 static 欄位時，依檔名判斷）
        if Path(filename).stem in STATIC_CARD_STEMS:
            static = True
        photo_path = photos_dir / filename
        ext = os.path.splitext(filename)[1].lower()
        renderable = {".jpg", ".jpeg", ".png", ".webp", ".bmp"} | ({".heic", ".heif"} if portable.HEIF_ENABLED else set())
        if filename == "__MISSING__" or ext not in renderable or not photo_path.exists():
            ctx.log(f"⚠️ 找不到照片 {filename}，改用替代圖片")
            photo_path = last_valid
        else:
            last_valid = photo_path
        if photo_path is None:
            raise RuntimeError("沒有任何有效的照片可用作替代圖片！")
        tasks.append((photo_path, duration, idx, current_time, fx, fy, static))
        current_time += duration

    total = len(tasks)
    ctx.log(f"📸 總照片數量：{total} 張，總時長：{current_time:.2f} 秒（已啟用 Face-Aware Ken Burns 智慧焦點運鏡）")
    ctx.progress(0, total, "rendering_clips")

    final_clips = []
    try:
        import concurrent.futures
        # 每個交界的溶接長度（0 = 拍點硬切）
        xfades = [transition_length(tasks[i][1], tasks[i + 1][1]) for i in range(total - 1)]
        n_cut = sum(1 for x in xfades if x <= 0.0)
        ctx.log(f"🎞️ 過場：{len(xfades) - n_cut} 處交叉溶接、{n_cut} 處拍點硬切（≤{HARD_CUT_THRESHOLD}s 視為快節奏）")

        def neighbor(i, xf):
            if xf <= 0.0:
                return None
            p, d, cid, ts, nfx, nfy, nst = tasks[i]
            return {"photo_path": p, "duration": d, "clip_id": cid, "timeline_start": ts,
                    "focus_x": nfx, "focus_y": nfy, "static": nst, "xfade": xf}

        ctx.log(f"🧵 平行渲染片段：{MAX_WORKERS} 個工作緒")
        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
            futs = []
            for i, (photo_path, duration, task_id, timeline_start, fx, fy, st) in enumerate(tasks):
                prev = neighbor(i - 1, xfades[i - 1]) if i > 0 else None
                nxt = neighbor(i + 1, xfades[i]) if i < total - 1 else None
                futs.append(pool.submit(
                    make_photo_clip, photo_path, duration, task_id, temp_dir, srt_entries,
                    timeline_start, focus_x=fx, focus_y=fy, static=st, font_choice=font_choice,
                    prev=prev, nxt=nxt, is_first=(i == 0), is_last=(i == total - 1)))
            fut_ids = {f: t[2] for f, t in zip(futs, tasks)}
            for fut in concurrent.futures.as_completed(futs):
                final_clips.append((fut_ids[fut], fut.result()))
                if len(final_clips) % 5 == 0 or len(final_clips) == total:
                    ctx.log(f"  [進度] 已完成 {len(final_clips)}/{total} 個片段")
                ctx.progress(len(final_clips), total, "rendering_clips")

        final_clips.sort()
        final_clip_paths = [p for _, p in final_clips]

        ctx.log("🔗 正在合併片段與混音...")
        ctx.progress(total, total, "merging")

        concat_list_path = temp_dir / "concat_list.txt"
        with open(concat_list_path, "w", encoding="utf-8") as f:
            for p in final_clip_paths:
                f.write(f"file '{p.resolve()}'\n")

        output_file.parent.mkdir(parents=True, exist_ok=True)
        cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list_path),
            "-i", str(music_file),
            *portable.final_encoder_args("6000k"),
            "-c:a", "aac", "-b:a", "192k",
            "-shortest",
            str(output_file)
        ]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
        for line in proc.stdout:
            ctx.log(line.rstrip("\n"))
        proc.wait()
        if proc.returncode != 0:
            # 硬體編碼失敗時，改用軟體編碼重試一次
            ctx.log("⚠️ 硬體編碼失敗，改用 CPU 軟體編碼重試...")
            cmd_fallback = [
                "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list_path),
                "-i", str(music_file),
                "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "192k",
                "-shortest",
                str(output_file)
            ]
            proc2 = subprocess.run(cmd_fallback, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
            ctx.log(proc2.stdout or "")
            if proc2.returncode != 0:
                raise RuntimeError("最終合併失敗（硬體與軟體編碼皆失敗）")

        final_duration = get_media_duration(output_file)
        ctx.log(f"🎉 MV 製作成功！輸出：{output_file}")
        ctx.log(f"⏱️ 最終長度：{final_duration:.2f} 秒")
        ctx.progress(total, total, "done")
        return {"output_file": str(output_file), "duration": final_duration}
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
