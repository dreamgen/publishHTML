#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/fs_browser.py
=================
本地檔案系統瀏覽器與 macOS 原生 Finder 選取輔助模組。
讓使用者在 MV Studio 網頁介面直接點選音樂檔、照片資料夾、SRT 字幕、片頭片尾與輸出路徑，
免去手動複製貼上路徑的麻煩。
"""

import os
import subprocess
import sys
from pathlib import Path
from datetime import datetime

STUDIO_DIR = Path(__file__).resolve().parent.parent
ROOT_DIR = STUDIO_DIR.parent

AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
SRT_EXTS = {".srt", ".txt", ".lrc"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".m4v"}
DOC_EXTS = {".txt", ".md", ".docx", ".doc", ".rtf", ".html", ".htm", ".odt", ".pdf", ".csv"}


def _classify_ext(ext: str) -> str:
    ext = ext.lower()
    if ext in AUDIO_EXTS:
        return "audio"
    if ext in SRT_EXTS:
        return "srt"
    if ext in IMAGE_EXTS:
        return "image"
    if ext in VIDEO_EXTS:
        return "video"
    if ext in DOC_EXTS:
        return "doc"
    return "other"


def _format_size(num_bytes: int) -> str:
    if num_bytes < 1024:
        return f"{num_bytes} B"
    if num_bytes < 1024 * 1024:
        return f"{num_bytes / 1024:.1f} KB"
    if num_bytes < 1024 * 1024 * 1024:
        return f"{num_bytes / (1024 * 1024):.1f} MB"
    return f"{num_bytes / (1024 * 1024 * 1024):.2f} GB"


def _quick_dir_summary(dir_path: Path, max_scan: int = 800) -> dict:
    """快速掃描子目錄內的照片數與音訊數，方便在資料夾列表顯示徽章。"""
    photo_count = 0
    audio_count = 0
    srt_count = 0
    subdir_count = 0
    try:
        with os.scandir(dir_path) as it:
            for idx, entry in enumerate(it):
                if idx >= max_scan:
                    break
                if entry.name.startswith("."):
                    continue
                if entry.is_dir(follow_symlinks=False):
                    subdir_count += 1
                elif entry.is_file(follow_symlinks=False):
                    ext = os.path.splitext(entry.name)[1].lower()
                    if ext in IMAGE_EXTS:
                        photo_count += 1
                    elif ext in AUDIO_EXTS:
                        audio_count += 1
                    elif ext == ".srt":
                        srt_count += 1
    except OSError:
        pass
    return {
        "photo_count": photo_count,
        "audio_count": audio_count,
        "srt_count": srt_count,
        "subdir_count": subdir_count,
    }


def resolve_initial_dir(raw_path: str | None) -> tuple[Path, str | None]:
    """
    將使用者傳入的路徑解析為存在的目錄，若傳入的是檔案路徑則回傳其父目錄與預選檔名。
    """
    preselect = None
    if raw_path:
        raw_path = raw_path.strip()
        p = Path(os.path.expanduser(raw_path))
        if not p.is_absolute():
            p = (ROOT_DIR / p).resolve()
        if p.exists():
            if p.is_file():
                return p.parent.resolve(), p.name
            if p.is_dir():
                return p.resolve(), None
        # 若路徑本身不存在（例如尚未輸出的 output.mp4），嘗試退回存在的祖先目錄
        parent = p.parent
        while parent != parent.parent:
            if parent.exists() and parent.is_dir():
                return parent.resolve(), p.name if p.suffix else None
            parent = parent.parent

    # 預設優先順序：Downloads -> MV 專案根目錄 -> Home
    downloads = Path.home() / "Downloads"
    if downloads.exists():
        return downloads.resolve(), preselect
    if ROOT_DIR.exists():
        return ROOT_DIR.resolve(), preselect
    return Path.home().resolve(), preselect


def build_shortcuts(extra_dirs: list[dict] | None = None) -> list[dict]:
    """回傳常用快速捷徑目錄清單。"""
    home = Path.home()
    candidates = [
        {"label": "🎬 MV 專案目錄", "path": ROOT_DIR, "icon": "🎬"},
        {"label": "📥 下載項目 (Downloads)", "path": home / "Downloads", "icon": "📥"},
        {"label": "🖥️ 桌面 (Desktop)", "path": home / "Desktop", "icon": "🖥️"},
        {"label": "📄 文件 (Documents)", "path": home / "Documents", "icon": "📄"},
        {"label": "🏠 家目錄 (Home)", "path": home, "icon": "🏠"},
    ]
    out = []
    seen = set()
    for item in (extra_dirs or []):
        p_str = item.get("path")
        if not p_str:
            continue
        p = Path(p_str)
        if p.exists() and p.is_file():
            p = p.parent
        if p.exists() and p.is_dir():
            rp = str(p.resolve())
            if rp not in seen:
                seen.add(rp)
                out.append({
                    "label": item.get("label", p.name),
                    "path": rp,
                    "icon": item.get("icon", "📌"),
                })

    for c in candidates:
        p = c["path"]
        if p.exists() and p.is_dir():
            rp = str(p.resolve())
            if rp not in seen:
                seen.add(rp)
                out.append({
                    "label": c["label"],
                    "path": rp,
                    "icon": c["icon"],
                })
    return out


def build_breadcrumbs(dir_path: Path) -> list[dict]:
    """將絕對路徑拆解為可點擊的麵包屑導覽。"""
    parts = dir_path.parts
    crumbs = []
    acc = Path("/")
    crumbs.append({"name": "/", "path": "/"})
    for part in parts[1:]:
        acc = acc / part
        crumbs.append({"name": part, "path": str(acc)})
    return crumbs


def detect_folder_companions(dir_path: Path) -> dict:
    """
    偵測當前資料夾內是否同時含有音樂檔、SRT 字幕檔、片頭/片尾或照片子資料夾，
    方便使用者一鍵帶入整套專案素材路徑。
    """
    audios = []
    srts = []
    title_card = None
    outro_card = None
    photo_count = 0
    best_photo_subdir = None
    best_photo_subdir_count = 0

    try:
        with os.scandir(dir_path) as it:
            for entry in it:
                if entry.name.startswith("."):
                    continue
                if entry.is_dir(follow_symlinks=False):
                    sub_summary = _quick_dir_summary(Path(entry.path))
                    if sub_summary["photo_count"] > best_photo_subdir_count:
                        best_photo_subdir_count = sub_summary["photo_count"]
                        best_photo_subdir = str(Path(entry.path).resolve())
                    continue
                if not entry.is_file(follow_symlinks=False):
                    continue
                ext = os.path.splitext(entry.name)[1].lower()
                if ext in AUDIO_EXTS:
                    audios.append(str(Path(entry.path).resolve()))
                elif ext == ".srt":
                    srts.append(str(Path(entry.path).resolve()))
                elif ext in IMAGE_EXTS:
                    photo_count += 1
                    if "片頭" in entry.name or entry.name.lower().startswith("title"):
                        title_card = entry.name
                    elif "片尾" in entry.name or entry.name.lower().startswith("outro"):
                        outro_card = entry.name
    except OSError:
        pass

    audios.sort()
    srts.sort(key=lambda p: (0 if "generated" in Path(p).name else 1, p))

    resolved_photos_dir = str(dir_path.resolve()) if photo_count > 0 else best_photo_subdir
    resolved_photo_count = photo_count if photo_count > 0 else best_photo_subdir_count

    return {
        "music_file": audios[0] if audios else None,
        "srt_file": srts[0] if srts else None,
        "photos_dir": resolved_photos_dir,
        "photo_count": resolved_photo_count,
        "title_card_file": title_card,
        "outro_file": outro_card,
    }


def list_directory(
    target_path: str | None = None,
    mode: str = "all",
    show_all_files: bool = False,
    extra_shortcuts: list[dict] | None = None,
) -> dict:
    """
    列出指定目錄下的資料夾與檔案清單。
    mode:
      - 'dir'    : 選取資料夾（顯示所有子資料夾，並標示每個資料夾內含幾張照片/音樂）
      - 'audio'  : 選取音樂檔（.mp3, .wav, .m4a, .aac, .flac, .ogg）
      - 'srt'    : 選取字幕檔（.srt, .txt, .lrc）
      - 'image'  : 選取圖片檔（.jpg, .jpeg, .png, .webp）
      - 'output' : 選取輸出影片路徑（.mp4 等，或直接指定目前資料夾 + 檔名）
      - 'all'    : 顯示全部檔案
    """
    cur_dir, preselect = resolve_initial_dir(target_path)
    parent_dir = str(cur_dir.parent) if cur_dir.parent != cur_dir else None

    dirs = []
    files = []

    allowed_kinds = None
    if not show_all_files:
        if mode == "audio":
            allowed_kinds = {"audio"}
        elif mode == "srt":
            allowed_kinds = {"srt"}
        elif mode == "doc":
            allowed_kinds = {"doc", "srt"}
        elif mode == "image":
            allowed_kinds = {"image"}
        elif mode in ("video", "output"):
            allowed_kinds = {"video"}
        elif mode == "dir":
            # dir 模式下仍可顯示最多 30 張照片預覽，讓使用者確認沒選錯資料夾
            allowed_kinds = {"image", "audio", "srt"}

    try:
        with os.scandir(cur_dir) as it:
            for entry in it:
                if entry.name.startswith("."):
                    continue
                try:
                    st = entry.stat(follow_symlinks=False)
                except OSError:
                    continue

                mtime_iso = datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")
                full_path = str(Path(entry.path).resolve())

                if entry.is_dir(follow_symlinks=False):
                    summary = _quick_dir_summary(Path(entry.path))
                    dirs.append({
                        "name": entry.name,
                        "path": full_path,
                        "is_dir": True,
                        "kind": "dir",
                        "mtime": mtime_iso,
                        "mtime_ts": st.st_mtime,
                        "photo_count": summary["photo_count"],
                        "audio_count": summary["audio_count"],
                        "srt_count": summary["srt_count"],
                        "subdir_count": summary["subdir_count"],
                    })
                elif entry.is_file(follow_symlinks=False):
                    ext = os.path.splitext(entry.name)[1].lower()
                    kind = _classify_ext(ext)
                    if allowed_kinds is not None and kind not in allowed_kinds:
                        continue
                    files.append({
                        "name": entry.name,
                        "path": full_path,
                        "is_dir": False,
                        "kind": kind,
                        "ext": ext,
                        "size": st.st_size,
                        "size_human": _format_size(st.st_size),
                        "mtime": mtime_iso,
                        "mtime_ts": st.st_mtime,
                    })
    except PermissionError:
        return {
            "error": f"沒有權限讀取目錄：{cur_dir}",
            "current_path": str(cur_dir),
            "parent_path": parent_dir,
            "breadcrumbs": build_breadcrumbs(cur_dir),
            "shortcuts": build_shortcuts(extra_shortcuts),
            "entries": [],
            "current_dir_stats": {"photo_count": 0, "audio_count": 0, "srt_count": 0},
            "companions": {},
        }

    # 資料夾優先：有照片或音訊的資料夾排前面，或依名稱排序
    dirs.sort(key=lambda d: d["name"].lower())
    files.sort(key=lambda f: f["name"].lower())

    # 若為 dir 模式，檔案只保留前 25 筆供預覽確認，避免數百張照片洗版資料夾清單
    preview_files_truncated = False
    if mode == "dir" and not show_all_files and len(files) > 25:
        files = files[:25]
        preview_files_truncated = True

    cur_stats = _quick_dir_summary(cur_dir)
    companions = detect_folder_companions(cur_dir)

    return {
        "current_path": str(cur_dir),
        "parent_path": parent_dir,
        "preselect": preselect,
        "mode": mode,
        "breadcrumbs": build_breadcrumbs(cur_dir),
        "shortcuts": build_shortcuts(extra_shortcuts),
        "current_dir_stats": cur_stats,
        "companions": companions,
        "preview_files_truncated": preview_files_truncated,
        "entries": dirs + files,
    }


# 非 macOS 使用 tkinter 對話框。放在獨立的子行程執行：tkinter 要求在固定執行緒建立視窗，
# 而網頁伺服器是多執行緒；子行程也能避免 tkinter 當機連帶拖垮伺服器。
_TK_PICK_SCRIPT = r"""
import sys
try:
    import tkinter
    from tkinter import filedialog
except Exception:
    sys.exit(3)   # tkinter 不可用
mode, initial_dir, default_name = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    root = tkinter.Tk()
    root.withdraw()
    root.attributes("-topmost", True)   # 讓對話框浮在瀏覽器前面
    root.update()
except Exception:
    sys.exit(3)   # 例如 Linux 沒有顯示環境
kw = {"parent": root, "initialdir": initial_dir}
types = {
    "audio": [("音樂檔", "*.mp3 *.wav *.m4a *.aac *.flac *.ogg"), ("所有檔案", "*.*")],
    "srt": [("字幕／歌詞", "*.srt *.txt"), ("所有檔案", "*.*")],
    "image": [("圖片", "*.png *.jpg *.jpeg"), ("所有檔案", "*.*")],
    "doc": [("文件", "*.docx *.pdf *.txt *.md"), ("所有檔案", "*.*")],
}
try:
    if mode == "dir":
        path = filedialog.askdirectory(title="請選擇照片資料夾", mustexist=True, **kw)
    elif mode == "output":
        path = filedialog.asksaveasfilename(title="請選擇輸出影片儲存位置", initialfile=default_name or "output_MV.mp4",
                                            defaultextension=".mp4", filetypes=[("MP4 影片", "*.mp4")], **kw)
    else:
        path = filedialog.askopenfilename(title="請選擇檔案", filetypes=types.get(mode, [("所有檔案", "*.*")]), **kw)
finally:
    root.destroy()
if not path:
    sys.exit(4)   # 使用者取消
sys.stdout.buffer.write(path.encode("utf-8"))
"""


def _tk_pick_path(mode: str, start_dir, default_name) -> dict:
    """tkinter 版選取視窗。失敗時回傳 fallback=True，讓前端改用內建檔案瀏覽器。"""
    try:
        proc = subprocess.run(
            [sys.executable, "-c", _TK_PICK_SCRIPT, mode, str(start_dir), default_name or ""],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300,
        )
    except Exception as e:
        return {"ok": False, "fallback": True, "error": f"無法開啟系統選取視窗（{e}），改用內建檔案瀏覽器"}
    if proc.returncode == 4:
        return {"ok": False, "cancelled": True}
    if proc.returncode != 0:
        return {"ok": False, "fallback": True,
                "error": "此電腦無法開啟系統選取視窗（tkinter 不可用或沒有顯示環境），改用內建檔案瀏覽器"}
    return {"ok": True, "path": proc.stdout.decode("utf-8", errors="replace").strip()}


def native_pick_path(mode: str = "dir", initial_dir: str | None = None, default_name: str | None = None) -> dict:
    """
    呼叫系統原生對話框讓使用者選取檔案或資料夾：
    macOS 用 Finder（osascript），其他平台用 tkinter.filedialog。
    若使用者按下取消，回傳 {"ok": False, "cancelled": True}；
    若系統對話框不可用，回傳 {"ok": False, "fallback": True, "error": …}，前端會退回內建檔案瀏覽器。
    """
    start_dir, _ = resolve_initial_dir(initial_dir)
    if sys.platform != "darwin":
        return _tk_pick_path(mode, start_dir, default_name)
    escaped_dir = str(start_dir).replace("\\", "\\\\").replace('"', '\\"')
    if mode == "dir":
        script = (
            f'POSIX path of (choose folder with prompt "請選擇照片資料夾：" '
            f'default location (POSIX file "{escaped_dir}"))'
        )
    elif mode == "output":
        fname = (default_name or "output_MV.mp4").replace('"', '\\"')
        script = (
            f'POSIX path of (choose file name with prompt "請選擇輸出影片儲存位置：" '
            f'default name "{fname}" default location (POSIX file "{escaped_dir}"))'
        )
    else:
        prompt_map = {
            "audio": "請選擇音樂檔案（MP3 / WAV / M4A）：",
            "srt": "請選擇字幕檔案（SRT）：",
            "image": "請選擇圖片檔案（PNG / JPG）：",
        }
        prompt_str = prompt_map.get(mode, "請選擇檔案：")
        script = (
            f'POSIX path of (choose file with prompt "{prompt_str}" '
            f'default location (POSIX file "{escaped_dir}"))'
        )

    try:
        proc = subprocess.run(
            ["osascript", "-e", script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
            timeout=120,
        )
        if proc.returncode != 0:
            err = (proc.stderr or "").strip()
            if "-128" in err or "User canceled" in err or "使用者已取消" in err:
                return {"ok": False, "cancelled": True}
            return {"ok": False, "error": err or "無法開啟系統檔案選取視窗"}
        chosen = proc.stdout.strip()
        if chosen.endswith("/") and len(chosen) > 1:
            chosen = chosen.rstrip("/")
        return {"ok": True, "path": chosen}
    except Exception as e:
        return {"ok": False, "error": str(e)}
