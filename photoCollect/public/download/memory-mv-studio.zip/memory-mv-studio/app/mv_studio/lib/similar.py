"""
相似照片分組（MV Studio 照片挑選 第二階段）

作法：
  1. 每張照片算一個 64-bit dHash 感知指紋（JPEG 用 draft 模式縮小解碼，數百張約數秒）。
  2. 依拍攝時間排序，時間相近且指紋相近者歸為同一組（Union-Find）：
       - 拍攝時間相差 ≤ 30 秒，且漢明距離 ≤ 15
       - 或相差 ≤ 180 秒，且漢明距離 ≤ 6（幾乎一樣的畫面）
  3. 指紋存在專案 .cache/phash.json（以檔案 mtime/size 為快取鍵），不寫入 photo_catalog.json，
     避免與 AI 分析、手動標記同時寫 catalog 時互相覆蓋。
  沒有 EXIF 拍攝時間的照片改用檔名流水號判斷相鄰（同前綴、號碼相差 ≤ 5，或 ≤ 20 且幾乎一樣）。
"""

import json
import os
from datetime import datetime
from pathlib import Path

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover
    Image = None
    ImageOps = None

TIME_WINDOW_S = 30
HAMMING_MAX = 15
TIME_WINDOW_WIDE_S = 180
HAMMING_STRICT = 6
SEQ_WINDOW = 5          # 無 EXIF 時：流水號相差 ≤ 5 視為連拍範圍
SEQ_WINDOW_WIDE = 20


def cache_path_of(project_dir: Path) -> Path:
    return Path(project_dir) / ".cache" / "phash.json"


def load_cache(path: Path) -> dict:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_cache(path: Path, data: dict):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def _local_src(entry: dict, photos_dir: Path):
    if entry.get("abs_path"):
        p = Path(entry["abs_path"])
        if p.exists():
            return p
    p = Path(photos_dir) / entry["filename"]
    return p if p.exists() else None


def _src_key(entry: dict, src):
    if src is not None:
        st = src.stat()
        return f"{int(st.st_mtime)}|{st.st_size}|up1"
    if entry.get("remote_url"):
        return "remote|" + entry["remote_url"]
    return None


def dhash(img) -> str:
    g = img.convert("L").resize((9, 8), Image.LANCZOS)
    px = list(g.getdata())
    bits = 0
    for r in range(8):
        row = r * 9
        for c in range(8):
            bits = (bits << 1) | (1 if px[row + c] > px[row + c + 1] else 0)
    return f"{bits:016x}"


def pending_entries(catalog: dict, cache: dict, photos_dir: Path) -> list:
    """回傳需要（重新）計算指紋的 catalog 條目（只看已分析的照片）。"""
    out = []
    for e in catalog.get("photos", []):
        if not e.get("analyzed"):
            continue
        src = _local_src(e, photos_dir)
        key = _src_key(e, src)
        if key is None:
            continue
        c = cache.get(e["filename"])
        if not c or c.get("k") != key:
            out.append(e)
    return out


def compute_hashes(ctx, catalog_path: Path, photos_dir: Path, thumb_cache_dir: Path, hash_cache: Path, photos_lib):
    """背景工作：補齊缺少的指紋。ctx 為 jobs.JobContext。"""
    if Image is None:
        raise RuntimeError("需要 Pillow 才能計算相似度")
    catalog = photos_lib.load_catalog(catalog_path)
    cache = load_cache(hash_cache)
    todo = pending_entries(catalog, cache, photos_dir)
    total = len(todo)
    ctx.log(f"需要計算相似度指紋：{total} 張")
    for i, e in enumerate(todo):
        if ctx.is_cancelled():
            break
        fn = e["filename"]
        src = _local_src(e, photos_dir)
        key = _src_key(e, src)
        h = None
        try:
            if src is not None:
                with Image.open(src) as img:
                    try:
                        img.draft("RGB", (160, 160))
                    except Exception:
                        pass
                    up = ImageOps.exif_transpose(img) if ImageOps else img  # 與縮圖一致，用轉正後的畫面
                    h = dhash(up)
            else:
                thumb = photos_lib.get_thumbnail(fn, catalog_path, photos_dir, thumb_cache_dir)
                if thumb:
                    with Image.open(thumb) as img:
                        h = dhash(img)
        except Exception as ex:  # 壞檔不重試，記錄 None
            ctx.log(f"⚠️ {fn} 無法計算：{ex}")
        cache[fn] = {"h": h, "k": key}
        if (i + 1) % 25 == 0:
            save_cache(hash_cache, cache)
            ctx.progress(i + 1, total, "計算相似度指紋")
    save_cache(hash_cache, cache)
    ctx.progress(total, total, "完成")
    ctx.set_result({"hashed": total})


def _parse_time(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(str(s)[:19])
    except ValueError:
        return None


_SEQ_RE = None


def _seq_key(filename: str):
    """沒有 EXIF 時間時的退路：檔名流水號，例如 IMG_3999.JPG → ('img_', 3999)。"""
    global _SEQ_RE
    if _SEQ_RE is None:
        import re
        _SEQ_RE = re.compile(r"^(.*?)(\d{3,})(?!.*\d)")
    stem = Path(filename).stem
    import re as _re
    stem = _re.sub(r"\s*\(\d+\)$", "", stem)  # 「IMG_1234 (2)」這類複本
    m = _SEQ_RE.match(stem)
    if not m:
        return None
    return (m.group(1).lower(), int(m.group(2)))


def build_groups(photos: list, cache: dict) -> dict:
    """回傳 {filename: group_id}，只包含 2 張以上的群組。"""
    timed, seq = [], []
    for p in photos:
        c = cache.get(p["filename"]) or {}
        if not c.get("h"):
            continue
        h = int(c["h"], 16)
        t = _parse_time(p.get("exif_time"))
        if t is not None:
            timed.append((t, p["filename"], h))
        else:
            k = _seq_key(p["filename"])
            if k is not None:
                seq.append((k, p["filename"], h))
    timed.sort(key=lambda x: (x[0], x[1]))
    seq.sort(key=lambda x: (x[0], x[1]))

    parent = {fn: fn for _, fn, _ in timed + seq}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    # 有拍攝時間：時間窗內比較
    for i in range(len(timed)):
        ti, fi, hi = timed[i]
        for j in range(i + 1, len(timed)):
            tj, fj, hj = timed[j]
            dt = (tj - ti).total_seconds()
            if dt > TIME_WINDOW_WIDE_S:
                break
            d = bin(hi ^ hj).count("1")
            if (dt <= TIME_WINDOW_S and d <= HAMMING_MAX) or d <= HAMMING_STRICT:
                union(fi, fj)

    # 沒有拍攝時間：同前綴、流水號相近者比較（連拍通常是連號）
    for i in range(len(seq)):
        (pi, ni), fi, hi = seq[i]
        for j in range(i + 1, len(seq)):
            (pj, nj), fj, hj = seq[j]
            if pj != pi or nj - ni > SEQ_WINDOW_WIDE:
                break
            d = bin(hi ^ hj).count("1")
            if (nj - ni <= SEQ_WINDOW and d <= HAMMING_MAX) or d <= HAMMING_STRICT:
                union(fi, fj)

    members = {}
    for _, fn, _ in timed + seq:  # 依時間／流水號順序編號
        members.setdefault(find(fn), []).append(fn)
    out, n = {}, 0
    for fns in members.values():
        if len(fns) < 2:
            continue
        n += 1
        for fn in fns:
            out[fn] = f"g{n}"
    return out
