#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/lyrics.py
=============
SRT 字幕解析/寫出，以及「歌詞逐行主題標籤」→「照片時間槽時間軸」的建置邏輯。
邏輯上 generalize 自 prepare_content_plan.py，差異是：
  - 不再用寫死的 SRT_THEME_MAP，改讀每行歌詞已標記好的 theme 欄位
  - TitleCard / Outro 素材檔名與時長改為每個專案可自訂
"""

import re
import subprocess
from pathlib import Path
from lib import beats as beats_lib


def get_media_duration(path) -> float:
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", check=True)
        return float(result.stdout.strip())
    except Exception:
        return 0.0


def format_srt_timestamp(seconds: float) -> str:
    if seconds < 0:
        seconds = 0.0
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    if ms >= 1000:
        s += 1
        ms -= 1000
    if s >= 60:
        m += 1
        s -= 60
    if m >= 60:
        h += 1
        m -= 60
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def parse_srt(path) -> list:
    """解析 SRT 檔案，回傳 [{idx, start, end, text}, ...]（不含 theme 欄位）。"""
    p = Path(path)
    if not p.exists():
        return []
    content = p.read_text(encoding="utf-8")
    blocks = re.split(r"\n\n+", content.strip())
    entries = []
    for block in blocks:
        lines = block.strip().splitlines()
        if len(lines) < 3:
            continue
        try:
            idx = int(lines[0].strip())
        except ValueError:
            continue
        ts = lines[1]
        text = "\n".join(lines[2:]).strip()
        times = re.findall(r"(\d{2}):(\d{2}):(\d{2})[,.](\d{3})", ts)
        if len(times) == 2:
            def to_sec(t):
                return int(t[0]) * 3600 + int(t[1]) * 60 + int(t[2]) + int(t[3]) / 1000
            entries.append({
                "idx": idx,
                "start": round(to_sec(times[0]), 3),
                "end": round(to_sec(times[1]), 3),
                "text": text,
            })
    return entries


def write_srt(entries: list, path):
    lines = []
    for i, e in enumerate(entries, 1):
        lines.append(str(i))
        lines.append(f"{format_srt_timestamp(e['start'])} --> {format_srt_timestamp(e['end'])}")
        lines.append(e["text"])
        lines.append("")
    Path(path).write_text("\n".join(lines), encoding="utf-8")


# ═══════════════════════════════════════════════════════════════
# 🔨 時間槽切分（整合 Beat-Snapping 節拍對齊）
# ═══════════════════════════════════════════════════════════════

def split_into_slots(
    start: float,
    duration: float,
    theme,
    subtitle,
    slot_params: dict,
    is_gap: bool = False,
    beats: list = None,
) -> list:
    if duration <= 0:
        return []
    target = slot_params.get("target_slot_duration", 3.5)
    min_slot = slot_params.get("min_slot_duration", 2.0)
    min_lyric = slot_params.get("min_lyric_slot", 2.5)
    beat_snap_enabled = bool(slot_params.get("beat_snap", True))
    max_slot = target * 1.5

    if duration <= max_slot:
        n = 1
    else:
        n = max(1, round(duration / target))
        per = duration / n
        if per < (min_slot if is_gap else min_lyric) and n > 1:
            n -= 1

    end = start + duration
    min_allowed = (min_slot if is_gap else min_lyric) * 0.85

    if n > 1 and beat_snap_enabled and beats:
        boundaries, snap_offsets = beats_lib.snap_boundaries_to_beats(
            start=start,
            end=end,
            n_slots=n,
            beats=beats,
            min_slot_duration=max(1.5, min_allowed),
            max_snap_window=0.48 if is_gap else 0.35,
        )
    else:
        per = duration / n
        boundaries = [round(start + i * per, 3) for i in range(n)] + [round(end, 3)]
        snap_offsets = [None] * n

    slots = []
    for i in range(n):
        s = boundaries[i]
        e = boundaries[i + 1]
        offset = snap_offsets[i] if i < len(snap_offsets) else None
        slots.append({
            "start": round(s, 3),
            "end": round(e, 3),
            "duration": round(e - s, 3),
            "theme": theme,
            "subtitle": subtitle,
            "is_gap": is_gap,
            "beat_snapped": offset is not None,
            "beat_offset_ms": int(round(offset * 1000)) if offset is not None else 0,
            "assigned_photo": None,
        })
    return slots


def _snap_point_in_window(ideal_t: float, lo: float, hi: float, beats: list) -> tuple[float, bool]:
    """在 [lo, hi] 區間內尋找最接近且強勁的節拍點，用於微小換氣間隙的照片切換點對齊。"""
    if not beats or hi - lo < 0.08:
        return round(ideal_t, 3), False
    cands = [b for b in beats if lo <= b["time"] <= hi]
    if not cands:
        return round(ideal_t, 3), False
    span = max(0.1, hi - lo)
    best = max(cands, key=lambda b: (1.0 - abs(b["time"] - ideal_t) / span) + 0.4 * b.get("strength", 0.5))
    return round(best["time"], 3), True


def build_timeline(
    lyrics_entries: list,
    total_duration: float,
    slot_params: dict,
    title_card_file: str,
    title_card_duration: float,
    outro_file: str,
    outro_duration: float,
    default_theme: str = "General",
    beats: list = None,
) -> list:
    """
    以逐行已標記主題的歌詞為骨幹，建立完整的照片時槽時間軸。
    若傳入 beats（由 beats.analyze_audio_beats 產生）且開啟 beat_snap，
    間奏切分點與換氣間隙切換點將自動精準踩在音樂重拍上。
    """
    gap_merge_threshold = slot_params.get("gap_merge_threshold", 2.0)
    beat_snap_enabled = bool(slot_params.get("beat_snap", True))
    outro_start = total_duration - outro_duration
    slots = []
    slot_id = 0

    slots.append({
        "slot_id": slot_id,
        "start": 0.0, "end": title_card_duration,
        "duration": title_card_duration,
        "theme": "TitleCard", "subtitle": None,
        "is_gap": False, "beat_snapped": False, "beat_offset_ms": 0,
        "assigned_photo": title_card_file,
    })
    slot_id += 1
    cursor = title_card_duration

    entries = sorted(lyrics_entries, key=lambda e: e["start"])

    for i, entry in enumerate(entries):
        theme = entry.get("theme") or default_theme

        if entry["end"] <= cursor:
            continue
        if entry["start"] >= outro_start:
            break

        eff_end = min(entry["end"], outro_start)

        if entry["start"] > cursor:
            gap_duration = entry["start"] - cursor
            if gap_duration >= gap_merge_threshold:
                # 若間奏結束點（歌詞開始前）附近 ±0.25s 有強拍，保持歌詞起始點精準對齊，
                # 並將間奏內部切分點透過 beats 吸附至鼓點
                gap_slots = split_into_slots(
                    cursor, gap_duration, theme, None, slot_params, is_gap=True, beats=beats
                )
                for s in gap_slots:
                    s["slot_id"] = slot_id
                    slot_id += 1
                slots.extend(gap_slots)
                cursor = entry["start"]
            elif beat_snap_enabled and beats and slots and not slots[-1].get("assigned_photo"):
                # 小於門檻的換氣間隙 [cursor, entry["start"]]：
                # 若此區間內有明顯鼓點，將前一個槽的結束點與本槽的起始點推進至該鼓點！
                snapped_cut, did_snap = _snap_point_in_window(
                    cursor + gap_duration * 0.5, cursor, min(entry["start"], outro_start), beats
                )
                if did_snap and snapped_cut > slots[-1]["start"] + 1.5:
                    slots[-1]["end"] = snapped_cut
                    slots[-1]["duration"] = round(snapped_cut - slots[-1]["start"], 3)
                    slots[-1]["beat_snapped"] = True
                    cursor = snapped_cut

        eff_start = cursor
        duration = eff_end - eff_start
        if duration < 0.1:
            cursor = eff_end
            continue

        entry_slots = split_into_slots(
            eff_start, duration, theme, entry["text"], slot_params, is_gap=False, beats=beats
        )
        for s in entry_slots:
            s["slot_id"] = slot_id
            slot_id += 1
        slots.extend(entry_slots)
        cursor = eff_end

    if cursor < outro_start - 0.05:
        tail_duration = outro_start - cursor
        tail_slots = split_into_slots(
            cursor, tail_duration, "Outro", None, slot_params, is_gap=True, beats=beats
        )
        for s in tail_slots:
            s["slot_id"] = slot_id
            slot_id += 1
        slots.extend(tail_slots)

    slots.append({
        "slot_id": slot_id,
        "start": round(outro_start, 3),
        "end": round(total_duration, 3),
        "duration": round(outro_duration, 3),
        "theme": "Outro", "subtitle": None,
        "is_gap": False, "beat_snapped": False, "beat_offset_ms": 0,
        "assigned_photo": outro_file,
    })

    min_slot_limit = slot_params.get("min_slot_duration", 2.0)
    slots = sanitize_timeline_slots(slots, min_duration=min_slot_limit)
    return slots


def sanitize_timeline_slots(slots: list, min_duration: float = 2.0) -> list:
    """
    確保時間軸中沒有任何短於 min_duration（預設 2.0 秒）的過短時槽，
    避免照片在 1 秒內快速切換造成視覺上的倉促跳躍感。
    Pass 1: 將極短時槽（< 1.5s）向相鄰照片時槽合併。
    Pass 2: 將仍短於 min_duration 的時槽與相鄰較長時槽重新均分時間。
    """
    if len(slots) <= 2:
        return slots

    i = 1
    while i < len(slots) - 1:
        if slots[i]["duration"] < 1.5:
            prev = slots[i - 1]
            if not prev.get("assigned_photo"):
                prev["end"] = slots[i]["end"]
                prev["duration"] = round(prev["end"] - prev["start"], 3)
                if not prev.get("subtitle") and slots[i].get("subtitle"):
                    prev["subtitle"] = slots[i]["subtitle"]
                slots.pop(i)
                continue
            else:
                nxt = slots[i + 1]
                nxt["start"] = slots[i]["start"]
                nxt["duration"] = round(nxt["end"] - nxt["start"], 3)
                slots.pop(i)
                continue
        i += 1

    for i in range(1, len(slots) - 1):
        if slots[i]["duration"] < min_duration:
            prev = slots[i - 1]
            if not prev.get("assigned_photo") and prev["duration"] > min_duration + 0.6:
                tot = round(slots[i]["end"] - prev["start"], 3)
                mid = round(prev["start"] + tot / 2.0, 3)
                prev["end"] = mid
                prev["duration"] = round(prev["end"] - prev["start"], 3)
                slots[i]["start"] = mid
                slots[i]["duration"] = round(slots[i]["end"] - slots[i]["start"], 3)

    for idx, s in enumerate(slots):
        s["slot_id"] = idx
    return slots


def compute_theme_requirements(slots: list) -> dict:
    reqs = {}
    for slot in slots:
        theme = slot["theme"]
        if slot.get("assigned_photo"):
            continue
        reqs.setdefault(theme, {"total_seconds": 0.0, "photos_needed": 0, "slot_ids": []})
        reqs[theme]["total_seconds"] = round(reqs[theme]["total_seconds"] + slot["duration"], 3)
        reqs[theme]["photos_needed"] += 1
        reqs[theme]["slot_ids"].append(slot["slot_id"])
    return reqs
