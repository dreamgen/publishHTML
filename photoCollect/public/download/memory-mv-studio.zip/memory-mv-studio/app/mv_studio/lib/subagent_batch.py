#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/subagent_batch.py
=====================
將 CLI 的 Multi-Subagent 批次視覺分析能力整合進 MV Studio 多專案架構。

核心功能：
1. 自動掃描新照片並預先產生輕量縮圖（.cache/thumbs/），讓 Subagent 透過 view_file / read_file
   看圖時速度提升 5~10 倍、大幅節省 Context Token。
2. 讀取該專案自訂的 themes（名稱 + 關鍵字）與 content_plan.json（各主題需求張數），
   依據待分析照片數量自動切分為多個 Subagent 分組（Shards）。
3. 產出標準化的 `subagent_task.json` 與專屬每個 Shard 的 Subagent Prompt，
   支援從對話中直接由主 Agent 派發多個 Subagents 並行分析。
4. 支援單一或多個 Subagent 回傳的 JSON 結果批次匯入 `photo_catalog.json`，
   自動驗證主題、補齊 fit_scores 矩陣、更新專案狀態，並寫入 jobs/subagent.json 供前端即時感知。
"""

import json
import math
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional

from lib import store, photos as photos_lib


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def compute_subagent_shards(pending_photos: list[dict], max_per_agent: int = 15) -> list[list[dict]]:
    """
    依據 photo_analysis_protocol.md 的平行化規則，將待分析照片切分為 Subagent 分組：
    - 0 張       → []
    - 1–15 張    → 1 組（可在主 Agent 或 1 個 Subagent 分析）
    - 16–40 張   → 2 組（均分）
    - 41–60 張   → 3 組（均分）
    - > 60 張    → 依 max_per_agent（預設 15 張/組）切分為 N 組
    """
    n = len(pending_photos)
    if n == 0:
        return []
    if n <= max_per_agent:
        num_shards = 1
    elif n <= 40 and max_per_agent >= 15:
        num_shards = 2
    elif n <= 60 and max_per_agent >= 15:
        num_shards = 3
    else:
        num_shards = max(1, math.ceil(n / max(1, max_per_agent)))

    shards = []
    base_size = n // num_shards
    remainder = n % num_shards
    start = 0
    for i in range(num_shards):
        size = base_size + (1 if i < remainder else 0)
        if size > 0:
            shards.append(pending_photos[start:start + size])
            start += size
    return shards


def compute_theme_coverage(catalog: dict, themes: list[dict], content_plan: Optional[dict] = None) -> dict:
    """
    計算目前 catalog 中各主題的已分析照片數，以及對照 content_plan.json 的需求缺口。
    """
    theme_names = [t["name"] for t in themes]
    counts = {t: 0 for t in theme_names}
    for p in catalog.get("photos", []):
        if p.get("analyzed") and p.get("theme") in counts:
            counts[p["theme"]] += 1

    reqs = (content_plan or {}).get("theme_requirements", {})
    coverage = {}
    for t in theme_names:
        needed = reqs.get(t, {}).get("photos_needed", 0)
        have = counts.get(t, 0)
        coverage[t] = {
            "analyzed_count": have,
            "photos_needed": needed,
            "deficit": max(0, needed - have),
            "sufficient": have >= needed if needed > 0 else have > 0,
        }
    return coverage


def build_subagent_prompt(
    project_id: str,
    song_title: str,
    shard_id: int,
    total_shards: int,
    shard_photos: list[dict],
    themes: list[dict],
    coverage: Optional[dict] = None,
    use_thumbnails: bool = True,
) -> str:
    """
    為單一 Subagent 分組生成可直接派發的完整視覺分析 Prompt。
    """
    theme_lines = []
    fit_score_lines = []
    for t in themes:
        name = t["name"]
        kws = "、".join(t.get("keywords", [])) or "依主題字面意義判斷"
        cov_hint = ""
        if coverage and name in coverage:
            c = coverage[name]
            if c["photos_needed"] > 0:
                cov_hint = f"（需求 {c['photos_needed']} 張，已有 {c['analyzed_count']} 張）"
        theme_lines.append(f"- {name}: {kws}{cov_hint}")
        fit_score_lines.append(f'        "{name}": 0.0')

    themes_block = "\n".join(theme_lines)
    fit_scores_block = ",\n".join(fit_score_lines)

    photo_lines = []
    for idx, p in enumerate(shard_photos, 1):
        view_target = p.get("thumb_path") if (use_thumbnails and p.get("thumb_path")) else p.get("abs_path")
        line = (
            f"{idx}. filename: \"{p['filename']}\"\n"
            f"   view_path: {view_target}\n"
            f"   abs_path:  {p.get('abs_path', '')}"
        )
        # 雲端收照片帶來的提示（依拍攝時間推得的環節、上傳者標的小隊）；只是參考，仍以實際畫面為準
        hints = []
        if p.get("theme_hint"):
            hints.append(f"環節「{p['theme_hint']}」")
        if p.get("protagonists"):
            hints.append("小隊／人物「" + "、".join(p["protagonists"]) + "」")
        if hints:
            line += "\n   hint: 上傳時標示 " + "，".join(hints) + "（僅供參考，請以畫面為準）"
        photo_lines.append(line)
    photos_block = "\n".join(photo_lines)

    default_theme = themes[0]["name"] if themes else "Intro"

    return f"""You are a visual analysis subagent for MV Studio project "{song_title}" ({project_id}), Shard {shard_id}/{total_shards}.
Your task: visually inspect each assigned photo using `read_file` on its `view_path` (lightweight thumbnail) or `abs_path`, and return a structured JSON analysis.

## Assigned Photos ({len(shard_photos)} photos)
{photos_block}

## Project Themes ({len(themes)} themes)
Classify each photo into capability-matched primary `theme` from this exact list:
{themes_block}

## Scoring Rubric
- `quality_score` (0.0–10.0): Overall visual quality for a memory MV
  - 9.0–10.0: Sharp focus, expressive faces/interactions, great composition & lighting
  - 7.0–8.9:  Good quality, clear subject, minor imperfections
  - 5.0–6.9:  Acceptable, soft focus or ordinary angle
  - 1.0–4.9:  Blurry, overexposed, back of heads, or obstructed
- `fit_scores` (0.0–10.0 for EVERY theme listed above):
  - 9.0–10.0: Perfect match for that theme's activity/mood
  - 7.0–8.9:  Strong relevance, can represent that theme well
  - 4.0–6.9:  Partial/general relevance, usable as P2 fallback
  - 0.0–3.9:  Unrelated to that theme
- `focus_x`, `focus_y` (0.0–1.0): Normalized center of the main faces/smiles in the photo (`focus_x`: 0.0=left, 0.5=center, 1.0=right; `focus_y`: 0.0=top, 0.35=upper-middle face zone, 1.0=bottom) so Ken Burns zoom-in steers toward faces without cutting off heads.
- `protagonists` (list of strings): Identifiable people/groups/roles in the photo (e.g. `["孩童", "家長"]`, `["第一小隊"]`, `["老師"]`, `["全員合照"]`) for Protagonist Balancing.

## Output Format
Return ONLY a valid JSON object (no markdown fences, no extra commentary):

{{
  "project_id": "{project_id}",
  "shard_id": {shard_id},
  "analyses": [
    {{
      "filename": "exact_filename_from_list.jpg",
      "abs_path": "/absolute/path/to/file.jpg",
      "theme": "{default_theme}",
      "description": "一句話繁體中文描述畫面主體、動作與情緒（20字內）",
      "quality_score": 8.5,
      "focus_x": 0.50,
      "focus_y": 0.36,
      "protagonists": ["孩童", "家長"],
      "fit_scores": {{
{fit_scores_block}
      }}
    }}
  ]
}}

## Strict Rules
1. MUST visually inspect EVERY photo in your assigned list using `read_file` on `view_path` before scoring.
2. `filename` MUST exactly match the `filename` field given in the list above.
3. `description` MUST be in Traditional Chinese (繁體中文).
4. `fit_scores` MUST include ALL {len(themes)} themes defined above.
5. Return ONLY the raw JSON object."""


def prepare_subagent_task(
    project_id: str,
    proj: dict,
    scan_first: bool = True,
    max_per_agent: int = 15,
    max_photos: int = 0,
    reanalyze_all: bool = False,
    thumb_max_w: int = 640,
) -> dict:
    """
    準備 MV Studio 專案的 Subagent 批次視覺分析任務：
    1. （可選）先掃描照片目錄將新檔案加入 catalog
    2. 為待分析照片產生 640px 清晰輕量縮圖（加速 Subagent 讀取）
    3. 將待分析照片切分為 Subagent Shards 並產生對應 Prompt
    4. 寫入 `mv_studio/projects/<project_id>/subagent_task.json`
    """
    pdir = store.project_dir(project_id)
    catalog_path = store.catalog_file(project_id)
    photos_dir = Path(proj.get("photos_dir") or (pdir / "photos"))
    cache_dir = pdir / ".cache" / "thumbs"

    themes = proj.get("themes") or store.DEFAULT_THEME_TEMPLATE

    scan_info = None
    if scan_first and photos_dir.exists():
        catalog = photos_lib.load_catalog(catalog_path)
        batch_id = photos_lib.next_batch_id(catalog)
        scan_info = photos_lib.scan_new_photos(photos_dir, catalog_path, batch_id)

    catalog = photos_lib.load_catalog(catalog_path)
    all_photos = catalog.get("photos", [])

    # 讀取 content_plan（若有）以提供需求缺口資訊
    cp_path = store.content_plan_file(project_id)
    content_plan = None
    if cp_path.exists():
        try:
            content_plan = json.loads(cp_path.read_text(encoding="utf-8"))
        except Exception:
            content_plan = None

    coverage = compute_theme_coverage(catalog, themes, content_plan)

    # 篩選固定片頭片尾：若片頭/片尾已在 catalog 但尚未標記，自動標記為已分析（避免卡在待分析），且不送交 Subagent
    fixed_map = {}
    if proj.get("title_card_file"):
        fixed_map[proj["title_card_file"]] = (themes[0]["name"] if themes else "Intro", "片頭固定圖卡")
    if proj.get("outro_file"):
        fixed_map[proj["outro_file"]] = (themes[-1]["name"] if themes else "Outro", "片尾固定圖卡")

    fixed_updated = False
    for p in all_photos:
        fn = p.get("filename")
        if fn in fixed_map and not p.get("analyzed"):
            t_name, desc = fixed_map[fn]
            p["theme"] = t_name
            p["description"] = desc
            p["quality_score"] = 9.0
            p["fit_scores"] = {t["name"]: (10.0 if t["name"] == t_name else 1.0) for t in themes}
            p["is_slide"] = True
            p["analyzed"] = True
            p["auto_tagged"] = True
            p["analyzed_by"] = "auto_fixed"
            fixed_updated = True
    if fixed_updated:
        photos_lib.save_catalog(catalog_path, catalog)

    pending = [
        p for p in all_photos
        if (reanalyze_all or not p.get("analyzed"))
        and p.get("filename") not in fixed_map
    ]
    if max_photos and max_photos > 0:
        pending = pending[:max_photos]

    # 為待分析照片預先生成縮圖，供 Subagent 高速讀取
    prepared_pending = []
    for p in pending:
        fname = p["filename"]
        thumb_path = photos_lib.get_thumbnail(
            fname, catalog_path, photos_dir, cache_dir, max_w=thumb_max_w
        )
        entry_copy = {
            "filename": fname,
            "abs_path": p.get("abs_path") or str(photos_dir / fname),
            "thumb_path": str(thumb_path.resolve()) if thumb_path else None,
            "exif_time": p.get("exif_time") or p.get("file_mtime"),
            "dims": p.get("dims"),
            "size_kb": p.get("size_kb"),
            "batch_id": p.get("batch_id", 1),
            "theme_hint": p.get("theme_hint"),
            "protagonists": p.get("protagonists") or [],
        }
        prepared_pending.append(entry_copy)

    shards_raw = compute_subagent_shards(prepared_pending, max_per_agent=max_per_agent)
    total_shards = len(shards_raw)

    song_title = proj.get("song_title") or proj.get("name") or project_id
    shards_out = []
    for idx, shard_photos in enumerate(shards_raw, 1):
        prompt = build_subagent_prompt(
            project_id=project_id,
            song_title=song_title,
            shard_id=idx,
            total_shards=total_shards,
            shard_photos=shard_photos,
            themes=themes,
            coverage=coverage,
            use_thumbnails=True,
        )
        shards_out.append({
            "shard_id": idx,
            "photo_count": len(shard_photos),
            "filenames": [x["filename"] for x in shard_photos],
            "photos": shard_photos,
            "prompt": prompt,
        })

    task_file = store.project_dir(project_id) / "subagent_task.json"
    cli_scan_cmd = f"python analyze_batch_photos.py scan --project {project_id}"
    cli_import_cmd = f"python analyze_batch_photos.py import --project {project_id} --input <subagent_output.json>"
    agent_chat_prompt = (
        f"請幫我對 MV Studio 專案「{song_title}」（ID: `{project_id}`）執行 Subagent 批次照片視覺分析：\n"
        f"任務定義檔已產生於 `{task_file}`（共 {len(prepared_pending)} 張待分析照片，分為 {total_shards} 個 Subagent 分組）。\n"
        f"請依 `subagent_task.json` 內的 `shards` 派發 Subagents 並行讀取 `thumb_path` 進行視覺評分，"
        f"完成後執行 `python {Path(__file__).resolve().parents[2] / 'analyze_batch_photos.py'} import --project {project_id} --input ...` 匯入結果。"
    )

    task_data = {
        "project_id": project_id,
        "project_name": proj.get("name"),
        "song_title": song_title,
        "generated_at": _now_tw(),
        "photos_dir": str(photos_dir),
        "catalog_path": str(catalog_path),
        "task_file": str(task_file),
        "scan_info": scan_info,
        "stats": {
            "total_photos": len(all_photos),
            "analyzed_photos": sum(1 for p in all_photos if p.get("analyzed")),
            "pending_photos": len(prepared_pending),
            "recommended_subagents": total_shards,
            "max_per_agent": max_per_agent,
        },
        "themes": themes,
        "theme_coverage": coverage,
        "agent_chat_prompt": agent_chat_prompt,
        "cli_commands": {
            "scan": cli_scan_cmd,
            "import": cli_import_cmd,
            "status": f"python analyze_batch_photos.py status --project {project_id}",
        },
        "shards": shards_out,
        "analyses": [],
    }

    task_file.write_text(json.dumps(task_data, ensure_ascii=False, indent=2), encoding="utf-8")
    return task_data


def get_subagent_status(project_id: str, proj: dict) -> dict:
    """
    取得專案目前的 Subagent 分析狀態、覆蓋率與已準備好的任務摘要（供前端顯示與輪詢）。
    """
    catalog_path = store.catalog_file(project_id)
    catalog = photos_lib.load_catalog(catalog_path)
    all_photos = catalog.get("photos", [])
    themes = proj.get("themes") or store.DEFAULT_THEME_TEMPLATE

    cp_path = store.content_plan_file(project_id)
    content_plan = None
    if cp_path.exists():
        try:
            content_plan = json.loads(cp_path.read_text(encoding="utf-8"))
        except Exception:
            content_plan = None

    coverage = compute_theme_coverage(catalog, themes, content_plan)
    fixed_files = {
        proj.get("title_card_file") or "片頭.png",
        proj.get("outro_file") or "片尾.png",
    }
    pending_count = sum(
        1 for p in all_photos
        if not p.get("analyzed") and p.get("filename") not in fixed_files
    )
    analyzed_count = sum(1 for p in all_photos if p.get("analyzed"))
    subagent_analyzed_count = sum(
        1 for p in all_photos if p.get("analyzed") and str(p.get("analyzed_by", "")).startswith("subagent")
    )

    task_file = store.project_dir(project_id) / "subagent_task.json"
    task_summary = None
    if task_file.exists():
        try:
            td = json.loads(task_file.read_text(encoding="utf-8"))
            task_summary = {
                "generated_at": td.get("generated_at"),
                "task_file": str(task_file),
                "recommended_subagents": len(td.get("shards", [])),
                "agent_chat_prompt": td.get("agent_chat_prompt"),
                "cli_commands": td.get("cli_commands"),
                "shards": [
                    {
                        "shard_id": s["shard_id"],
                        "photo_count": s["photo_count"],
                        "filenames": s["filenames"],
                        "prompt": s["prompt"],
                    }
                    for s in td.get("shards", [])
                ],
            }
        except Exception:
            task_summary = None

    return {
        "project_id": project_id,
        "catalog_last_updated": catalog.get("last_updated"),
        "stats": {
            "total": len(all_photos),
            "analyzed": analyzed_count,
            "pending": pending_count,
            "subagent_analyzed": subagent_analyzed_count,
        },
        "theme_coverage": coverage,
        "task": task_summary,
    }


def _extract_analyses_from_obj(obj) -> list[dict]:
    """
    從各種可能的 JSON 結構中提取 analyses 陣列：
    - {"analyses": [...]}
    - [{"filename": ...}, ...]
    - {"shards": [{"analyses": [...]}]}
    """
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict) and ("filename" in x or "abs_path" in x)]
    if isinstance(obj, dict):
        if isinstance(obj.get("analyses"), list) and obj["analyses"]:
            return obj["analyses"]
        # 可能是單筆分析結果
        if "filename" in obj and ("theme" in obj or "fit_scores" in obj):
            return [obj]
        # 可能包在 shards 或 results 裡
        collected = []
        for key in ("shards", "results", "batches"):
            if isinstance(obj.get(key), list):
                for item in obj[key]:
                    collected.extend(_extract_analyses_from_obj(item))
        return collected
    return []


def parse_raw_json_input(raw_text: str) -> list[dict]:
    """
    解析可能包含 Markdown code block 或多個 JSON 區塊的文字輸入。
    """
    text = (raw_text or "").strip()
    if not text:
        return []

    # 去除 ```json ... ``` 包裝
    if text.startswith("```"):
        lines = text.splitlines()
        cleaned = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(cleaned).strip()

    try:
        parsed = json.loads(text)
        return _extract_analyses_from_obj(parsed)
    except json.JSONDecodeError:
        # 嘗試用 JSONDecoder.raw_decode 連續解析多個 JSON 物件
        decoder = json.JSONDecoder()
        idx = 0
        n = len(text)
        analyses = []
        while idx < n:
            while idx < n and text[idx] in " \t\r\n,":
                idx += 1
            if idx >= n:
                break
            try:
                obj, next_idx = decoder.raw_decode(text, idx)
                analyses.extend(_extract_analyses_from_obj(obj))
                idx = next_idx
            except json.JSONDecodeError:
                break
        if analyses:
            return analyses
        raise


def _normalize_theme(raw_theme: str, fit_scores: dict, valid_themes: list[str]) -> str:
    if not valid_themes:
        return raw_theme or "General"
    if raw_theme in valid_themes:
        return raw_theme
    # 不分大小寫比對
    lower_map = {t.lower(): t for t in valid_themes}
    if raw_theme and raw_theme.lower() in lower_map:
        return lower_map[raw_theme.lower()]
    # 子字串比對
    if raw_theme:
        for vt in valid_themes:
            if vt.lower() in raw_theme.lower() or raw_theme.lower() in vt.lower():
                return vt
    # 退回 fit_scores 最高分的主題
    if isinstance(fit_scores, dict) and fit_scores:
        best_t = max(
            valid_themes,
            key=lambda t: float(fit_scores.get(t, -1.0)) if isinstance(fit_scores.get(t), (int, float)) else -1.0,
        )
        if float(fit_scores.get(best_t, 0.0)) > 0:
            return best_t
    return valid_themes[0]


def import_subagent_analyses(
    project_id: str,
    proj: dict,
    analyses: list[dict],
    overwrite: bool = True,
    source_label: str = "subagent",
) -> dict:
    """
    將 Subagent 分析結果批次寫入指定專案的 `photo_catalog.json` 並更新 `project.json`。
    """
    catalog_path = store.catalog_file(project_id)
    photos_dir = Path(proj.get("photos_dir") or (store.project_dir(project_id) / "photos"))

    themes = proj.get("themes") or store.DEFAULT_THEME_TEMPLATE
    valid_themes = [t["name"] for t in themes]

    # 若 catalog 尚不存在或照片尚未掃描，先自動掃描一次
    if not catalog_path.exists() and photos_dir.exists():
        photos_lib.scan_new_photos(photos_dir, catalog_path, batch_id=1)

    catalog = photos_lib.load_catalog(catalog_path)
    photo_index = {p["filename"]: p for p in catalog["photos"]}

    imported_new = 0
    updated_existing = 0
    skipped = 0
    errors = []

    for item in analyses:
        if not isinstance(item, dict):
            skipped += 1
            continue

        fname = (item.get("filename") or "").strip()
        if not fname and item.get("abs_path"):
            fname = Path(item["abs_path"]).name
        if not fname:
            skipped += 1
            continue

        entry = photo_index.get(fname)
        if not entry:
            # 嘗試在 photos_dir 尋找該檔案並動態補入 catalog
            candidate_path = photos_dir / fname
            if not candidate_path.exists() and item.get("abs_path"):
                candidate_path = Path(item["abs_path"])
            if candidate_path.exists():
                entry = {
                    "filename": fname,
                    "abs_path": str(candidate_path.resolve()),
                    "exif_time": photos_lib.get_exif_time(candidate_path),
                    "file_mtime": photos_lib.get_file_mtime(candidate_path),
                    "dims": list(photos_lib.get_image_dims(candidate_path) or []) or None,
                    "size_kb": round(candidate_path.stat().st_size / 1024, 1),
                    "batch_id": int(item.get("batch_id", 1)),
                    "is_slide": bool(item.get("is_slide", False)),
                    "theme": None,
                    "description": "",
                    "quality_score": None,
                    "fit_scores": {},
                    "analyzed": False,
                    "auto_tagged": False,
                }
                catalog["photos"].append(entry)
                photo_index[fname] = entry
            else:
                errors.append(f"找不到照片檔案：{fname}")
                continue

        was_analyzed = bool(entry.get("analyzed"))
        if was_analyzed and not overwrite:
            skipped += 1
            continue

        raw_fs = item.get("fit_scores") or {}
        normalized_fs = {}
        for vt in valid_themes:
            val = raw_fs.get(vt)
            if val is None:
                # 嘗試大小寫無關匹配
                for k, v in raw_fs.items():
                    if k.lower() == vt.lower():
                        val = v
                        break
            try:
                normalized_fs[vt] = round(max(0.0, min(10.0, float(val if val is not None else 2.0))), 1)
            except (TypeError, ValueError):
                normalized_fs[vt] = 2.0

        chosen_theme = _normalize_theme(item.get("theme", ""), normalized_fs, valid_themes)
        # 若主分類的 fit_score 偏低，確保至少有合理分數
        if chosen_theme in normalized_fs and normalized_fs[chosen_theme] < 6.0 and not raw_fs:
            normalized_fs[chosen_theme] = 8.5

        try:
            q_score = round(max(0.0, min(10.0, float(item.get("quality_score", 7.5)))), 1)
        except (TypeError, ValueError):
            q_score = 7.5

        entry["theme"] = chosen_theme
        entry["description"] = str(item.get("description") or entry.get("description") or "").strip()
        entry["quality_score"] = q_score
        entry["fit_scores"] = normalized_fs
        if item.get("focus_x") is not None:
            try:
                entry["focus_x"] = round(max(0.08, min(0.92, float(item["focus_x"]))), 3)
            except (TypeError, ValueError):
                pass
        elif entry.get("focus_x") is None:
            src_p = Path(entry.get("abs_path") or (photos_dir / fname))
            entry["focus_x"], entry["focus_y"] = photos_lib.estimate_photo_focus(src_p)
        if item.get("focus_y") is not None:
            try:
                entry["focus_y"] = round(max(0.08, min(0.88, float(item["focus_y"]))), 3)
            except (TypeError, ValueError):
                pass
        if "protagonists" in item:
            new_prots = photos_lib.normalize_protagonists(item.get("protagonists"))
            # 雲端來源照片：保留上傳者標的小隊（cloud_groups），再接上視覺分析看到的人物
            entry["protagonists"] = photos_lib.normalize_protagonists(list(entry.get("cloud_groups") or []) + new_prots)
        else:
            entry.setdefault("protagonists", [])
        entry["analyzed"] = True
        entry["auto_tagged"] = False
        entry["analyzed_by"] = source_label
        entry["analyzed_at"] = _now_tw()

        if was_analyzed:
            updated_existing += 1
        else:
            imported_new += 1

    photos_lib.save_catalog(catalog_path, catalog)

    # 同步更新 project.json 的 status.photos_analyzed
    total_analyzed = sum(1 for p in catalog["photos"] if p.get("analyzed"))
    store.update_project(project_id, {
        "status": {**proj.get("status", {}), "photos_analyzed": total_analyzed}
    })

    cp_path = store.content_plan_file(project_id)
    content_plan = None
    if cp_path.exists():
        try:
            content_plan = json.loads(cp_path.read_text(encoding="utf-8"))
        except Exception:
            content_plan = None

    coverage = compute_theme_coverage(catalog, themes, content_plan)

    return {
        "ok": True,
        "project_id": project_id,
        "imported_new": imported_new,
        "updated_existing": updated_existing,
        "total_processed": imported_new + updated_existing,
        "skipped": skipped,
        "errors": errors,
        "total_in_catalog": len(catalog["photos"]),
        "total_analyzed": total_analyzed,
        "pending_remaining": sum(1 for p in catalog["photos"] if not p.get("analyzed")),
        "theme_coverage": coverage,
    }
