#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/gphotos.py
==============
Google 相簿公開分享連結解析、元資料讀取、縮圖快取與原圖下載模組。

功能：
1. 解析 Google 相簿公開分享網址（支援 photos.app.goo.gl 與 photos.google.com/share/）。
2. 透過 AF_initDataCallback 與 batchexecute 分頁機制讀取相簿中全部照片資訊。
3. 將相簿照片以「輕量遠端照片」註冊入專案 photo_catalog.json（不預先下載數 GB 原圖）。
4. 支援隨選縮圖快取（640px 供 Subagent 分析、320px 供網格預覽、1280px 供大圖檢視）。
5. 核心功能：【正式挑選才下載原圖】—— 僅針對已指派至時間軸的正式照片批次下載最高畫質原圖。
"""

import re
import json
import urllib.request
import urllib.parse
from pathlib import Path
from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Tuple, List, Dict, Any

from lib import store
from lib import photos as photos_lib

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def resolve_album_url(share_url: str) -> Tuple[str, str, str]:
    """
    解析分享網址，取得最終 Google Photos URL、album_id 與 auth_key。
    """
    share_url = share_url.strip()
    if not share_url.startswith("http"):
        share_url = "https://" + share_url

    # photos.app.goo.gl 是 Firebase 動態短網址，若使用 curl UA 會立即回傳 302 重導向至正式相簿頁
    req = urllib.request.Request(share_url, headers={"User-Agent": "curl/8.4.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            final_url = resp.geturl()
    except Exception as e:
        raise ValueError(f"無法存取 Google 相簿網址：{e}")

    parsed = urllib.parse.urlparse(final_url)
    m = re.search(r"/share/([a-zA-Z0-9_\-]+)", parsed.path)
    if not m:
        raise ValueError(f"無效的 Google 相簿分享網址格式，未找到 album_id：{final_url}")
    album_id = m.group(1)

    qs = urllib.parse.parse_qs(parsed.query)
    auth_key = qs.get("key", [""])[0]

    return final_url, album_id, auth_key


def fetch_album_items(share_url: str, max_items: Optional[int] = None) -> Dict[str, Any]:
    """
    爬取相簿元資料與所有照片資料。
    """
    final_url, album_id, auth_key = resolve_album_url(share_url)

    req = urllib.request.Request(final_url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            html = resp.read().decode("utf-8")
    except Exception as e:
        raise ValueError(f"讀取相簿頁面失敗：{e}")

    title_match = re.search(r"<title>(.*?)</title>", html)
    album_title = title_match.group(1).replace(" - Google Photos", "").replace(" - Google 相簿", "").strip() if title_match else "Google 相簿"

    # 尋找 AF_initDataCallback ds:1
    cb_match = re.search(r"AF_initDataCallback\((\{key:\s*'ds:1'.*?\})\);</script>", html, re.DOTALL)
    if not cb_match:
        raise ValueError("無法解析相簿資料（找不到 ds:1 回呼）")

    cb_text = cb_match.group(1)
    data_match = re.search(r"data:\s*(\[.*?\])\s*,\s*sideChannel:", cb_text, re.DOTALL)
    if not data_match:
        raise ValueError("無法解析相簿資料區塊")

    data = json.loads(data_match.group(1))
    items_raw = data[1] if len(data) > 1 and isinstance(data[1], list) else []
    page_token = data[2] if len(data) > 2 else None

    # 相簿總數資訊（若有）
    album_meta = data[3] if len(data) > 3 and isinstance(data[3], list) else []
    total_in_album = album_meta[14] if len(album_meta) > 14 and isinstance(album_meta[14], int) else len(items_raw)

    photos = []
    seen_ids = set()

    def process_raw_item(raw):
        if not isinstance(raw, list) or len(raw) < 2:
            return
        photo_id = raw[0]
        if photo_id in seen_ids:
            return
        seen_ids.add(photo_id)

        meta = raw[1] if len(raw) > 1 and isinstance(raw[1], list) else []
        base_url = meta[0] if len(meta) > 0 else None
        if not base_url or not base_url.startswith("http"):
            return

        w = meta[1] if len(meta) > 1 and isinstance(meta[1], int) else 1920
        h = meta[2] if len(meta) > 2 and isinstance(meta[2], int) else 1080

        ts_ms = raw[2] if len(raw) > 2 and isinstance(raw[2], (int, float)) else None
        created_at = None
        if ts_ms:
            try:
                dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone(timedelta(hours=8)))
                created_at = dt.isoformat(timespec="seconds")
            except Exception:
                pass

        photos.append({
            "id": photo_id,
            "base_url": base_url,
            "width": w,
            "height": h,
            "created_at": created_at,
            "timestamp_ms": ts_ms,
        })

    for item in items_raw:
        process_raw_item(item)
        if max_items and len(photos) >= max_items:
            break

    # 若有後續分頁且尚未達到需求上限，使用 batchexecute RPC (snAcKc) 接續抓取
    rpc_url = "https://photos.google.com/_/PhotosUi/data/batchexecute"
    while page_token and (max_items is None or len(photos) < max_items):
        req_data = [album_id, page_token, None, auth_key]
        f_req = [[["snAcKc", json.dumps(req_data), None, "generic"]]]
        post_data = urllib.parse.urlencode({"f.req": json.dumps(f_req)}).encode("utf-8")
        rpc_req = urllib.request.Request(
            rpc_url,
            data=post_data,
            headers={
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                "User-Agent": USER_AGENT,
            },
        )
        try:
            with urllib.request.urlopen(rpc_req, timeout=20) as resp:
                res_text = resp.read().decode("utf-8")
            
            found_batch = False
            for line in res_text.split("\n"):
                if "wrb.fr" in line:
                    payload = json.loads(line)
                    inner_str = payload[0][2]
                    if inner_str:
                        inner = json.loads(inner_str)
                        batch_items = inner[1] if len(inner) > 1 and isinstance(inner[1], list) else []
                        for b_item in batch_items:
                            process_raw_item(b_item)
                            if max_items and len(photos) >= max_items:
                                break
                        page_token = inner[2] if len(inner) > 2 and inner[2] else None
                        found_batch = True
                        break
            if not found_batch:
                break
        except Exception:
            break

    return {
        "album_title": album_title,
        "album_id": album_id,
        "auth_key": auth_key,
        "share_url": final_url,
        "total_in_album": total_in_album,
        "fetched_count": len(photos),
        "photos": photos,
    }


def import_gphotos_to_catalog(project_id: str, share_url: str) -> Dict[str, Any]:
    """
    將 Google 相簿的照片匯入到指定專案的 photo_catalog.json 中。
    採「遠端照片記錄」模式：
    - 不預先下載原圖，只記錄 remote_url、dims、created_at。
    - 縮圖依需在背景即時快取。
    - 只有正式在照片挑選中選中的照片才下載原圖。
    """
    proj = store.get_project(project_id)
    catalog_path = store.catalog_file(project_id)
    catalog = photos_lib.load_catalog(catalog_path)

    # 爬取相簿內容
    album_data = fetch_album_items(share_url)
    fetched_photos = album_data["photos"]

    # 建立現有已登錄的照片索引（依 remote_url 或 photo_id 避免重複匯入）
    existing_remote_urls = set()
    existing_filenames = set()
    for p in catalog.get("photos", []):
        existing_filenames.add(p["filename"])
        if p.get("remote_url"):
            existing_remote_urls.add(p["remote_url"])

    batch_id = photos_lib.next_batch_id(catalog)
    added_count = 0

    for idx, item in enumerate(fetched_photos, 1):
        base_url = item["base_url"]
        if base_url in existing_remote_urls:
            continue

        photo_id = item["id"]
        # 產生簡短且乾淨的檔名：gphoto_001_AF1QipN76.jpg
        short_id = re.sub(r"[^a-zA-Z0-9]", "", photo_id)[:10]
        filename = f"gphoto_{idx:03d}_{short_id}.jpg"
        while filename in existing_filenames:
            filename = f"gphoto_{idx:03d}_{short_id}_{photos_lib.hashlib.sha1(base_url.encode()).hexdigest()[:4]}.jpg"
        existing_filenames.add(filename)
        existing_remote_urls.add(base_url)

        created_time = item["created_at"] or _now_tw()

        entry = {
            "filename": filename,
            "abs_path": "",  # 未下載時為空字串
            "remote_url": base_url,
            "photo_id": photo_id,
            "source": "google_photos",
            "downloaded": False,
            "exif_time": created_time,
            "file_mtime": created_time,
            "dims": [item["width"], item["height"]],
            "size_kb": 0,
            "batch_id": batch_id,
            "is_slide": False,
            "theme": None,
            "description": "",
            "quality_score": None,
            "fit_scores": {},
            "focus_x": 0.5,
            "focus_y": 0.38,
            "protagonists": [],
            "analyzed": False,
            "auto_tagged": False,
        }
        catalog["photos"].append(entry)
        added_count += 1

    photos_lib.save_catalog(catalog_path, catalog)

    # 同步更新專案設定中的相簿連結與名稱（若專案名稱仍為預設）
    updates = {"gphotos_url": album_data["share_url"]}
    if not proj.get("name") or proj["name"].startswith("proj_"):
        updates["name"] = album_data["album_title"]
        updates["song_title"] = album_data["album_title"]
    store.update_project(project_id, updates)

    return {
        "ok": True,
        "album_title": album_data["album_title"],
        "total_in_album": album_data["total_in_album"],
        "added_count": added_count,
        "total_catalog_photos": len(catalog["photos"]),
    }


def download_remote_image(remote_url: str, dest_path: Path, quality: str = "original") -> bool:
    """
    從 Google 相簿直連下載圖片：
    quality="original": 附加 =d 下載原圖無損檔案。
    quality="preview": 附加 =w1280-h1280 下載高清檢視圖。
    """
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    suffix = "=d" if quality == "original" else "=w1280-h1280"
    target_url = remote_url + suffix
    req = urllib.request.Request(target_url, headers={"User-Agent": USER_AGENT})

    tmp_path = dest_path.with_suffix(dest_path.suffix + ".tmp")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
            if len(data) < 1000:
                return False
            tmp_path.write_bytes(data)
            tmp_path.replace(dest_path)
            return True
    except Exception:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except Exception:
                pass
        return False


def get_selected_download_status(project_id: str) -> Dict[str, Any]:
    """
    取得目前專案「正式挑選的照片」之下載狀態：
    - total_selected: 時間軸正式分配使用的照片數
    - downloaded_count: 已下載為本機實體檔案的數量
    - pending_count: 尚待下載原圖的數量
    """
    proj = store.get_project(project_id)
    ordered_path = store.ordered_photos_file(project_id)
    catalog_path = store.catalog_file(project_id)
    catalog = photos_lib.load_catalog(catalog_path)
    cat_by_name = photos_lib.catalog_index_by_filename(catalog)

    from server import photos_dir_of
    pdir = photos_dir_of(proj)

    if not ordered_path.exists():
        return {
            "has_manifest": False,
            "total_selected": 0,
            "downloaded_count": 0,
            "pending_count": 0,
            "pending_photos": [],
        }

    try:
        ordered_photos = json.loads(ordered_path.read_text(encoding="utf-8"))
    except Exception:
        ordered_photos = []

    # 收集正式被分配的唯一照片檔名
    selected_filenames = set()
    for entry in ordered_photos:
        fn = entry.get("filename") if isinstance(entry, dict) else str(entry)
        if fn and fn not in ("__MISSING__", proj.get("title_card_file"), proj.get("outro_file")):
            selected_filenames.add(fn)

    total_selected = len(selected_filenames)
    downloaded_count = 0
    pending_photos = []

    for fn in selected_filenames:
        cat_entry = cat_by_name.get(fn, {})
        local_path = pdir / fn
        # 判斷是否為 Google 相簿來源
        is_gphoto = cat_entry.get("source") == "google_photos" or bool(cat_entry.get("remote_url"))

        if local_path.exists() and local_path.stat().st_size > 1000:
            downloaded_count += 1
        elif is_gphoto:
            pending_photos.append({
                "filename": fn,
                "remote_url": cat_entry.get("remote_url"),
                "dims": cat_entry.get("dims"),
            })
        else:
            # 一般本地照片若不存在
            pending_photos.append({
                "filename": fn,
                "remote_url": None,
                "missing_local": True,
            })

    return {
        "has_manifest": True,
        "total_selected": total_selected,
        "downloaded_count": downloaded_count,
        "pending_count": len(pending_photos),
        "pending_photos": pending_photos,
    }


def download_selected_photos(project_id: str, ctx=None, max_workers: int = 4) -> Dict[str, Any]:
    """
    【核心動作】：只針對正式挑中的照片批次下載原圖！
    多執行緒並行下載並更新 catalog。
    """
    proj = store.get_project(project_id)
    catalog_path = store.catalog_file(project_id)
    catalog = photos_lib.load_catalog(catalog_path)
    cat_by_name = photos_lib.catalog_index_by_filename(catalog)

    from server import photos_dir_of
    pdir = photos_dir_of(proj)
    pdir.mkdir(parents=True, exist_ok=True)

    status = get_selected_download_status(project_id)
    pending = [p for p in status.get("pending_photos", []) if p.get("remote_url")]

    if not pending:
        if ctx:
            ctx.log("✅ 所有已挑選的照片皆已下載完成！")
        return {"ok": True, "downloaded": 0, "total": status["total_selected"]}

    if ctx:
        ctx.log(f"📥 開始下載正式挑選的 {len(pending)} 張 Google 相簿高解析度原圖...")

    success_count = 0
    failed_count = 0

    def _worker(item):
        fname = item["filename"]
        rurl = item["remote_url"]
        target = pdir / fname
        ok = download_remote_image(rurl, target, quality="original")
        return fname, ok, target

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(_worker, it): it for it in pending}
        done_count = 0
        for f in as_completed(futures):
            done_count += 1
            fname, ok, target = f.result()
            if ok:
                success_count += 1
                cat_entry = cat_by_name.get(fname)
                if cat_entry:
                    cat_entry["downloaded"] = True
                    cat_entry["abs_path"] = str(target.resolve())
                    try:
                        cat_entry["size_kb"] = round(target.stat().st_size / 1024, 1)
                        # 如果有 PIL，更新精確 dims
                        if photos_lib.Image:
                            with photos_lib.Image.open(target) as im:
                                cat_entry["dims"] = list(im.size)
                    except Exception:
                        pass
                if ctx:
                    ctx.log(f"  [{done_count}/{len(pending)}] ✓ {fname} ({round(target.stat().st_size/1024/1024, 2)} MB)")
            else:
                failed_count += 1
                if ctx:
                    ctx.log(f"  [{done_count}/{len(pending)}] ❌ 下載失敗：{fname}")

    # 儲存更新後的 catalog
    photos_lib.save_catalog(catalog_path, catalog)

    if ctx:
        ctx.log(f"🎉 原圖下載完成！成功 {success_count} 張，失敗 {failed_count} 張。")

    return {
        "ok": True,
        "downloaded": success_count,
        "failed": failed_count,
        "total_selected": status["total_selected"],
    }
