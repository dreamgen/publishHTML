#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/photos.py
=============
照片 catalog 掃描 / 標記 / 縮圖，皆為「每個專案獨立一份 catalog」，
且主題清單改為讀取專案自訂的 themes（而非寫死的 ALL_THEMES）。
"""

import re
import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone, timedelta

PHOTO_EXTS = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".gif", ".bmp", ".webp"}
SKIP_FILENAMES = {"ordered_photos.json", "ordered_photos_detail.json", ".DS_Store"}

try:
    from PIL import Image, ImageOps
except ImportError:
    Image = None
    ImageOps = None

try:
    import numpy as np
except ImportError:
    np = None


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def get_exif_time(path: Path):
    try:
        from PIL.ExifTags import TAGS
        img = Image.open(path)
        exif_data = img._getexif()
        if exif_data:
            for tag_id, value in exif_data.items():
                if TAGS.get(tag_id) == "DateTimeOriginal":
                    dt = datetime.strptime(str(value), "%Y:%m:%d %H:%M:%S")
                    return dt.isoformat(timespec="seconds")
    except Exception:
        pass
    return None


def get_file_mtime(path: Path) -> str:
    ts = path.stat().st_mtime
    dt = datetime.fromtimestamp(ts, tz=timezone(timedelta(hours=8)))
    return dt.isoformat(timespec="seconds")


# ── 拍攝方向（EXIF Orientation）──────────────────────────────
# 手機直拍的照片常以「橫的像素 + 方向標記」存檔。瀏覽器會自動轉正，但 PIL 不會，
# 所以縮圖、尺寸、焦點偵測與渲染都必須先依標記轉正，否則直式照片會橫躺。
ORIENT_VERSION = 1   # catalog 條目的 orient_v：dims / focus 已是「轉正後」座標
_ROTATED = (5, 6, 7, 8)  # 轉正後寬高對調的方向值


def _orientation_of(img) -> int:
    try:
        return int(img.getexif().get(0x0112, 1) or 1)
    except Exception:
        return 1


def get_exif_orientation(path: Path) -> int:
    try:
        with Image.open(path) as img:
            return _orientation_of(img)
    except Exception:
        return 1


def open_upright(path: Path):
    """開啟圖片並依 EXIF 方向轉正（回傳已載入的 Image，呼叫端負責關閉）。"""
    img = Image.open(path)
    if _orientation_of(img) != 1 and ImageOps is not None:
        try:
            fixed = ImageOps.exif_transpose(img)
            if fixed is not img:
                img.close()
            return fixed
        except Exception:
            pass
    return img


def raw_to_upright_focus(fx: float, fy: float, orientation: int):
    """把「未轉正畫面」上的焦點座標換算成「轉正後」座標（與 ImageOps.exif_transpose 一致）。"""
    x, y = float(fx), float(fy)
    m = {
        2: (1 - x, y), 3: (1 - x, 1 - y), 4: (x, 1 - y),
        5: (y, x), 6: (1 - y, x), 7: (1 - y, 1 - x), 8: (y, 1 - x),
    }
    return m.get(orientation, (x, y))


def get_image_dims(path: Path):
    """回傳轉正後的 (寬, 高)。"""
    try:
        from . import portable
        return portable.open_upright(path).size
    except Exception:
        return None


# event_prep.py 使用的舊名稱（先前缺漏，本機收件上傳時會出錯）
def get_dimensions(path: Path):
    return get_image_dims(path) or (0, 0)


def get_exif_datetime(path: Path):
    return get_exif_time(path)


def estimate_photo_focus(path: Path) -> tuple[float, float]:
    """
    快速估計照片中的人臉/主體視覺重心座標 (focus_x, focus_y) ∈ [0.0, 1.0]：
    結合：
      1. 暖膚色特徵圖（YCbCr / RGB 人臉膚色區間）
      2. 局部邊緣梯度能量（五官與主體輪廓）
      3. 人像構圖先驗（中心偏上 y ≈ 0.36，避免地面或下半身雜訊將鏡頭往下拉而切到頭頂）
    單張耗時 < 3ms，供 Ken Burns 智慧推進使用。
    """
    if Image is None or np is None or not path or not path.exists():
        return (0.5, 0.38)
    try:
        from . import portable
        img = portable.open_upright(path).convert("RGB").resize((160, 160))
        arr = np.asarray(img, dtype=np.float32)
        r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]

        # 1. YCbCr 膚色機率遮罩（針對亞洲/自然光人臉膚色）
        lum = 0.299 * r + 0.587 * g + 0.114 * b
        cb = 128.0 - 0.168736 * r - 0.331264 * g + 0.5 * b
        cr = 128.0 + 0.5 * r - 0.418688 * g - 0.081312 * b
        skin_mask = (
            (lum > 55.0) & (lum < 240.0) &
            (cr > 133.0) & (cr < 175.0) &
            (cb > 77.0) & (cb < 127.0) &
            (r > g) & (g > b * 0.85)
        ).astype(np.float32)

        # 2. 空間邊緣能量（五官/眼神/笑臉高頻細節）
        gx = np.abs(np.diff(lum, axis=1, prepend=lum[:, :1]))
        gy = np.abs(np.diff(lum, axis=0, prepend=lum[:1, :]))
        edge = (gx + gy) / 255.0

        # 3. 構圖空間先驗（水平居中 0.5，垂直偏上 0.36 保護頭部不裁切）
        ys = np.linspace(0.0, 1.0, 160, dtype=np.float32)[:, None]
        xs = np.linspace(0.0, 1.0, 160, dtype=np.float32)[None, :]
        prior = np.exp(-0.5 * (((xs - 0.5) / 0.32) ** 2 + ((ys - 0.36) / 0.24) ** 2))

        saliency = (2.2 * skin_mask * (0.4 + edge) + 0.8 * edge) * prior
        p85 = float(np.percentile(saliency, 85))
        top_mask = np.maximum(0.0, saliency - p85)
        total_w = float(np.sum(top_mask))
        if total_w < 1e-5:
            return (0.5, 0.38)

        fx = float(np.sum(top_mask * xs) / total_w)
        fy = float(np.sum(top_mask * ys) / total_w)
        fx = round(max(0.18, min(0.82, fx)), 3)
        fy = round(max(0.20, min(0.72, fy)), 3)
        return (fx, fy)
    except Exception:
        return (0.5, 0.38)


def normalize_protagonists(raw) -> list[str]:
    """將清單或逗號/頓號分隔字串正規化為不重複的人物/小隊標籤陣列。"""
    if not raw:
        return []
    if isinstance(raw, str):
        items = re.split(r"[、,，;；/|\s]+", raw.strip())
    elif isinstance(raw, list):
        items = [str(x).strip() for x in raw]
    else:
        return []
    out = []
    seen = set()
    for it in items:
        it = it.strip()
        if it and it not in seen:
            seen.add(it)
            out.append(it)
    return out


def load_catalog(catalog_path: Path) -> dict:
    if catalog_path.exists():
        return json.loads(catalog_path.read_text(encoding="utf-8"))
    return {"catalog_version": "2.0", "last_updated": _now_tw(), "total_photos": 0, "photos": []}


def save_catalog(catalog_path: Path, catalog: dict):
    catalog["last_updated"] = _now_tw()
    catalog["total_photos"] = len(catalog["photos"])
    catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")


def catalog_filenames(catalog: dict) -> set:
    return {p["filename"] for p in catalog["photos"]}


def catalog_index_by_filename(catalog: dict) -> dict:
    return {p["filename"]: p for p in catalog["photos"]}


def scan_new_photos(photos_dir: Path, catalog_path: Path, batch_id: int) -> dict:
    """掃描目錄，將新照片以 analyzed=False 的佔位項目加入 catalog（不做任何自動主題判斷，
    因為主題標籤與命名慣例因專案而異，一律交由使用者或 Claude 視覺分析標記）。"""
    if not photos_dir.exists():
        raise FileNotFoundError(f"照片目錄不存在：{photos_dir}")

    catalog = load_catalog(catalog_path)
    known = catalog_filenames(catalog)
    added = []

    for f in sorted(photos_dir.iterdir()):
        if not f.is_file():   # 子資料夾（例如雲端同步移入的 _excluded/）不掃描
            continue
        if f.name in SKIP_FILENAMES or f.name in known:
            continue
        if f.suffix.lower() not in PHOTO_EXTS:
            continue

        exif_time = get_exif_time(f)
        mtime = get_file_mtime(f)
        dims = get_image_dims(f)
        size_kb = round(f.stat().st_size / 1024, 1)
        fx, fy = estimate_photo_focus(f)

        entry = {
            "filename": f.name,
            "abs_path": str(f.resolve()),
            "exif_time": exif_time,
            "file_mtime": mtime,
            "dims": list(dims) if dims else None,
            "size_kb": size_kb,
            "batch_id": batch_id,
            "is_slide": False,
            "theme": None,
            "description": "",
            "quality_score": None,
            "fit_scores": {},
            "focus_x": fx,
            "focus_y": fy,
            "protagonists": [],
            "analyzed": False,
            "auto_tagged": False,
            "orient_v": ORIENT_VERSION,
        }
        catalog["photos"].append(entry)
        added.append(entry["filename"])

    save_catalog(catalog_path, catalog)
    return {
        "batch_id": batch_id,
        "added_pending": len(added),
        "added_filenames": added,
        "total_in_catalog": len(catalog["photos"]),
    }


def next_batch_id(catalog: dict) -> int:
    ids = [p.get("batch_id", 0) for p in catalog["photos"]]
    return (max(ids) + 1) if ids else 1


def update_photo(catalog_path: Path, filename: str, fields: dict, valid_themes: list) -> dict:
    catalog = load_catalog(catalog_path)
    idx = catalog_index_by_filename(catalog)
    entry = idx.get(filename)
    if not entry:
        raise KeyError(f"catalog 中找不到 {filename}")

    if "theme" in fields:
        theme = fields["theme"]
        if theme and theme not in valid_themes:
            raise ValueError(f"無效的主題：{theme}")
        entry["theme"] = theme
    if "quality_score" in fields and fields["quality_score"] not in (None, ""):
        entry["quality_score"] = float(fields["quality_score"])
    if "fit_scores" in fields and isinstance(fields["fit_scores"], dict):
        fs = entry.get("fit_scores") or {}
        for t, v in fields["fit_scores"].items():
            if t in valid_themes:
                try:
                    fs[t] = float(v)
                except (TypeError, ValueError):
                    pass
        entry["fit_scores"] = fs
    if "description" in fields:
        entry["description"] = fields["description"]
    if "is_slide" in fields:
        entry["is_slide"] = bool(fields["is_slide"])
    if "focus_x" in fields and fields["focus_x"] not in (None, ""):
        entry["focus_x"] = round(max(0.05, min(0.95, float(fields["focus_x"]))), 3)
    if "focus_y" in fields and fields["focus_y"] not in (None, ""):
        entry["focus_y"] = round(max(0.05, min(0.95, float(fields["focus_y"]))), 3)
    if "protagonists" in fields:
        entry["protagonists"] = normalize_protagonists(fields["protagonists"])
    if "flag" in fields:
        # 使用者挑照片時的人工標記：like（喜歡）／reject（淘汰）；空值代表清除
        flag = fields["flag"]
        if flag in ("like", "reject"):
            entry["flag"] = flag
        elif not flag:
            entry.pop("flag", None)
        else:
            raise ValueError(f"無效的標記：{flag}")

    if entry.get("theme"):
        entry["analyzed"] = True

    save_catalog(catalog_path, catalog)
    return entry


def auto_detect_focus_batch(catalog_path: Path, photos_dir: Path, overwrite: bool = False) -> dict:
    """
    對 catalog 中所有照片批次執行人臉/主體視覺重心座標 (focus_x, focus_y) 偵測。
    """
    migrate_orientation(catalog_path, photos_dir)
    catalog = load_catalog(catalog_path)
    updated = 0
    for p in catalog.get("photos", []):
        if not overwrite and p.get("focus_x") is not None and p.get("focus_y") is not None and p.get("focus_source") == "manual":
            continue
        src = Path(p["abs_path"]) if p.get("abs_path") and Path(p["abs_path"]).exists() else (photos_dir / p["filename"])
        if src.exists():
            fx, fy = estimate_photo_focus(src)
            p["focus_x"] = fx
            p["focus_y"] = fy
            p.setdefault("protagonists", [])
            updated += 1
    save_catalog(catalog_path, catalog)
    return {"updated": updated, "total": len(catalog.get("photos", []))}


def resolve_photo_path(filename: str, catalog_path: Path, photos_dir: Path, extra_dirs: list = None):
    catalog = load_catalog(catalog_path)
    idx = catalog_index_by_filename(catalog)
    entry = idx.get(filename)
    if entry and entry.get("abs_path"):
        p = Path(entry["abs_path"])
        if p.exists():
            return p
    p = photos_dir / filename
    if p.exists():
        return p
    for d in (extra_dirs or []):
        p = Path(d) / filename
        if p.exists():
            return p
    return None


def get_thumbnail(filename: str, catalog_path: Path, photos_dir: Path, cache_dir: Path,
                   extra_dirs: list = None, max_w: int = 320):
    src = resolve_photo_path(filename, catalog_path, photos_dir, extra_dirs)
    if not src:
        # 支援遠端照片（例如 Google 相簿）：直接從 remote_url 抓取指定尺寸縮圖並寫入本機快取
        catalog = load_catalog(catalog_path)
        entry = catalog_index_by_filename(catalog).get(filename)
        if entry and entry.get("remote_url"):
            cache_dir.mkdir(parents=True, exist_ok=True)
            key = hashlib.sha1(f"{entry['remote_url']}|{max_w}".encode("utf-8")).hexdigest()
            cache_path = cache_dir / f"{key}.jpg"
            if cache_path.exists() and cache_path.stat().st_size > 500:
                return cache_path
            try:
                import urllib.request
                thumb_url = f"{entry['remote_url']}=w{max_w}-h{max_w}"
                req = urllib.request.Request(thumb_url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=12) as resp:
                    data = resp.read()
                    if len(data) > 500:
                        cache_path.write_bytes(data)
                        return cache_path
            except Exception:
                pass
        return None

    if Image is None:
        return None
    cache_dir.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha1(f"{src}|{src.stat().st_mtime}|{max_w}|upright-v2".encode("utf-8")).hexdigest()
    cache_path = cache_dir / f"{key}.jpg"
    if cache_path.exists():
        return cache_path
    try:
        from . import portable
        img = portable.open_upright(src).convert("RGB")
        w, h = img.size
        if w > max_w:
            new_h = int(h * max_w / w)
            img = img.resize((max_w, new_h))
        img.save(cache_path, "JPEG", quality=82)
        return cache_path
    except Exception:
        return None


def _fix_focus_in_place(d: dict, orientation: int):
    if d.get("focus_x") is None or d.get("focus_y") is None:
        return
    try:
        fx, fy = raw_to_upright_focus(d["focus_x"], d["focus_y"], orientation)
    except (TypeError, ValueError):
        return
    d["focus_x"] = round(max(0.05, min(0.95, fx)), 3)
    d["focus_y"] = round(max(0.05, min(0.95, fy)), 3)


def migrate_orientation(catalog_path: Path, photos_dir: Path) -> dict:
    """
    一次性遷移：舊版的 dims 與焦點座標是在「未依 EXIF 轉正」的畫面上記錄的。
    對有方向標記的照片，把 dims 改為轉正後尺寸、焦點座標換算到轉正後畫面，
    並同步更新時間軸檔（ordered_photos_detail.json / ordered_photos.json）裡的焦點。
    每張照片處理後標記 orient_v，之後不會重複換算；找不到原檔的照片保留到下次再處理。
    """
    if Image is None:
        return {"checked": 0, "rotated": 0}
    catalog = load_catalog(catalog_path)
    changed = False
    rotated = {}
    checked = 0
    for e in catalog.get("photos", []):
        if e.get("orient_v") == ORIENT_VERSION:
            continue
        src = None
        if e.get("abs_path"):
            cand = Path(e["abs_path"])
            if cand.exists():
                src = cand
        if src is None and e.get("filename"):
            cand = Path(photos_dir) / e["filename"]
            if cand.exists():
                src = cand
        if src is None:
            if e.get("remote_url") and not e.get("downloaded"):
                # Google 相簿 API 給的寬高與縮圖本來就是轉正後的
                e["orient_v"] = ORIENT_VERSION
                changed = True
            continue
        try:
            with Image.open(src) as img:
                raw = img.size
                o = _orientation_of(img)
        except Exception:
            continue
        checked += 1
        if o in (2, 3, 4, 5, 6, 7, 8):
            upright = (raw[1], raw[0]) if o in _ROTATED else raw
            stored = tuple(e.get("dims") or ())
            # 寬高已是轉正後的（例如新版程式寫入的），就不再換算焦點
            already = o in _ROTATED and stored == tuple(upright) and upright != raw
            if not already:
                e["dims"] = list(upright)
                if "width" in e and "height" in e:
                    e["width"], e["height"] = upright
                    e["orientation"] = "landscape" if upright[0] >= upright[1] else "portrait"
                _fix_focus_in_place(e, o)
                rotated[e["filename"]] = o
            e["exif_orientation"] = o
        e["orient_v"] = ORIENT_VERSION
        changed = True

    if changed:
        save_catalog(catalog_path, catalog)

    # 時間軸檔裡複製過去的焦點也一起換算（先存 catalog，避免中斷時重複換算）
    if rotated:
        pdir = Path(catalog_path).parent
        for name in ("ordered_photos_detail.json", "ordered_photos.json"):
            fp = pdir / name
            if not fp.exists():
                continue
            try:
                data = json.loads(fp.read_text(encoding="utf-8"))
                rows = data.get("assignments", []) if isinstance(data, dict) else data
                hit = False
                for row in rows if isinstance(rows, list) else []:
                    if isinstance(row, dict) and row.get("filename") in rotated:
                        _fix_focus_in_place(row, rotated[row["filename"]])
                        hit = True
                if hit:
                    fp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
    return {"checked": checked, "rotated": len(rotated)}
