#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/jobs.py
===========
簡易背景工作追蹤（歌詞對齊 / 渲染都可能耗時數十秒到數分鐘，
不能卡住 HTTP request，所以用背景執行緒跑，狀態寫入 JSON 檔供前端輪詢）。
"""

import json
import threading
import subprocess
from pathlib import Path
from datetime import datetime, timezone, timedelta

_locks = {}
_threads = {}
_lock_guard = threading.Lock()

MAX_LOG_LINES = 400


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def _get_lock(key: str) -> threading.Lock:
    with _lock_guard:
        if key not in _locks:
            _locks[key] = threading.Lock()
        return _locks[key]


def _default_status() -> dict:
    return {
        "status": "idle",
        "started_at": None,
        "finished_at": None,
        "log": [],
        "progress": {"done": 0, "total": 0, "phase": ""},
        "error": None,
        "result": {},
    }


def read_status(job_path: Path) -> dict:
    if job_path.exists():
        try:
            return json.loads(job_path.read_text(encoding="utf-8"))
        except Exception:
            return _default_status()
    return _default_status()


def _write_status(job_path: Path, status: dict):
    lock = _get_lock(str(job_path))
    with lock:
        job_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")


def cancel_job(job_path: Path) -> bool:
    if not is_running(job_path):
        return False
    status = read_status(job_path)
    status["cancel_requested"] = True
    _write_status(job_path, status)
    return True


class JobContext:
    """傳給背景工作函式的介面，讓它可以回報 log / progress / result。"""

    def __init__(self, job_path: Path):
        self.job_path = job_path
        self.status = read_status(job_path)

    def log(self, line: str):
        self.status["log"].append(line)
        if len(self.status["log"]) > MAX_LOG_LINES:
            self.status["log"] = self.status["log"][-MAX_LOG_LINES:]
        _write_status(self.job_path, self.status)

    def progress(self, done: int, total: int, phase: str = ""):
        self.status["progress"] = {"done": done, "total": total, "phase": phase}
        _write_status(self.job_path, self.status)

    def set_result(self, result: dict):
        self.status["result"].update(result)
        _write_status(self.job_path, self.status)

    def is_cancelled(self) -> bool:
        # Check current status from disk in case it was cancelled by another request
        current_status = read_status(self.job_path)
        if current_status.get("cancel_requested"):
            self.status["cancel_requested"] = True
            return True
        return False


def is_running(job_path: Path) -> bool:
    key = str(job_path)
    with _lock_guard:
        t = _threads.get(key)
    return bool(t and t.is_alive())


def start_job(job_path: Path, target) -> bool:
    """
    target: callable(ctx: JobContext) -> None
    若已有相同 job 在跑，回傳 False（不重複啟動）。
    """
    key = str(job_path)
    if is_running(job_path):
        return False

    status = _default_status()
    status["status"] = "running"
    status["started_at"] = _now_tw()
    _write_status(job_path, status)

    def runner():
        ctx = JobContext(job_path)
        try:
            target(ctx)
            ctx.status["status"] = "done"
        except Exception as e:
            ctx.status["status"] = "error"
            ctx.status["error"] = str(e)
            ctx.log(f"❌ 發生錯誤：{e}")
        finally:
            ctx.status["finished_at"] = _now_tw()
            _write_status(job_path, ctx.status)

    t = threading.Thread(target=runner, daemon=True)
    with _lock_guard:
        _threads[key] = t
    t.start()
    return True


def run_subprocess_streamed(ctx: JobContext, cmd: list, cwd=None, env=None):
    """在 JobContext 內執行 subprocess，把每行輸出即時記錄到 log。若失敗會 raise。"""
    ctx.log(f"$ {' '.join(str(c) for c in cmd)}")
    proc = subprocess.Popen(
        cmd, cwd=str(cwd) if cwd else None, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", bufsize=1,
    )
    for line in proc.stdout:
        ctx.log(line.rstrip("\n"))
    proc.wait()
    if proc.returncode != 0:
        raise RuntimeError(f"指令執行失敗（結束碼 {proc.returncode}）")
