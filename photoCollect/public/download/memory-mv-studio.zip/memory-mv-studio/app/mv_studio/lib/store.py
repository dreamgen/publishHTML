#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/store.py
============
多專案註冊表與每個專案的資料夾 / project.json 讀寫。

資料夾結構：
  mv_studio/projects/index.json           -- 專案清單索引
  mv_studio/projects/<project_id>/project.json      -- 專案設定
  mv_studio/projects/<project_id>/lyrics.txt         -- 使用者貼上的歌詞（可選）
  mv_studio/projects/<project_id>/generated.srt      -- 對齊產生的字幕
  mv_studio/projects/<project_id>/lyrics_map.json    -- 每行歌詞 + 主題標籤
  mv_studio/projects/<project_id>/content_plan.json  -- 時間軸規劃
  mv_studio/projects/<project_id>/photo_catalog.json -- 照片標記結果
  mv_studio/projects/<project_id>/ordered_photos.json
  mv_studio/projects/<project_id>/ordered_photos_detail.json
  mv_studio/projects/<project_id>/jobs/<job_key>.json -- 背景工作狀態
"""

import json
import time
import uuid
from pathlib import Path
from datetime import datetime, timezone, timedelta

STUDIO_DIR = Path(__file__).resolve().parent.parent
PROJECTS_DIR = STUDIO_DIR / "projects"
INDEX_FILE = PROJECTS_DIR / "index.json"

DEFAULT_THEME_TEMPLATE = [
    {"name": "Intro", "keywords": ["準備", "開始", "期待", "出發", "牽手", "大步"]},
    {"name": "English", "keywords": ["英文", "English", "自信"]},
    {"name": "Manners", "keywords": ["禮儀", "謝謝", "對不起", "請", "禮貌"]},
    {"name": "Emotions", "keywords": ["生氣", "情緒", "難過", "心情", "摔"]},
    {"name": "Classics", "keywords": ["讀經", "經典", "朗讀", "老師"]},
    {"name": "Quiz", "keywords": ["會考", "闖關", "挑戰", "狀元", "分站"]},
    {"name": "BeachClean", "keywords": ["淨灘", "海灘", "垃圾", "撿"]},
    {"name": "WarmWords", "keywords": ["愛", "擁抱", "信任", "陪伴", "溫暖", "親子", "連結"]},
    {"name": "Outro", "keywords": ["謝謝", "再見", "Yeah", "結束"]},
]

DEFAULT_SLOT_PARAMS = {
    "gap_merge_threshold": 2.0,
    "target_slot_duration": 3.5,
    "min_slot_duration": 2.0,
    "min_lyric_slot": 2.5,
    "beat_snap": True,
    "protagonist_weight": 2.5,
}


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def _ensure_dirs():
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)


def load_index() -> dict:
    _ensure_dirs()
    if INDEX_FILE.exists():
        return json.loads(INDEX_FILE.read_text(encoding="utf-8"))
    return {"projects": []}


def save_index(idx: dict):
    _ensure_dirs()
    INDEX_FILE.write_text(json.dumps(idx, ensure_ascii=False, indent=2), encoding="utf-8")


def project_dir(project_id: str) -> Path:
    return PROJECTS_DIR / project_id


def project_file(project_id: str) -> Path:
    return project_dir(project_id) / "project.json"


def list_projects() -> list:
    idx = load_index()
    out = []
    for entry in idx["projects"]:
        if entry.get("archived"):
            continue
        pf = project_file(entry["id"])
        if pf.exists():
            proj = json.loads(pf.read_text(encoding="utf-8"))
            out.append(proj)
    out.sort(key=lambda p: p.get("updated_at", ""), reverse=True)
    return out


def default_project_template(project_id: str, name: str, song_title: str = "") -> dict:
    now = _now_tw()
    return {
        "id": project_id,
        "name": name,
        "song_title": song_title or name,
        "created_at": now,
        "updated_at": now,
        "music_file": "",
        "lyrics_text_file": "",
        "srt_file": "",
        "photos_dir": "",
        "output_file": "",
        "title_card_file": "片頭.png",
        "outro_file": "片尾.png",
        "title_card_duration": 3.9,
        "outro_duration": 8.0,
        # 新專案預設「空白」主題標籤清單：每首歌的分類都不一樣，避免預先塞入
        # 不相干的範例主題。使用者可以在「內容規劃」分頁按「分析歌詞產生建議」
        # 依這首歌實際歌詞內容長出專屬標籤，或按「載入範例模板」套用參考樣板。
        "themes": [],
        "slot_params": dict(DEFAULT_SLOT_PARAMS),
        "event_info": {
            "event_name": song_title or name,
            "event_date": "",
            "event_end_date": "",
            "event_location": "",
            "organizer": "",
            "slogan": "",
            "schedule_text": "",
            "promo_copy": "",
            "handbook_text": "",
            "expected_groups": [],
            "schedule_slots": [],
            "shot_checklist": [],
            "upload_enabled": True,
            "upload_token": f"ev_{uuid.uuid4().hex[:8]}",
            "public_base_url": "",
            "upload_note": "歡迎上傳活動精采照片！可一次選取多張照片，並勾選所屬活動環節或小隊。",
        },
        "gemini_api_key": "",
        "gemini_model": "gemini-3.5-flash",
        "status": {
            "event_prepared": False,
            "lyrics_aligned": False,
            "content_planned": False,
            "photos_analyzed": 0,
            "manifest_built": False,
            "rendered": False,
        },
    }


def create_project(name: str, song_title: str = "") -> dict:
    _ensure_dirs()
    project_id = f"proj_{int(time.time())}_{uuid.uuid4().hex[:6]}"
    pdir = project_dir(project_id)
    pdir.mkdir(parents=True, exist_ok=True)
    (pdir / "jobs").mkdir(exist_ok=True)

    proj = default_project_template(project_id, name, song_title)
    project_file(project_id).write_text(json.dumps(proj, ensure_ascii=False, indent=2), encoding="utf-8")

    idx = load_index()
    idx["projects"].append({"id": project_id})
    save_index(idx)
    return proj


def get_project(project_id: str) -> dict:
    pf = project_file(project_id)
    if not pf.exists():
        raise FileNotFoundError(f"找不到專案：{project_id}")
    return json.loads(pf.read_text(encoding="utf-8"))


def save_project(project_id: str, data: dict):
    data["updated_at"] = _now_tw()
    project_file(project_id).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def update_project(project_id: str, patch: dict) -> dict:
    proj = get_project(project_id)
    for k, v in patch.items():
        if k in ("id", "created_at"):
            continue
        proj[k] = v
    save_project(project_id, proj)
    return proj


def archive_project(project_id: str):
    idx = load_index()
    for entry in idx["projects"]:
        if entry["id"] == project_id:
            entry["archived"] = True
    save_index(idx)


def default_output_file(proj: dict) -> Path:
    name = proj.get("song_title") or proj.get("name") or "output"
    return project_dir(proj["id"]) / "output" / f"{name}_MV.mp4"


def resolved_srt_file(proj: dict) -> Path:
    if proj.get("srt_file"):
        return Path(proj["srt_file"])
    return project_dir(proj["id"]) / "generated.srt"


def resolved_output_file(proj: dict) -> Path:
    if proj.get("output_file"):
        return Path(proj["output_file"])
    return default_output_file(proj)


def lyrics_map_file(project_id: str) -> Path:
    return project_dir(project_id) / "lyrics_map.json"


def content_plan_file(project_id: str) -> Path:
    return project_dir(project_id) / "content_plan.json"


def catalog_file(project_id: str) -> Path:
    return project_dir(project_id) / "photo_catalog.json"


def ordered_photos_file(project_id: str) -> Path:
    return project_dir(project_id) / "ordered_photos.json"


def ordered_photos_detail_file(project_id: str) -> Path:
    return project_dir(project_id) / "ordered_photos_detail.json"


def jobs_dir(project_id: str) -> Path:
    d = project_dir(project_id) / "jobs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def job_file(project_id: str, job_key: str) -> Path:
    return jobs_dir(project_id) / f"{job_key}.json"
