#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/cloud_sync.py
=================
雲端收照片服務的本地端同步（只用標準函式庫 urllib）。
合約見雲端專案的 API.md §5.5：
  GET  {sync_url}/manifest?cursor=   分頁取得活動設定與照片清單
  GET  {sync_url}/photo/{hash}       下載單張照片
  POST {sync_url}/requirements       回寫各主題需要的張數

專案的 project.json 內以 `cloud` 欄位保存 {url, event_id, key, linked_at, last_sync_at}。
"""

import json
import os
import re
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import store, photos as photos_lib

USER_AGENT = "MVStudio-mvctl/1.0"   # 部分 CDN 會擋掉預設的 Python-urllib 識別字串
RETRIES = 3
TIMEOUT = 40
_SYNC_URL_RE = re.compile(r"^(https?://[^/\s]+)/api/sync/(ev_[A-Za-z0-9_-]{12})$")


class SyncError(Exception):
    """同步過程的一般錯誤（訊息可直接顯示給使用者）。"""


class SyncAuthError(SyncError):
    """同步金鑰錯誤（HTTP 401）。"""


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


# ───────────────────────────────────────────────────────────────
# 網址解析與 HTTP
# ───────────────────────────────────────────────────────────────

def parse_sync_url(raw: str) -> tuple[str, str]:
    """
    把使用者貼上的同步網址正規化成 (sync_url, event_id)。
    容許：前後空白／引號、結尾斜線、多貼了 /manifest、帶 query 或 #片段。
    """
    s = (raw or "").strip().strip("\"'<>").strip()
    s = s.split("#", 1)[0].split("?", 1)[0].rstrip("/")
    if s.endswith("/manifest"):
        s = s[: -len("/manifest")].rstrip("/")
    m = _SYNC_URL_RE.match(s)
    if not m:
        raise SyncError("同步網址格式不正確，應為 https://<主機>/api/sync/ev_xxxxxxxxxxxx（請從雲端管理頁整段複製）")
    return s, m.group(2)


def _request(url: str, key: str, method: str = "GET", body: dict | None = None,
             sink: Path | None = None, expect_size: int = 0):
    """
    發出一次請求，網路錯誤與 5xx 重試 RETRIES 次（逐次等待 1、2 秒）。
    sink 有值時把回應串流寫到該檔案（.part 流程由呼叫端處理），否則回傳解析後的 JSON。
    """
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"Authorization": f"Bearer {key}", "User-Agent": USER_AGENT, "Accept": "*/*"}
    if data is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    last_err = None
    for attempt in range(1, RETRIES + 1):
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                if sink is not None:
                    got = 0
                    with open(sink, "wb") as f:
                        while True:
                            chunk = resp.read(64 * 1024)
                            if not chunk:
                                break
                            f.write(chunk)
                            got += len(chunk)
                    if expect_size and got != expect_size:
                        raise OSError(f"大小不符（收到 {got}，預期 {expect_size}）")
                    return got
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 401:
                raise SyncAuthError("同步金鑰不正確或已被主辦者重發") from None
            if e.code < 500:   # 4xx 重試也不會好，直接回報
                msg = ""
                try:
                    msg = json.loads(e.read().decode("utf-8")).get("message", "")
                except Exception:
                    pass
                err = SyncError(f"雲端回應 HTTP {e.code}" + (f"：{msg}" if msg else ""))
                err.status = e.code
                raise err from None
            last_err = e
        except (urllib.error.URLError, OSError, TimeoutError, ValueError) as e:
            last_err = e
        if attempt < RETRIES:
            time.sleep(attempt)
    raise SyncError(f"網路錯誤（已重試 {RETRIES} 次）：{last_err}")


def fetch_manifest_page(cloud: dict, cursor: str | None = None) -> dict:
    url = cloud["url"].rstrip("/") + "/manifest"
    if cursor:
        url += "?" + urllib.parse.urlencode({"cursor": cursor})
    return _request(url, cloud["key"])


def fetch_manifest(cloud: dict) -> dict:
    """走完所有分頁，回傳合併後的 manifest（event/segments/groups/shots 取第一頁，excluded 取聯集）。"""
    first = fetch_manifest_page(cloud)
    out = {k: first.get(k) for k in ("event", "segments", "groups", "shots")}
    excluded = list(first.get("excluded") or [])
    photos = list(first.get("photos") or [])
    cursor = first.get("cursor")
    seen_cursors = set()
    while cursor and cursor not in seen_cursors:   # 防止伺服器回傳重複 cursor 造成無窮迴圈
        seen_cursors.add(cursor)
        page = fetch_manifest_page(cloud, cursor)
        photos.extend(page.get("photos") or [])
        for h in page.get("excluded") or []:
            if h not in excluded:
                excluded.append(h)
        cursor = page.get("cursor")
    out["excluded"] = excluded
    out["photos"] = photos
    return out


# ───────────────────────────────────────────────────────────────
# 環節判斷（合約 §3 segment_of）
# ───────────────────────────────────────────────────────────────

def _to_min(hm: str) -> int:
    return int(hm[:2]) * 60 + int(hm[3:5])


def rotation_segment_of(photo: dict, rotations: list[dict]):
    """輪站課程（與雲端 rotation.js 一致）：拍攝時間在某輪站區塊的第幾段（換站時間算前一段），再依小隊查輪站表。
    回傳 ("none", None) 不在輪站時段；("hit", 環節名稱)；("bye", 自由活動或 None)；("unknown", None) 判斷不了。"""
    t = photo.get("exif_time") or ""
    if len(t) < 16 or not rotations:
        return ("none", None)
    m, day = _to_min(t[11:16]), t[:10]
    for rot in rotations:
        slots = rot.get("slots") or []
        slot = None
        for i in range(len(slots) - 1, -1, -1):
            sl = slots[i]
            d = sl.get("date") or rot.get("date")
            if d and d != day:
                continue
            # 同一天的下一段開始前都算這一段（換站時間）；當天最後一段到它的結束時間（跨日輪站每段各有日期）
            nxt = slots[i + 1] if i + 1 < len(slots) and slots[i + 1].get("day") == sl.get("day") else None
            until = _to_min(nxt["start"]) if nxt else _to_min(sl["end"])
            if _to_min(sl["start"]) <= m < until:
                slot = i
                break
        if slot is None:
            continue
        results = {row["cells"][slot] for row in rot.get("rows") or [] if row.get("group") in (photo.get("groups") or [])}
        if len(results) != 1:
            return ("unknown", None)
        c = results.pop()
        if c == -1:
            return ("bye", rot.get("free_segment"))
        return ("hit", rot["stations"][c]["segment"])
    return ("none", None)


def segment_of(photo: dict, segments: list[dict], rotations: list[dict] | None = None) -> str | None:
    """手動選的環節（且仍存在）優先；否則用 exif_time 的 HH:MM 落在 [start,end) 的環節。
    多日活動（環節帶 date）時拍攝日期也要相同；沒有日期而多天同時段 → 無法判斷，回 None。與雲端 segmentOf 一致。"""
    names = {s.get("name") for s in segments}
    seg = photo.get("segment")
    if seg and seg != "auto" and seg in names:
        return seg
    kind, name = rotation_segment_of(photo, rotations or [])
    if kind == "hit" or (kind == "bye" and name):
        return name
    if kind == "bye":
        return None
    t = photo.get("exif_time") or ""
    m = re.search(r"T(\d{2}:\d{2})", t)
    if not m:
        return None
    hm = m.group(1)
    hits = [s for s in segments if not s.get("kind") and s.get("start", "") <= hm < s.get("end", "")]
    if not hits:
        return None
    if any(s.get("date") for s in hits):
        day = t[:10]
        return next((s["name"] for s in hits if s.get("date") == day), None)
    if len({s.get("day") for s in hits}) > 1:
        return None
    return hits[0]["name"]


def segments_to_schedule_text(segments: list[dict]) -> str:
    """還原成流程表文字；多日活動在每天前加日期標題（有日期寫 M/D，否則寫「第N天」）。"""
    lines, last_day = [], object()
    for s in segments:
        day = s.get("day")
        if day and day != last_day:
            d = s.get("date")
            lines.append(f"{int(d[5:7])}/{int(d[8:10])}" if d else f"第{day}天")
        last_day = day
        lines.append(f"{s['start']}-{s['end']} {s.get('title') or s['name'] if day else s['name']}")
    return "\n".join(lines)


# ───────────────────────────────────────────────────────────────
# link
# ───────────────────────────────────────────────────────────────

def apply_manifest_to_project(pid: str, proj: dict, manifest: dict) -> dict:
    """把雲端活動資訊寫入專案（event_info、themes）。回傳更新後的專案。"""
    from . import event_prep
    ev = event_prep.ensure_event_info(proj)
    info = manifest.get("event") or {}
    segments = manifest.get("segments") or []
    ev["event_name"] = info.get("name") or ev.get("event_name", "")
    ev["event_date"] = info.get("date") or ""
    ev["event_end_date"] = info.get("end_date") or ""
    ev["event_location"] = info.get("location") or ""
    ev["organizer"] = info.get("organizer") or ""
    plain = [s for s in segments if not s.get("kind")]   # 輪站關卡不寫進流程表文字與時段表（依小隊判斷）
    ev["schedule_text"] = segments_to_schedule_text(plain)
    ev["rotations"] = manifest.get("rotations") or []
    ev["schedule_slots"] = [{
        "time_start": s["start"], "time_end": s["end"], "time_range": f"{s['start']}-{s['end']}",
        "title": s.get("title") or s["name"], "theme": s["name"], "keywords": [],
        "day": s.get("day"), "date": s.get("date"),
    } for s in plain]
    ev["expected_groups"] = list(manifest.get("groups") or [])
    # 保留雲端欄位（segment/target/source），同時補上本地既有格式（theme/title/target_photos）以相容舊畫面
    ev["shot_checklist"] = [{
        **sh, "theme": sh.get("segment", ""), "title": sh.get("segment", ""),
        "time_range": next((f"{s['start']}-{s['end']}" for s in segments if s["name"] == sh.get("segment")), ""),
        "target_photos": sh.get("target", 0),
    } for sh in (manifest.get("shots") or [])]

    patch = {"event_info": ev}
    if not proj.get("themes") and segments:
        # 被當成輪站時段的流程環節（rotation_slot）只是收容判斷不了的照片，主題改由各關卡負責
        patch["themes"] = [{"name": s["name"], "keywords": []} for s in segments if not s.get("rotation_slot")]
    if not proj.get("photos_dir"):
        patch["photos_dir"] = str(store.project_dir(pid) / "photos")
    Path(patch.get("photos_dir") or proj["photos_dir"]).mkdir(parents=True, exist_ok=True)
    return store.update_project(pid, patch)


def link(pid: str, raw_url: str, key: str) -> dict:
    """驗證並保存雲端連結，把活動資訊寫入專案。回傳 {proj, manifest_first, cards_error}。"""
    url, event_id = parse_sync_url(raw_url)
    key = (key or "").strip()
    if not key:
        raise SyncError("缺少同步金鑰（--key）")
    cloud = {"url": url, "event_id": event_id, "key": key}
    first = fetch_manifest_page(cloud)           # 401 會在這裡丟 SyncAuthError
    proj = store.get_project(pid)
    proj = store.update_project(pid, {"cloud": {**cloud, "linked_at": _now_tw()}})
    proj = apply_manifest_to_project(pid, proj, first)

    cards_error = None
    try:   # 片頭片尾失敗不影響連結
        from . import event_prep
        ev = event_prep.ensure_event_info(proj)
        event_prep.generate_event_cards(Path(proj["photos_dir"]), ev, proj)
    except Exception as e:
        cards_error = str(e)
    return {"proj": store.get_project(pid), "first": first, "cards_error": cards_error}


# ───────────────────────────────────────────────────────────────
# sync
# ───────────────────────────────────────────────────────────────

def _safe(s: str, n: int) -> str:
    """只保留字母數字（含中日韓文字）、底線與連字號，避免非法檔名字元。"""
    return re.sub(r"[^\w\-]", "", s or "", flags=re.UNICODE)[:n]


def local_filename(ph: dict) -> str:
    who = _safe(ph.get("device"), 6) or _safe(ph.get("uploader"), 6) or "cloud"
    ext = re.sub(r"[^a-z0-9]", "", (ph.get("ext") or "jpg").lower()) or "jpg"
    return f"{who}_{ph['hash'][:10]}.{ext}"


def _download(cloud: dict, ph: dict, dest: Path):
    part = dest.with_name(dest.name + ".part")
    url = cloud["url"].rstrip("/") + "/photo/" + ph["hash"]
    expect = int(ph.get("size") or 0)
    try:
        _request(url, cloud["key"], sink=part, expect_size=expect)
        os.replace(part, dest)
    finally:
        if part.exists():
            try:
                part.unlink()
            except OSError:
                pass


def _build_entry(ph: dict, dest: Path, hint: str | None, batch_id: int) -> dict:
    exif_time = ph.get("exif_time") or None   # 與 photos.get_exif_time 相同格式：YYYY-MM-DDTHH:MM:SS（活動當地時間）
    dims = photos_lib.get_image_dims(dest)
    w, h = ph.get("w") or (dims[0] if dims else None), ph.get("h") or (dims[1] if dims else None)
    fx, fy = photos_lib.estimate_photo_focus(dest)
    return {
        "filename": dest.name,
        "abs_path": str(dest.resolve()),
        "exif_time": exif_time,
        "time_src": ph.get("time_src") or ("exif" if exif_time else None),
        "file_mtime": photos_lib.get_file_mtime(dest),
        "dims": [w, h] if w and h else (list(dims) if dims else None),
        "width": w, "height": h,
        "size_kb": round(dest.stat().st_size / 1024, 1),
        "batch_id": batch_id,
        "is_slide": False,
        "theme": None,
        "theme_hint": hint,
        "description": "",
        "quality_score": None,
        "fit_scores": {},
        "focus_x": fx,
        "focus_y": fy,
        "protagonists": photos_lib.normalize_protagonists(ph.get("groups")),
        "cloud_groups": photos_lib.normalize_protagonists(ph.get("groups")),   # 上傳者標的小隊；視覺分析匯入時會保留
        "analyzed": False,
        "auto_tagged": False,
        "source": "cloud",
        "cloud_hash": ph["hash"],
        "uploader": ph.get("uploader") or "",
        "device": ph.get("device") or "",
        **_cloud_extras(ph),
    }


def _cloud_extras(ph: dict) -> dict:
    """雲端的上傳者備註、主辦者標的 MV 優先、相簿票數（舊版雲端沒有這些欄位時給預設值）。"""
    note = str(ph.get("note") or "").strip()
    try:
        votes = max(0, int(ph.get("votes") or 0))
    except (TypeError, ValueError):
        votes = 0
    return {"cloud_note": note[:200], "cloud_priority": bool(ph.get("priority")), "cloud_votes": votes}


def _move_excluded(catalog: dict, excluded: list[str], photos_dir: Path) -> list[str]:
    """雲端已排除的照片：本地若有，檔案移到 photos_dir/_excluded/，並從 catalog 移除。回傳被移除的檔名。"""
    ex = set(excluded)
    removed = []
    keep = []
    for p in catalog["photos"]:
        if p.get("cloud_hash") in ex:
            src = Path(p.get("abs_path") or (photos_dir / p["filename"]))
            if src.exists():
                dst_dir = photos_dir / "_excluded"
                dst_dir.mkdir(parents=True, exist_ok=True)
                dst = dst_dir / src.name
                if dst.exists():
                    dst = dst_dir / f"{src.stem}_{int(time.time())}{src.suffix}"
                shutil.move(str(src), str(dst))
            removed.append(p["filename"])
        else:
            keep.append(p)
    catalog["photos"] = keep
    return removed


def sync_once(pid: str, log=print) -> dict:
    """執行一次同步。回傳統計 dict（added/skipped/excluded/failed/by_segment/by_group）。"""
    proj = store.get_project(pid)
    cloud = proj.get("cloud")
    if not cloud:
        raise SyncError(f"專案 {pid} 尚未連結雲端，請先執行 mvctl link")
    manifest = fetch_manifest(cloud)
    segments = manifest.get("segments") or []

    photos_dir = Path(proj.get("photos_dir") or (store.project_dir(pid) / "photos"))
    photos_dir.mkdir(parents=True, exist_ok=True)
    cat_path = store.catalog_file(pid)
    catalog = photos_lib.load_catalog(cat_path)
    by_hash = {p["cloud_hash"]: p for p in catalog["photos"] if p.get("cloud_hash")}
    batch_id = photos_lib.next_batch_id(catalog)

    added = skipped = failed = 0
    ex_set = set(manifest["excluded"])
    todo = [ph for ph in manifest["photos"] if ph.get("hash") and ph["hash"] not in ex_set]
    for i, ph in enumerate(todo, 1):
        hint = segment_of(ph, segments, manifest.get("rotations"))
        have = by_hash.get(ph["hash"])
        if have:
            have["theme_hint"] = hint   # 主辦者可能改了環節時間，提示隨雲端更新
            have["cloud_groups"] = photos_lib.normalize_protagonists(ph.get("groups"))
            if not have.get("analyzed"):
                have["protagonists"] = list(have["cloud_groups"])
            have.update(_cloud_extras(ph))   # 上傳者改了備註、主辦者改了 MV 優先、票數變動都隨雲端更新
            skipped += 1
            continue
        dest = photos_dir / local_filename(ph)
        try:
            expect = int(ph.get("size") or 0)
            if not (dest.exists() and (not expect or dest.stat().st_size == expect)):
                _download(cloud, ph, dest)       # 檔案不存在或大小不符就（重新）下載
            entry = _build_entry(ph, dest, hint, batch_id)
        except SyncAuthError:
            raise
        except Exception as e:
            failed += 1
            log(f"   ⚠️ 下載失敗 {ph['hash'][:10]}：{e}")
            continue
        catalog["photos"].append(entry)
        by_hash[ph["hash"]] = entry
        added += 1
        if added % 20 == 0:   # 定期存檔，Ctrl+C 中斷也不會丟進度
            photos_lib.save_catalog(cat_path, catalog)
            log(f"   … 已下載 {added} 張（{i}/{len(todo)}）")

    removed = _move_excluded(catalog, manifest["excluded"], photos_dir)
    photos_lib.save_catalog(cat_path, catalog)

    cloud_new = {**cloud, "last_sync_at": _now_tw()}
    store.update_project(pid, {"cloud": cloud_new})

    by_segment, by_group = {}, {}
    for p in catalog["photos"]:
        if p.get("source") != "cloud":
            continue
        by_segment[p.get("theme_hint") or "未分類"] = by_segment.get(p.get("theme_hint") or "未分類", 0) + 1
        for g in (p.get("cloud_groups") or ["（未標小隊）"]):
            by_group[g] = by_group.get(g, 0) + 1
    return {"added": added, "skipped": skipped, "excluded": len(removed), "failed": failed,
            "by_segment": by_segment, "by_group": by_group, "batch_id": batch_id if added else None,
            "cloud_total": len(todo)}


# ───────────────────────────────────────────────────────────────
# push-requirements
# ───────────────────────────────────────────────────────────────

def push_requirements(pid: str) -> dict:
    proj = store.get_project(pid)
    cloud = proj.get("cloud")
    if not cloud:
        raise SyncError(f"專案 {pid} 尚未連結雲端，請先執行 mvctl link")
    plan_path = store.content_plan_file(pid)
    if not plan_path.exists():
        raise SyncError("尚未建立 content_plan，請先執行 mvctl plan")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    reqs = plan.get("theme_requirements") or {}
    body = {"requirements": {name: {"photos_needed": int(r.get("photos_needed", 0))} for name, r in reqs.items()}}
    res = _request(cloud["url"].rstrip("/") + "/requirements", cloud["key"], method="POST", body=body)
    return {"sent": len(body["requirements"]), "updated": res.get("updated", 0)}
