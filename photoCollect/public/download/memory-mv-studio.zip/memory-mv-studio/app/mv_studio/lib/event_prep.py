#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/event_prep.py
=================
階段 0：活動前籌備、企劃/流程/宣傳文案/手冊解析、照片募集環境自動建置與即時上傳系統。

核心功能：
1. 儲存與管理活動前資料（活動名稱、日期、地點、主辦、流程表、宣傳文案、活動手冊、預期小隊/主角清單）。
2. 從檔案（.txt / .md / .docx / .doc / .rtf / .html / .pdf）擷取手冊或企劃書文字。
3. 智慧解析活動流程與文案：
   - 自動萃取「活動環節 / 主題標籤 (themes)」與時間區間 (HH:MM-HH:MM)
   - 自動萃取「參與小隊 / 主角標籤 (expected_groups)」（直接銜接人物出場均衡度控制）
   - 自動生成「攝影師建議拍攝清單 (shot_checklist)」
4. 一鍵準備照片募集環境：
   - 自動建立專屬照片資料夾與 photo_catalog.json
   - 自動以 Pillow 繪製 1920x1080 活動專屬「片頭.png」與「片尾.png」
   - 自動產生局域網 / 公網上傳 URL 與純 Python 零依賴 SVG QR Code
5. 處理攝影師手機/網頁端即時批次上傳照片：
   - 自動防撞名儲存、讀取 EXIF 拍攝時間、自動對照活動流程表時間預分配主題
   - 自動執行 <3ms 人臉焦點偵測 (focus_x, focus_y) 與記錄拍攝者 (uploader) 及小隊標籤 (protagonists)
"""

import os
import re
import json
import uuid
import socket
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
from PIL import Image, ImageDraw, ImageFont, ImageFilter

from . import store, photos as photos_lib

DEFAULT_EVENT_INFO = {
    "event_name": "",
    "event_date": "",
    "event_end_date": "",   # 多日活動的最後一天；單日留空
    "event_location": "",
    "organizer": "",
    "slogan": "",
    "schedule_text": "",
    "promo_copy": "",
    "handbook_text": "",
    "handbook_files": [],
    "expected_groups": [],
    "schedule_slots": [],   # [{time_start, time_end, title, theme, keywords}]
    "shot_checklist": [],   # [{theme, title, time_range, tip, target_photos}]
    "upload_enabled": True,
    "upload_token": "",
    "public_base_url": "",
    "upload_note": "歡迎上傳活動精采照片！可一次選取多張照片，並勾選所屬活動環節或小隊。",
}


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def get_lan_ip() -> str:
    """偵測本機在區網 (Wi-Fi / LAN) 的 IPv4 位址，供手機掃描 QR Code 連線。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def ensure_event_info(proj: dict) -> dict:
    """確保專案字典內含完整的 event_info 結構與唯一 upload_token。"""
    ev = dict(DEFAULT_EVENT_INFO)
    saved = proj.get("event_info") or {}
    for k, v in saved.items():
        ev[k] = v
    if not ev.get("event_name"):
        ev["event_name"] = proj.get("song_title") or proj.get("name") or "活動回憶專案"
    if not ev.get("upload_token"):
        ev["upload_token"] = f"ev_{uuid.uuid4().hex[:8]}"
    return ev


def find_project_by_upload_token(token: str) -> tuple[str | None, dict | None]:
    """依 upload_token 或 project_id 查找對應專案。"""
    if not token:
        return None, None
    token = token.strip()
    for p in store.list_projects():
        ev = p.get("event_info") or {}
        if ev.get("upload_token") == token or p.get("id") == token:
            return p["id"], p
    return None, None


# ═══════════════════════════════════════════════════════════════
# 📄 手冊 / 企劃書檔案文字擷取
# ═══════════════════════════════════════════════════════════════

def _docx_text(p: Path) -> str:
    """只用標準函式庫讀 .docx：解壓 word/document.xml，依段落／表格儲存格／換行／tab 還原純文字。"""
    import zipfile
    import xml.etree.ElementTree as ET
    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(p) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    lines = []

    def para_text(par) -> str:
        buf = []
        for node in par.iter():
            if node.tag == ns + "t":
                buf.append(node.text or "")
            elif node.tag == ns + "tab":
                buf.append("\t")
            elif node.tag in (ns + "br", ns + "cr"):
                buf.append("\n")
        return "".join(buf)

    body = root.find(ns + "body")
    for child in (body if body is not None else root):
        if child.tag == ns + "p":
            lines.append(para_text(child))
        elif child.tag == ns + "tbl":
            # 表格：每列一行，儲存格以 " | " 相連（流程表常見「時間 | 內容」）
            for tr in child.iter(ns + "tr"):
                cells = []
                for tc in tr.findall(ns + "tc"):
                    cells.append(" ".join(para_text(par).strip() for par in tc.iter(ns + "p") if para_text(par).strip()))
                lines.append(" | ".join(c for c in cells if c))
    return "\n".join(lines).strip()


def _textutil(p: Path) -> str:
    """macOS 內建 textutil（支援 .doc / .rtf / .html / .odt / .docx）。"""
    proc = subprocess.run(
        ["/usr/bin/textutil", "-convert", "txt", "-stdout", str(p)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="replace", timeout=20,
    )
    return proc.stdout.strip() if proc.returncode == 0 else ""


def _pdf_text(p: Path) -> str:
    """PDF：優先 pypdf（選用相依）；沒有時 macOS 退回 PDFKit（JXA），其他平台回傳清楚錯誤。"""
    try:
        from pypdf import PdfReader  # type: ignore
    except ImportError:
        PdfReader = None
    if PdfReader is not None:
        try:
            text = "\n".join((pg.extract_text() or "") for pg in PdfReader(str(p)).pages).strip()
        except Exception as e:
            raise RuntimeError(f"無法讀取 PDF（{e}），檔案可能損毀或加密，請另存成 .docx 或 .txt") from e
        if text:
            return text
        raise RuntimeError("PDF 內沒有可擷取的文字（可能是掃描圖檔），請改提供 .docx 或 .txt")
    if sys.platform == "darwin":
        jxa = (
            'ObjC.import("Quartz");'
            f'var url = $.NSURL.fileURLWithPath({json.dumps(str(p))});'
            'var doc = $.PDFDocument.alloc.initWithURL(url);'
            'doc ? ObjC.unwrap(doc.string) : "";'
        )
        proc = subprocess.run(
            ["osascript", "-l", "JavaScript", "-e", jxa],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace", timeout=25,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
    raise RuntimeError("無法讀取 PDF：請安裝 pypdf（./venv/bin/pip install pypdf；Windows：venv\\Scripts\\pip install pypdf），"
                       "或把內容另存成 .docx / .txt 再提供")


def extract_document_text(file_path: str | Path) -> str:
    """
    從使用者選擇的活動手冊、流程表或宣傳文案檔案中擷取純文字。
    - .txt/.md/.csv/.json/.srt：直接讀 UTF-8
    - .docx：標準函式庫 zipfile（全平台）
    - .pdf：pypdf（選用）；macOS 無 pypdf 時退回 PDFKit
    - .doc/.rtf/.odt/.html：僅 macOS（textutil）；其他平台請另存成 .docx 或 .txt
    讀不到時一律丟出訊息清楚的例外，不會把二進位內容當文字回傳。
    """
    p = Path(file_path)
    if not p.exists() or not p.is_file():
        raise FileNotFoundError(f"找不到檔案：{p}")

    ext = p.suffix.lower()
    if ext in {".txt", ".md", ".csv", ".tsv", ".json", ".srt"}:
        return p.read_text(encoding="utf-8", errors="ignore").strip()

    if ext == ".docx":
        try:
            text = _docx_text(p)
        except Exception as e:
            if sys.platform == "darwin":   # 檔案格式特殊時，macOS 還有 textutil 可試
                text = _textutil(p)
                if text:
                    return text
            raise RuntimeError(f"無法讀取 .docx（{e}），請確認檔案未損毀，或另存成 .txt") from e
        if not text:
            raise RuntimeError(".docx 內沒有文字內容")
        return text

    if ext == ".pdf":
        return _pdf_text(p)

    if ext in {".doc", ".rtf", ".html", ".htm", ".odt"}:
        if sys.platform == "darwin":
            try:
                text = _textutil(p)
            except Exception:
                text = ""
            if text:
                return text
            raise RuntimeError(f"textutil 無法讀取 {p.name}，請另存成 .docx 或 .txt")
        raise RuntimeError(f"此平台無法直接讀取 {ext} 檔：請另存成 .docx 或 .txt 再提供")

    # 其他副檔名：當純文字讀取
    return p.read_text(encoding="utf-8", errors="ignore").strip()


# ═══════════════════════════════════════════════════════════════
# 🧠 活動流程、宣傳文案、手冊智慧解析
# ═══════════════════════════════════════════════════════════════

_STOP_WORDS = {
    "時間", "活動", "內容", "項目", "流程", "備註", "地點", "說明", "負責人",
    "分鐘", "小時", "上午", "下午", "中午", "晚上", "全體", "大家", "我們",
}


def _extract_keywords_from_title(title: str, desc: str = "") -> list[str]:
    text = f"{title} {desc}"
    tokens = re.findall(r"[\u4e00-\u9fa5]{2,4}|[A-Za-z]{3,12}", text)
    out = []
    for t in tokens:
        if t in _STOP_WORDS:
            continue
        if t not in out:
            out.append(t)
        if len(out) >= 6:
            break
    return out


def _clean_theme_name(raw_title: str) -> str:
    """將流程表標題精簡為適合當主題標籤的名稱（2~8 字）。"""
    s = re.sub(r"^[0-9一二三四五六七八九十、.\s\-—:：()（）【】\[\]]+", "", raw_title).strip()
    # 移除括號內補充說明
    s = re.sub(r"[（(][^）)]*[）)]", "", s).strip()
    # 若有斜線或破折號取前半
    parts = re.split(r"[/｜|—\-：:]", s)
    s = parts[0].strip() if parts else s
    if len(s) > 10:
        s = s[:10]
    return s or "活動精彩瞬間"


# ── 多日活動：日期標題行（與雲端 config.js parseDayHeader 一致）────────────
# 有年份時「2026/11/20」「2026-11-20」「2026年11月20日」；沒年份只認「11/20」「11月20日」
_DATE_HEAD = re.compile(
    r"^(?:(\d{4})\s*[/\-.年]\s*(\d{1,2})\s*[/\-.月]\s*(\d{1,2})|(\d{1,2})\s*/\s*(\d{1,2})|(\d{1,2})\s*月\s*(\d{1,2}))\s*日?(?![\d:./])(.{0,30})$")
_DAY_HEAD = re.compile(r"^(?:day\s*(\d{1,2})|d(\d{1,2})|第\s*([一二三四五六七八九十\d]{1,3})\s*[天日])(?![\d:])(.{0,30})$", re.I)
_RANGE_LINE = re.compile(r"^(\d{1,2})[:：](\d{2})\s*[-–~～至到]\s*(\d{1,2})[:：](\d{2})\s+(.+)$")
_CN = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}


def _cn_to_int(s: str) -> int | None:
    if s.isdigit():
        return int(s)
    if s == "十":
        return 10
    m = re.fullmatch(r"(?:([一二三四五六七八九])?十)?([一二三四五六七八九])?", s)
    if not m:
        return None
    tens = (_CN[m.group(1)] if m.group(1) else 1) * 10 if "十" in s else 0
    return tens + (_CN[m.group(2)] if m.group(2) else 0)


def _add_days(date: str, n: int) -> str:
    return (datetime.strptime(date, "%Y-%m-%d") + timedelta(days=n)).strftime("%Y-%m-%d")


def event_date_text(ev: dict) -> str:
    """單日「2026/11/20」；多日「2026/11/20–11/22」（跨年兩端都寫年份）。"""
    s = ev.get("event_date") or ""
    e = ev.get("event_end_date") or ""
    if not s:
        return ""
    f = lambda d: d.replace("-", "/")
    if not e or e <= s:
        return f(s)
    return f"{f(s)}–{int(e[5:7])}/{int(e[8:10])}" if e[:4] == s[:4] else f"{f(s)}–{f(e)}"


def parse_day_header(line: str, start_date: str | None = None) -> dict | None:
    """一行是日期標題就回 {date: 'YYYY-MM-DD'|None, n: 第幾天|None}，否則 None。"""
    t = re.sub(r"^[#*\s【\[（(]+", "", (line or "").strip())
    t = re.sub(r"[】\]）)]", " ", t, count=1).strip()
    if not t or _RANGE_LINE.match(t):
        return None
    m = _DATE_HEAD.match(t)
    if m:
        mo = int(m.group(2) or m.group(4) or m.group(6))
        da = int(m.group(3) or m.group(5) or m.group(7))
        y = int(m.group(1)) if m.group(1) else (int(start_date[:4]) if start_date else datetime.now().year)
        def mk(yy):
            return f"{yy}-{mo:02d}-{da:02d}"
        try:
            if not m.group(1) and start_date and mk(y) < _add_days(start_date, -180):
                y += 1
            datetime.strptime(mk(y), "%Y-%m-%d")
        except ValueError:
            return None
        return {"date": mk(y), "n": None}
    m = _DAY_HEAD.match(t)
    if m:
        n = int(m.group(1) or m.group(2)) if (m.group(1) or m.group(2)) else _cn_to_int(m.group(3))
        if not n or n < 1 or n > 60:
            return None
        return {"date": _add_days(start_date, n - 1) if start_date else None, "n": n}
    return None


def parse_schedule_text(schedule_text: str, start_date: str | None = None) -> list[dict]:
    """多日活動：每天流程前放一行日期標題（「11/20」「Day 2」「第二天」），兩天以上時主題名稱加「第N天・」。"""
    raw = _parse_schedule_lines(schedule_text, start_date)
    days = {s["day"] for s in raw if s.get("day")}
    multi = len(days) >= 2
    out, seen = [], set()
    for s in raw:
        if multi:
            s["theme"] = f"第{s['day']}天・{s['theme']}"
        else:
            s["day"], s["date"] = None, None
        if s["theme"] in seen:
            continue
        seen.add(s["theme"])
        out.append(s)
    return out


def _parse_schedule_lines(schedule_text: str, start_date: str | None = None) -> list[dict]:
    """
    解析活動流程文字，抓出時間區間 (如 09:00-09:30) 與對應活動環節。
    支援格式：
      - 09:00 - 09:30 報到與相見歡
      - 09:30~10:30 【破冰遊戲】團隊默契大考驗
      - 1. 迎賓入場 / 2. 分站闖關 / 3. 溫馨感恩
    """
    if not schedule_text or not schedule_text.strip():
        return []

    lines = [ln.strip() for ln in schedule_text.splitlines() if ln.strip()]
    slots = []
    cur = None   # {"n", "date", "count"}
    time_pat = re.compile(
        r"(?:(\d{1,2}[:：]\d{2})\s*(?:[-~～至到—]+\s*(\d{1,2}[:：]\d{2}))?)\s*(.+)"
    )

    for ln in lines:
        # 跳過純表格分隔線或標題列
        if re.match(r"^[-=|_+\s]+$", ln):
            continue
        hd = parse_day_header(ln, start_date)
        if hd:
            n = hd["n"] or ((cur["n"] + 1) if cur and cur["count"] else (cur["n"] if cur else 1))
            date = hd["date"] or (_add_days(start_date, n - 1) if start_date else None)
            if cur and not cur["count"]:
                cur.update(n=n, date=date)
            else:
                cur = {"n": n, "date": date, "count": 0}
            continue
        if cur is None:
            cur = {"n": 1, "date": start_date or None, "count": 0}
        before = len(slots)
        m = time_pat.search(ln)
        if m:
            t_start = m.group(1).replace("：", ":")
            t_end = (m.group(2) or "").replace("：", ":")
            rest = m.group(3).strip(" \t|-—：:、")
            if not rest or rest in _STOP_WORDS:
                continue
            # 過濾純休息/用餐/賦歸或保留為活動環節
            theme_name = _clean_theme_name(rest)
            kws = _extract_keywords_from_title(theme_name, rest)
            slots.append({
                "time_start": t_start,
                "time_end": t_end,
                "time_range": f"{t_start}-{t_end}" if t_end else t_start,
                "title": rest,
                "theme": theme_name,
                "keywords": kws,
            })
        else:
            # 嘗試匹配編號項目或【環節名稱】
            m_bracket = re.search(r"【([^】]{2,12})】\s*(.*)", ln)
            m_num = re.match(r"^(?:Step\s*\d+|階段[一二三四五六七八九十\d]+|[0-9一二三四五六七八九十]+[、.．])\s*(.+)", ln, re.I)
            if m_bracket:
                tname = _clean_theme_name(m_bracket.group(1))
                desc = m_bracket.group(2).strip()
                slots.append({
                    "time_start": "",
                    "time_end": "",
                    "time_range": "",
                    "title": f"{tname} {desc}".strip(),
                    "theme": tname,
                    "keywords": _extract_keywords_from_title(tname, desc),
                })
            elif m_num:
                raw = m_num.group(1).strip()
                tname = _clean_theme_name(raw)
                if len(tname) >= 2 and tname not in _STOP_WORDS:
                    slots.append({
                        "time_start": "",
                        "time_end": "",
                        "time_range": "",
                        "title": raw,
                        "theme": tname,
                        "keywords": _extract_keywords_from_title(tname, raw),
                    })
        for s in slots[before:]:
            s["day"], s["date"] = cur["n"], cur["date"]
        cur["count"] += len(slots) - before

    return slots


def extract_expected_groups(schedule_text: str, promo_copy: str, handbook_text: str, existing_groups: list = None) -> list[str]:
    """
    從手冊、流程與文案中自動偵測小隊、組別或班級名單（如「第一小隊」、「A組」、「向日葵小隊」）。
    """
    combined = "\n".join([schedule_text or "", promo_copy or "", handbook_text or ""])
    found = list(existing_groups or [])

    patterns = [
        r"第[一二三四五六七八九十0-9]{1,3}(?:小隊|分隊|組|隊|中隊|班)",
        r"[A-Z0-9]{1,2}\s*(?:小隊|組|隊)",
        r"[\u4e00-\u9fa5]{2,4}小隊",
    ]
    for pat in patterns:
        for m in re.findall(pat, combined):
            clean = re.sub(r"\s+", "", m.strip())
            if clean in {"每一小隊", "各小隊", "同小隊", "本小隊", "哪一小隊"}:
                continue
            if clean not in found:
                found.append(clean)

    return found[:24]


def analyze_event_materials(event_info: dict, existing_themes: list = None) -> dict:
    """
    綜合分析活動流程、宣傳文案與手冊，產出：
    - schedule_slots: 結構化時程表
    - suggested_themes: 建議的 MV 主題標籤清單 [{name, keywords}]
    - expected_groups: 預期參與小隊/人物標籤清單
    - shot_checklist: 給攝影師的建議拍攝清單
    """
    sched_txt = event_info.get("schedule_text", "")
    promo_txt = event_info.get("promo_copy", "")
    hand_txt = event_info.get("handbook_text", "")

    start = event_info.get("event_date") or None
    schedule_slots = parse_schedule_text(sched_txt, start)
    if not schedule_slots and hand_txt:
        schedule_slots = parse_schedule_text(hand_txt, start)

    # 彙整主題清單
    themes_map = {}
    for s in schedule_slots:
        tname = s["theme"]
        if not tname:
            continue
        if tname not in themes_map:
            themes_map[tname] = list(s.get("keywords") or [tname])
        else:
            for k in (s.get("keywords") or []):
                if k not in themes_map[tname]:
                    themes_map[tname].append(k)

    # 從宣傳文案與手冊中補充常見的情感/活動主題（如破冰、闖關、溫馨互動、大合照）
    combined_txt = f"{sched_txt}\n{promo_txt}\n{hand_txt}"
    common_event_themes = [
        ("報到迎賓", ["報到", "簽到", "迎賓", "集合", "出發", "相見歡"]),
        ("破冰互動", ["破冰", "早操", "帶動跳", "暖身", "熱身"]),
        ("團隊闖關", ["闖關", "挑戰", "分站", "競賽", "任務", "合作", "遊戲"]),
        ("課程學習", ["課程", "講座", "學習", "讀經", "手作", "體驗", "DIY"]),
        ("戶外探索", ["戶外", "自然", "露營", "野炊", "生態", "淨灘", "步道"]),
        ("溫馨分享", ["分享", "感恩", "擁抱", "感動", "回饋", "陪伴", "暖心"]),
        ("頒獎大合照", ["頒獎", "結業", "大合照", "團體照", "賦歸", "圓滿"]),
    ]
    for tname, kws in common_event_themes:
        hit_kws = [k for k in kws if k in combined_txt]
        if hit_kws and tname not in themes_map and len(themes_map) < 10:
            themes_map[tname] = kws[:5]

    # 若完全沒有輸入任何流程或文案，提供基礎活動四階段主題
    if not themes_map:
        for tname, kws in [
            ("報到迎賓", ["報到", "出發", "期待", "集合"]),
            ("活動亮點", ["挑戰", "合作", "闖關", "專注"]),
            ("溫馨互動", ["笑容", "陪伴", "互動", "分享"]),
            ("圓滿大合照", ["大合照", "感謝", "回憶", "再見"]),
        ]:
            themes_map[tname] = kws

    suggested_themes = [
        {"name": name, "keywords": kws[:6]}
        for name, kws in themes_map.items()
    ]

    expected_groups = extract_expected_groups(
        sched_txt, promo_txt, hand_txt, event_info.get("expected_groups")
    )

    # 產生給攝影師的建議拍攝清單 (Shot Checklist)
    shot_checklist = []
    if schedule_slots:
        for s in schedule_slots:
            shot_checklist.append({
                "theme": s["theme"],
                "title": s["title"],
                "time_range": s.get("time_range", ""),
                "tip": f"建議拍攝「{s['title']}」的人物正面神情、互動特寫與全景畫面（橫式 16:9 最佳）",
                "target_photos": 10,
            })
    else:
        for t in suggested_themes:
            shot_checklist.append({
                "theme": t["name"],
                "title": t["name"],
                "time_range": "",
                "tip": f"捕捉包含「{'、'.join(t['keywords'][:3])}」的精采人物笑臉與互動畫面",
                "target_photos": 10,
            })

    if expected_groups:
        shot_checklist.append({
            "theme": "小隊均衡",
            "title": f"各組別 / 小隊均衡拍攝（共 {len(expected_groups)} 組）",
            "time_range": "全天",
            "tip": f"請確認 {', '.join(expected_groups[:8])} 每一組都有小組合照與隊員特寫，系統將自動平衡出場率！",
            "target_photos": len(expected_groups) * 4,
        })

    return {
        "schedule_slots": schedule_slots,
        "suggested_themes": suggested_themes,
        "expected_groups": expected_groups,
        "shot_checklist": shot_checklist,
    }


# ═══════════════════════════════════════════════════════════════
# 🎨 自動產生 1920x1080 片頭卡與片尾卡
# ═══════════════════════════════════════════════════════════════

def _load_cjk_font(size: int, text: str = ""):
    """片頭／片尾卡字型：與字幕同一套繁體優先＋缺字檢驗（避免「啟」等字變方框）。"""
    from . import portable
    choice = portable.choose_cjk_font(text)
    if choice:
        try:
            return choice.load(size)
        except Exception:
            pass
    return ImageFont.load_default()


def generate_event_cards(photos_dir: Path, event_info: dict, proj: dict) -> dict:
    """
    根據活動名稱、日期、地點、標語與主辦單位，自動在 photos_dir 產生美觀的 1920x1080 片頭.png 與 片尾.png。
    """
    photos_dir.mkdir(parents=True, exist_ok=True)
    w, h = 1920, 1080

    event_name = event_info.get("event_name") or proj.get("song_title") or proj.get("name") or "活動回憶 MV"
    slogan = event_info.get("slogan") or ""
    if not slogan and event_info.get("promo_copy"):
        first_line = [ln.strip() for ln in event_info["promo_copy"].splitlines() if ln.strip()]
        if first_line:
            slogan = first_line[0][:36]
    date_str = event_date_text(event_info)
    loc_str = event_info.get("event_location") or ""
    org_str = event_info.get("organizer") or ""

    title_filename = proj.get("title_card_file") or "片頭.png"
    outro_filename = proj.get("outro_file") or "片尾.png"
    title_path = photos_dir / title_filename
    outro_path = photos_dir / outro_filename

    def _draw_card(out_path: Path, main_title: str, sub_line: str, footer_line: str, palette: tuple):
        img = Image.new("RGB", (w, h), palette[0])
        draw = ImageDraw.Draw(img)
        # 柔和漸層背景
        for y in range(h):
            ratio = y / h
            r = int(palette[0][0] * (1 - ratio) + palette[1][0] * ratio)
            g = int(palette[0][1] * (1 - ratio) + palette[1][1] * ratio)
            b = int(palette[0][2] * (1 - ratio) + palette[1][2] * ratio)
            draw.line([(0, y), (w, y)], fill=(r, g, b))

        # 裝飾外框
        margin = 64
        draw.rounded_rectangle(
            [margin, margin, w - margin, h - margin],
            radius=28,
            outline=(255, 255, 255, 90),
            width=3,
        )

        # 卡片上所有文字一起檢查缺字
        card_text = " ".join(str(v) for v in (event_info or {}).values() if isinstance(v, str)) + main_title
        font_title = _load_cjk_font(92 if len(main_title) <= 14 else 72, card_text)
        font_sub = _load_cjk_font(44, card_text)
        font_foot = _load_cjk_font(34, card_text)

        # 主標題置中
        tb = draw.textbbox((0, 0), main_title, font=font_title)
        tw, th = tb[2] - tb[0], tb[3] - tb[1]
        draw.text(
            ((w - tw) // 2, h // 2 - th - 30),
            main_title,
            font=font_title,
            fill=(255, 250, 240),
            stroke_width=4,
            stroke_fill=(20, 24, 40),
        )

        # 副標題
        if sub_line:
            sb = draw.textbbox((0, 0), sub_line, font=font_sub)
            sw = sb[2] - sb[0]
            draw.text(
                ((w - sw) // 2, h // 2 + 24),
                sub_line,
                font=font_sub,
                fill=(255, 218, 130),
                stroke_width=2,
                stroke_fill=(20, 24, 40),
            )

        # 底部日期/地點/主辦
        if footer_line:
            fb = draw.textbbox((0, 0), footer_line, font=font_foot)
            fw = fb[2] - fb[0]
            draw.text(
                ((w - fw) // 2, h - margin - 80),
                footer_line,
                font=font_foot,
                fill=(220, 230, 245),
            )

        img.save(out_path, format="PNG")

    meta_parts = [x for x in (date_str, loc_str, org_str) if x]
    footer_txt = "  ｜  ".join(meta_parts)

    _draw_card(
        title_path,
        main_title=event_name,
        sub_line=slogan or "精彩活動回憶錄",
        footer_line=footer_txt,
        palette=((28, 42, 78), (68, 38, 82)),
    )
    _draw_card(
        outro_path,
        main_title="感謝每一位參與的夥伴",
        sub_line=event_name,
        footer_line=org_str or footer_txt or "珍貴回憶・永存心中",
        palette=((32, 52, 68), (22, 30, 48)),
    )
    return {
        "title_card_path": str(title_path),
        "outro_card_path": str(outro_path),
    }


# ═══════════════════════════════════════════════════════════════
# 📱 純 Python 零依賴 ISO/IEC 18004 QR Code SVG 產生器
# ═══════════════════════════════════════════════════════════════

# GF(256) 指數與對數表 (primitive polynomial 0x11D)
_GF_EXP = [0] * 512
_GF_LOG = [0] * 256
_x = 1
for _i in range(255):
    _GF_EXP[_i] = _x
    _GF_LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _GF_EXP[_i] = _GF_EXP[_i - 255]

# Version 1..6 Level L: (total_codewords, ec_codewords_per_block, num_blocks, alignment_Version_positions)
_QR_VER_L = {
    1: (26, 7, 1, []),
    2: (44, 10, 1, [6, 18]),
    3: (70, 15, 1, [6, 22]),
    4: (100, 20, 1, [6, 26]),
    5: (134, 26, 1, [6, 30]),
    6: (172, 18, 2, [6, 34]),
}


def _rs_generator_poly(nsym: int) -> list[int]:
    g = [1]
    for i in range(nsym):
        ng = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            ng[j] ^= c
            if c != 0:
                ng[j + 1] ^= _GF_EXP[_GF_LOG[c] + i]
        g = ng
    return g


def _rs_encode(data: list[int], nsym: int) -> list[int]:
    gen = _rs_generator_poly(nsym)
    res = list(data) + [0] * nsym
    for i in range(len(data)):
        coef = res[i]
        if coef != 0:
            lcoef = _GF_LOG[coef]
            for j in range(1, len(gen)):
                if gen[j] != 0:
                    res[i + j] ^= _GF_EXP[lcoef + _GF_LOG[gen[j]]]
    return res[len(data):]


def generate_qr_svg(text: str, box_size: int = 6, border: int = 3) -> str:
    """
    將網址或文字編碼為標準 ISO/IEC 18004 QR Code (Level L, Version 1~6) 並回傳 SVG 字串。
    完全不依賴外部套件，手機相機可直接掃描開啟上傳頁面。
    """
    raw = text.encode("utf-8")
    ver = None
    for v, (tot, ec, blk, _) in _QR_VER_L.items():
        data_cap = tot - ec * blk
        if len(raw) + 2 <= data_cap:
            ver = v
            break
    if ver is None:
        ver = 6
        raw = raw[:132]

    tot_cw, ec_cw, num_blocks, align_pos = _QR_VER_L[ver]
    data_cw = tot_cw - ec_cw * num_blocks

    # 1. 編碼 Byte mode bit stream (0100 + 8-bit length + bytes + terminator)
    bits = [0, 1, 0, 0]
    for b in range(7, -1, -1):
        bits.append((len(raw) >> b) & 1)
    for byte in raw:
        for b in range(7, -1, -1):
            bits.append((byte >> b) & 1)
    bits.extend([0] * min(4, data_cw * 8 - len(bits)))
    while len(bits) % 8 != 0:
        bits.append(0)
    codewords = []
    for i in range(0, len(bits), 8):
        val = 0
        for b in bits[i:i + 8]:
            val = (val << 1) | b
        codewords.append(val)
    pad_bytes = [0xEC, 0x11]
    while len(codewords) < data_cw:
        codewords.append(pad_bytes[(len(codewords)) % 2])

    # 2. 分塊並計算 Reed-Solomon 糾錯碼
    if num_blocks == 1:
        ec = _rs_encode(codewords, ec_cw)
        final_cw = codewords + ec
    else:
        blk_len = data_cw // num_blocks
        b1 = codewords[:blk_len]
        b2 = codewords[blk_len:]
        ec1 = _rs_encode(b1, ec_cw)
        ec2 = _rs_encode(b2, ec_cw)
        final_cw = []
        for a, b in zip(b1, b2):
            final_cw.extend([a, b])
        for a, b in zip(ec1, ec2):
            final_cw.extend([a, b])

    # 3. 建立矩陣
    size = 17 + 4 * ver
    matrix = [[None] * size for _ in range(size)]
    reserved = [[False] * size for _ in range(size)]

    def _place_finder(r0, c0):
        for dr in range(-1, 8):
            for dc in range(-1, 8):
                r, c = r0 + dr, c0 + dc
                if 0 <= r < size and 0 <= c < size:
                    if 0 <= dr <= 6 and 0 <= dc <= 6:
                        on = (dr in (0, 6) or dc in (0, 6) or (2 <= dr <= 4 and 2 <= dc <= 4))
                        matrix[r][c] = 1 if on else 0
                    else:
                        matrix[r][c] = 0
                    reserved[r][c] = True

    _place_finder(0, 0)
    _place_finder(0, size - 7)
    _place_finder(size - 7, 0)

    # Alignment patterns
    for ar in align_pos:
        for ac in align_pos:
            if reserved[ar][ac]:
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    on = (abs(dr) == 2 or abs(dc) == 2 or (dr == 0 and dc == 0))
                    matrix[ar + dr][ac + dc] = 1 if on else 0
                    reserved[ar + dr][ac + dc] = True

    # Timing patterns
    for i in range(8, size - 8):
        if not reserved[6][i]:
            matrix[6][i] = (i + 1) % 2
            reserved[6][i] = True
        if not reserved[i][6]:
            matrix[i][6] = (i + 1) % 2
            reserved[i][6] = True

    # Dark module & Format info areas reservation
    matrix[size - 8][8] = 1
    reserved[size - 8][8] = True
    for i in range(9):
        if i < size:
            reserved[8][i] = True
            reserved[i][8] = True
    for i in range(8):
        reserved[8][size - 1 - i] = True
        reserved[size - 1 - i][8] = True

    # 4. 填入資料位元
    all_bits = []
    for cw in final_cw:
        for b in range(7, -1, -1):
            all_bits.append((cw >> b) & 1)

    bit_idx = 0
    col = size - 1
    upward = True
    while col > 0:
        if col == 6:
            col -= 1
        rows = range(size - 1, -1, -1) if upward else range(size)
        for r in rows:
            for dc in (0, -1):
                c = col + dc
                if not reserved[r][c]:
                    b = all_bits[bit_idx] if bit_idx < len(all_bits) else 0
                    bit_idx += 1
                    # Mask 0: (r + c) % 2 == 0
                    if (r + c) % 2 == 0:
                        b ^= 1
                    matrix[r][c] = b
        upward = not upward
        col -= 2

    # 5. 填入 Format Information (Level L = 01, Mask 0 = 000 -> BCH 0x77C4)
    fmt = 0x77C4
    fmt_bits = [(fmt >> i) & 1 for i in range(15)]  # LSB first
    # Around top-left
    tl_coords = [
        (8, 0), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 7), (8, 8),
        (7, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (0, 8),
    ]
    for idx, (r, c) in enumerate(tl_coords):
        matrix[r][c] = fmt_bits[14 - idx]
    # Bottom-left & top-right
    for idx in range(7):
        matrix[size - 1 - idx][8] = fmt_bits[14 - idx]
    for idx in range(7, 15):
        matrix[8][size - 15 + idx] = fmt_bits[14 - idx]

    # 6. 輸出 SVG
    total_px = (size + border * 2) * box_size
    rects = []
    for r in range(size):
        for c in range(size):
            if matrix[r][c]:
                x = (c + border) * box_size
                y = (r + border) * box_size
                rects.append(f'<rect x="{x}" y="{y}" width="{box_size}" height="{box_size}"/>')
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total_px} {total_px}" '
        f'width="{total_px}" height="{total_px}" shape-rendering="crispEdges">'
        f'<rect width="100%" height="100%" fill="#ffffff" rx="8"/>'
        f'<g fill="#111827">{"".join(rects)}</g></svg>'
    )


# ═══════════════════════════════════════════════════════════════
# 🚀 一鍵建置照片收集環境與處理攝影師上傳
# ═══════════════════════════════════════════════════════════════

def build_upload_urls(proj: dict, port: int = 8787) -> dict:
    ev = ensure_event_info(proj)
    token = ev["upload_token"]
    lan_ip = get_lan_ip()
    lan_url = f"http://{lan_ip}:{port}/upload/{token}"
    local_url = f"http://localhost:{port}/upload/{token}"
    pub_base = (ev.get("public_base_url") or "").strip().rstrip("/")
    public_url = f"{pub_base}/upload/{token}" if pub_base else ""
    primary_url = public_url or lan_url
    return {
        "upload_token": token,
        "lan_ip": lan_ip,
        "lan_url": lan_url,
        "local_url": local_url,
        "public_url": public_url,
        "primary_url": primary_url,
        "qr_svg": generate_qr_svg(primary_url),
    }


def prepare_collection_environment(
    project_id: str,
    proj: dict,
    event_patch: dict | None = None,
    sync_themes: bool = True,
    generate_cards: bool = True,
    port: int = 8787,
) -> dict:
    """
    一鍵準備活動照片募集環境：
    1. 更新 event_info 並執行智慧解析（流程時段、主題標籤、預期小隊、拍攝清單）
    2. 確保專屬 photos_dir 資料夾與 photo_catalog.json 已建立
    3. 自動產生 1920x1080 片頭.png 與 片尾.png
    4. 產生上傳 URL 與 QR Code
    """
    ev = ensure_event_info(proj)
    if event_patch:
        for k, v in event_patch.items():
            if k in DEFAULT_EVENT_INFO:
                ev[k] = v

    parsed = analyze_event_materials(ev, proj.get("themes", []))
    ev["schedule_slots"] = parsed["schedule_slots"]
    ev["shot_checklist"] = parsed["shot_checklist"]
    if not ev.get("expected_groups") and parsed["expected_groups"]:
        ev["expected_groups"] = parsed["expected_groups"]

    # 確保照片收集資料夾存在
    pdir_str = (proj.get("photos_dir") or "").strip()
    if not pdir_str:
        pdir = store.project_dir(project_id) / "photos"
        pdir_str = str(pdir)
    else:
        pdir = Path(pdir_str)
    pdir.mkdir(parents=True, exist_ok=True)

    # 初始化 photo_catalog.json
    cat_path = store.catalog_file(project_id)
    if not cat_path.exists():
        photos_lib.save_catalog(cat_path, {"photos": [], "batches": []})

    # 若專案尚無主題或要求同步主題，將解析出的活動環節寫入 proj["themes"]
    themes = list(proj.get("themes") or [])
    if (sync_themes or not themes) and parsed["suggested_themes"]:
        existing_names = {t["name"] for t in themes}
        for st in parsed["suggested_themes"]:
            if st["name"] not in existing_names:
                themes.append(st)
                existing_names.add(st["name"])

    # 自動生成片頭與片尾卡
    cards_info = {}
    if generate_cards:
        cards_info = generate_event_cards(pdir, ev, proj)

    status = dict(proj.get("status") or {})
    status["event_prepared"] = True

    updated_proj = store.update_project(project_id, {
        "photos_dir": pdir_str,
        "song_title": proj.get("song_title") or ev.get("event_name") or proj.get("name"),
        "themes": themes,
        "event_info": ev,
        "status": status,
    })

    urls = build_upload_urls(updated_proj, port=port)
    return {
        "ok": True,
        "project": updated_proj,
        "event_info": ev,
        "themes": themes,
        "photos_dir": pdir_str,
        "cards": cards_info,
        "upload": urls,
    }


def _match_theme_by_exif_time(exif_time_str: str | None, schedule_slots: list[dict]) -> str | None:
    """
    若照片有 EXIF 拍攝時間 (YYYY-MM-DDTHH:MM:SS)，自動比對活動流程表的時段 (HH:MM-HH:MM)，
    直接預填對應的活動環節主題！
    """
    if not exif_time_str or not schedule_slots:
        return None
    m = re.search(r"T(\d{2}):(\d{2})", exif_time_str)
    if not m:
        return None
    photo_mins = int(m.group(1)) * 60 + int(m.group(2))
    # 多日活動：時段有日期時，拍攝日期也要相同
    photo_day = exif_time_str[:10]
    if any(s.get("date") for s in schedule_slots):
        schedule_slots = [s for s in schedule_slots if s.get("date") == photo_day]

    def _to_mins(hhmm: str) -> int | None:
        parts = hhmm.split(":")
        if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
            return int(parts[0]) * 60 + int(parts[1])
        return None

    for s in schedule_slots:
        s_min = _to_mins(s.get("time_start", ""))
        e_min = _to_mins(s.get("time_end", ""))
        if s_min is not None and e_min is not None:
            if s_min - 5 <= photo_mins <= e_min + 5:
                return s.get("theme")
    return None


def handle_uploaded_photos(
    project_id: str,
    proj: dict,
    uploaded_files: list[dict],
    uploader: str = "匿名夥伴",
    selected_theme: str = "",
    protagonists_raw: str | list = "",
    note: str = "",
) -> dict:
    """
    儲存從 `/api/upload/<token>` 上傳的多張照片，並立即寫入 photo_catalog.json：
    - uploaded_files: [{"filename": str, "data": bytes}, ...]
    - 自動防撞名、提取 EXIF 拍攝時間、偵測人臉焦點 (focus_x, focus_y)
    - 若 selected_theme 為空或 'auto'，自動比對活動流程表時間預分配主題
    """
    ev = ensure_event_info(proj)
    if not ev.get("upload_enabled", True):
        raise ValueError("此活動目前已關閉照片上傳功能")

    pdir_str = proj.get("photos_dir") or str(store.project_dir(project_id) / "photos")
    pdir = Path(pdir_str)
    pdir.mkdir(parents=True, exist_ok=True)

    cat_path = store.catalog_file(project_id)
    catalog = photos_lib.load_catalog(cat_path)
    batch_id = photos_lib.next_batch_id(catalog)

    protagonists = photos_lib.normalize_protagonists(protagonists_raw)
    uploader_clean = (uploader or "匿名夥伴").strip()[:24]
    valid_theme_names = {t["name"] for t in (proj.get("themes") or [])}
    schedule_slots = ev.get("schedule_slots") or []

    saved_items = []
    ts_prefix = datetime.now().strftime("%H%M%S")

    for idx, item in enumerate(uploaded_files):
        orig_name = Path(item.get("filename") or f"photo_{idx+1}.jpg").name
        ext = Path(orig_name).suffix.lower()
        if ext not in photos_lib.PHOTO_EXTS:
            continue

        # 避免不同手機上傳同名 IMG_0001.JPG 互相覆蓋
        stem = re.sub(r"[^\w\u4e00-\u9fa5\-]", "_", Path(orig_name).stem)[:40]
        dest_name = f"{stem}{ext}"
        dest_path = pdir / dest_name
        if dest_path.exists():
            dest_name = f"{stem}_{ts_prefix}_{idx+1}{ext}"
            dest_path = pdir / dest_name

        dest_path.write_bytes(item["data"])

        exif_time = photos_lib.get_exif_time(dest_path)
        mtime = photos_lib.get_file_mtime(dest_path)
        w, h = photos_lib.get_image_dims(dest_path) or (0, 0)
        fx, fy = photos_lib.estimate_photo_focus(dest_path)

        # 決定主題：手動指定 > EXIF 時間自動匹配流程表 > None
        assigned_theme = None
        if selected_theme and selected_theme != "auto" and selected_theme in valid_theme_names:
            assigned_theme = selected_theme
        else:
            matched = _match_theme_by_exif_time(exif_time, schedule_slots)
            if matched and (not valid_theme_names or matched in valid_theme_names):
                assigned_theme = matched

        fit_scores = {}
        if assigned_theme:
            fit_scores = {t: (8.5 if t == assigned_theme else 3.0) for t in valid_theme_names}

        desc_parts = []
        if uploader_clean:
            desc_parts.append(f"📸 {uploader_clean} 上傳")
        if note:
            desc_parts.append(note.strip())

        entry = {
            "filename": dest_name,
            "abs_path": str(dest_path),
            "batch_id": batch_id,
            "exif_time": exif_time,
            "file_mtime": mtime,
            "width": w,
            "height": h,
            "orientation": "landscape" if w >= h else "portrait",
            # 時段比對只是「主題提示」：仍標記為未分析，讓 AI 視覺分析補上真實畫質分與 fit_scores，
            # 避免模糊／閉眼照片因預設 8.0 分而優先被排進 MV
            "analyzed": False,
            "theme": assigned_theme,
            "theme_hint": assigned_theme,
            "quality_score": None,
            "fit_scores": fit_scores,
            "focus_x": fx,
            "focus_y": fy,
            "protagonists": protagonists,
            "uploader": uploader_clean,
            "uploaded_at": _now_tw(),
            "description": "｜".join(desc_parts) if desc_parts else "",
        }
        catalog["photos"].append(entry)
        saved_items.append(entry)

    if saved_items:
        catalog.setdefault("batches", []).append({
            "batch_id": batch_id,
            "scanned_at": _now_tw(),
            "source_dir": f"upload:{uploader_clean}",
            "photo_count": len(saved_items),
        })
        photos_lib.save_catalog(cat_path, catalog)
        analyzed_count = sum(1 for p in catalog["photos"] if p.get("analyzed"))
        store.update_project(project_id, {
            "photos_dir": str(pdir),
            "status": {**(proj.get("status") or {}), "photos_analyzed": analyzed_count},
        })

    return {
        "ok": True,
        "saved_count": len(saved_items),
        "total_in_catalog": len(catalog["photos"]),
        "items": saved_items,
    }


def get_collection_stats(project_id: str, proj: dict, port: int = 8787) -> dict:
    """回傳目前活動照片募集進度、各主題/各小隊統計、最近上傳紀錄與上傳 URL。"""
    ev = ensure_event_info(proj)
    cat = photos_lib.load_catalog(store.catalog_file(project_id))
    ps = cat.get("photos", [])

    by_theme = {}
    by_group = {}
    by_uploader = {}

    for t in (proj.get("themes") or []):
        by_theme[t["name"]] = 0
    for g in (ev.get("expected_groups") or []):
        by_group[g] = 0

    for p in ps:
        if p.get("filename") in {proj.get("title_card_file", "片頭.png"), proj.get("outro_file", "片尾.png")}:
            continue
        th = p.get("theme")
        if th:
            by_theme[th] = by_theme.get(th, 0) + 1
        for g in (p.get("protagonists") or []):
            by_group[g] = by_group.get(g, 0) + 1
        up = p.get("uploader")
        if up:
            by_uploader[up] = by_uploader.get(up, 0) + 1

    recent = sorted(
        [p for p in ps if p.get("filename") not in {"片頭.png", "片尾.png"}],
        key=lambda x: x.get("uploaded_at") or x.get("file_mtime") or "",
        reverse=True,
    )[:16]

    return {
        "event_info": ev,
        "themes": proj.get("themes", []),
        "total_photos": len([p for p in ps if p.get("filename") not in {"片頭.png", "片尾.png"}]),
        "by_theme": by_theme,
        "by_group": by_group,
        "by_uploader": by_uploader,
        "recent_photos": [
            {
                "filename": p["filename"],
                "theme": p.get("theme"),
                "protagonists": p.get("protagonists", []),
                "uploader": p.get("uploader", "本地掃描"),
                "uploaded_at": p.get("uploaded_at") or p.get("exif_time") or "",
            }
            for p in recent
        ],
        "upload": build_upload_urls(proj, port=port),
    }
