#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/themes.py
=============
主題標籤建議：
  1. suggest_all() — 依專案「既有」的主題 + 關鍵字，對每行歌詞做關鍵字比對評分。
  2. generate_candidate_themes() — 不依賴既有主題，直接分析這首歌歌詞本身的用字，
     抓出重複出現的詞組，產生「全新」的主題標籤候選（名稱 + 關鍵字 + 範例歌詞行），
     供使用者一鍵加入主題清單，再自行改名 / 調整關鍵字。
"""

import re

# 中文常見虛詞/代名詞（用來過濾掉沒有實質意義的詞組候選）
STOPWORD_CHARS = set(
    "的了是我你他她它們在不就都也很和與而那這啊呢吧嗎呀喔哦嘛著過得地之其於以為"
    "一個有沒麼什誰哪呵唉喲欸再又還只才卻但讓把被從到給跟對向用要會能可好太更最"
    "些種樣去來上下中大小多少"
)

MIN_NGRAM_FREQ = 2
NGRAM_SIZES = (2, 3)


def suggest_theme_for_text(text: str, themes: list) -> str | None:
    """
    themes: [{"name": str, "keywords": [str, ...]}, ...]
    回傳得分最高且 > 0 的主題名稱；若無任何關鍵字命中，回傳 None。
    """
    if not text or not themes:
        return None
    best_theme = None
    best_score = 0
    for t in themes:
        score = 0
        for kw in t.get("keywords", []):
            if kw and kw in text:
                score += 1
        if score > best_score:
            best_score = score
            best_theme = t.get("name")
    return best_theme


def suggest_all(entries: list, themes: list, overwrite: bool = False) -> list:
    """
    entries: [{"idx", "start", "end", "text", "theme"}, ...]
    只會覆蓋 theme 為 None/空 的項目，除非 overwrite=True。
    回傳更新後的 entries（原地修改也會回傳同一份 list）。
    """
    for e in entries:
        if not overwrite and e.get("theme"):
            continue
        suggestion = suggest_theme_for_text(e.get("text", ""), themes)
        e["theme"] = suggestion
    return entries


def validate_themes(themes: list) -> list:
    """去除空白項目、確保每個主題都有 name 與 keywords 欄位。"""
    out = []
    seen = set()
    for t in themes or []:
        name = (t.get("name") or "").strip()
        if not name or name in seen:
            continue
        seen.add(name)
        kws = [k.strip() for k in t.get("keywords", []) if k and k.strip()]
        out.append({"name": name, "keywords": kws})
    return out


def _is_low_quality_gram(gram: str) -> bool:
    """
    過濾掉不太可能是有意義詞彙的字詞組合：
    - 2 字詞：只要有任一字是常見虛詞/代名詞，通常就是斷詞邊界切歪的殘片（例如「一起」的「一」、
      「候我」的「我」），直接排除，只留下兩字都是實詞的組合（例如「禮儀」「情緒」「淨灘」）。
    - 3 字詞：詞組較長，允許其中包含一個虛詞字（例如「大步向」），但若三字全是虛詞則排除。
    """
    if len(gram) == 2:
        return any(c in STOPWORD_CHARS for c in gram)
    return all(c in STOPWORD_CHARS for c in gram)


def generate_candidate_themes(entries: list, existing_themes: list, max_candidates: int = 6) -> list:
    """
    分析這首歌全部歌詞行的用字，抓出重複出現、且非純虛詞的詞組（2～3 字），
    依出現頻率分群，產生新的主題標籤候選。不會回傳跟現有主題名稱/關鍵字重複的候選。

    回傳: [{"name": str, "keywords": [str,...], "line_count": int, "sample_lines": [str,...]}, ...]
    """
    texts = [(e["idx"], e.get("text", "")) for e in entries if (e.get("text") or "").strip()]
    if len(texts) < 4:
        return []

    existing_names = {t.get("name") for t in existing_themes}
    existing_keywords = set()
    for t in existing_themes:
        existing_keywords.update(t.get("keywords", []))

    ngram_freq: dict = {}
    ngram_lines: dict = {}

    for idx, text in texts:
        runs = re.findall(r"[一-鿿]+", text)
        seen_in_line = set()
        for run in runs:
            for n in NGRAM_SIZES:
                for i in range(len(run) - n + 1):
                    gram = run[i:i + n]
                    if _is_low_quality_gram(gram):
                        continue
                    seen_in_line.add(gram)
        for gram in seen_in_line:
            ngram_freq[gram] = ngram_freq.get(gram, 0) + 1
            ngram_lines.setdefault(gram, set()).add(idx)

    valid_grams = {
        gram: freq for gram, freq in ngram_freq.items()
        if gram not in existing_names and gram not in existing_keywords
    }

    def _pick(pool_items, already_selected, limit):
        out = list(already_selected)
        covered_lines = set()
        for g, _ in out:
            covered_lines |= ngram_lines[g]
        for gram, freq in pool_items:
            if len(out) >= limit:
                break
            if any(g == gram for g, _ in out):
                continue
            if any(gram in g or g in gram for g, _ in out):
                continue
            lines_here = ngram_lines[gram]
            # 若這個候選涵蓋的歌詞行完全被已選候選涵蓋，代表只是同一句話裡的另一個
            # 重疊片段（沒有帶來新資訊），跳過以強迫候選分散到不同的歌詞段落。
            if freq <= 1 and lines_here <= covered_lines:
                continue
            out.append((gram, freq))
            covered_lines |= lines_here
        return out

    # 分成四個優先層級依序挑選：
    #   1) 真的重複出現的 2 字詞（中文最常見的詞長，訊號最可靠）
    #   2) 真的重複出現的 3 字詞
    #   3) 只出現一次的 2 字詞（歌詞較短、重複不足時的退而求其次）
    #   4) 只出現一次的 3 字詞
    def _first_seen(gram):
        return min(ngram_lines[gram])

    tiers = []
    for min_freq in (MIN_NGRAM_FREQ, 1):
        for size in (2, 3):
            pool = [
                (g, f) for g, f in valid_grams.items()
                if len(g) == size and (f >= MIN_NGRAM_FREQ if min_freq == MIN_NGRAM_FREQ else f < MIN_NGRAM_FREQ)
            ]
            # 頻率高優先；同頻率時依歌詞中第一次出現的順序排列（比字母序更有意義）
            pool.sort(key=lambda x: (-x[1], _first_seen(x[0])))
            tiers.append(pool)

    selected = []
    for pool in tiers:
        if len(selected) >= max_candidates:
            break
        selected = _pick(pool, selected, max_candidates)

    results = []
    for gram, freq in selected:
        line_idxs = sorted(ngram_lines[gram])
        sample_lines = [text for idx, text in texts if idx in line_idxs][:3]

        related = [
            (g2, f2) for g2, f2 in valid_grams.items()
            if g2 != gram and ngram_lines.get(g2, set()) & ngram_lines[gram]
        ]
        related.sort(key=lambda x: -x[1])
        keywords = [gram] + [g for g, _ in related[:3]]

        results.append({
            "name": gram,
            "keywords": keywords,
            "line_count": len(line_idxs),
            "sample_lines": sample_lines,
        })

    return results
