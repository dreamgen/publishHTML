#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lib/auto_analyze.py
====================
使用 Google Gemini Vision API 自動分析照片主題、品質分與適配分。

呼叫方式（由 server.py 的背景工作呼叫）：
    from lib.auto_analyze import analyze_photos_batch

功能：
- 讀取 catalog 中 analyzed=False 的照片
- 使用 Gemini Vision API 批次分析（並行）
- 寫回 catalog（theme / quality_score / fit_scores / description）
- 透過 JobContext 回報進度與 log
"""

import json
import os
import base64
import threading
import time
from pathlib import Path
from typing import Optional

# ── Gemini SDK (lazy import，未安裝時給出友善提示) ──────────────────────
def _import_genai():
    try:
        import google.generativeai as genai
        return genai
    except ImportError:
        return None


# ═══════════════════════════════════════════════════════════════
# 核心分析函式
# ═══════════════════════════════════════════════════════════════

ANALYZE_PROMPT_TEMPLATE = """你是一個專業的照片分類助理。請分析這張照片，並回傳 **純 JSON**（不要 markdown 包裝）。

可用的主題標籤（themes）：
{themes_list}

各主題含義：
{themes_desc}

請回傳以下 JSON 格式：
{{
  "theme": "最適合的主題（從上面清單選一個）",
  "description": "一句話描述照片內容（繁體中文，20字以內）",
  "quality_score": 照片品質分數（0.0–10.0，考量清晰度、構圖、情感豐富度）,
  "focus_x": 主體/人物臉部水平重心座標（0.0=最左, 0.5=正中, 1.0=最右）,
  "focus_y": 主體/人物笑臉垂直重心座標（0.0=最上, 0.35=中上人臉區, 1.0=最下，供運鏡拉近時對準臉部不切頭頂）,
  "protagonists": ["畫面中出現的主要人物或小隊特徵標籤（如：孩童、家長、第一小隊、老師、全員合照）"],
  "fit_scores": {{
{fit_scores_template}
  }}
}}

評分標準（fit_scores）：
- 10.0：完全符合該主題，照片主角與主題直接相關
- 7.0–9.9：相關但不完美
- 4.0–6.9：勉強相關或可多次利用
- 1.0–3.9：幾乎不相關
- 0.0：完全不適合

只回傳 JSON，不要其他文字。"""


def build_prompt(themes: list[dict]) -> str:
    """根據專案主題清單建構分析 prompt。"""
    names = [t["name"] for t in themes]
    themes_list = "\n".join(f"- {n}" for n in names)
    themes_desc = "\n".join(
        f"- {t['name']}：關鍵字 {', '.join(t.get('keywords', []) or ['（未設定）'])}"
        for t in themes
    )
    fit_scores_template = "\n".join(
        f'    "{n}": 分數'
        for n in names
    )
    return ANALYZE_PROMPT_TEMPLATE.format(
        themes_list=themes_list,
        themes_desc=themes_desc,
        fit_scores_template=fit_scores_template,
    )


def analyze_single_photo(
    genai,
    model_name: str,
    photo_path: Path,
    prompt: str,
    valid_themes: list[str],
    retries: int = 2,
) -> Optional[dict]:
    """
    用 Gemini Vision 分析單張照片。
    成功時回傳分析結果 dict，失敗時回傳 None。
    """
    for attempt in range(retries + 1):
        try:
            model = genai.GenerativeModel(model_name)

            # 讀取圖片並用 base64 傳送
            img_bytes = photo_path.read_bytes()
            suffix = photo_path.suffix.lower()
            mime = {
                ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".png": "image/png", ".heic": "image/heic",
                ".heif": "image/heif", ".gif": "image/gif",
                ".webp": "image/webp",
            }.get(suffix, "image/jpeg")

            response = model.generate_content([
                {"mime_type": mime, "data": img_bytes},
                prompt,
            ])
            raw = response.text.strip()

            # 清除可能的 markdown 包裝
            if raw.startswith("```"):
                lines = raw.splitlines()
                raw = "\n".join(
                    l for l in lines if not l.startswith("```")
                ).strip()

            result = json.loads(raw)

            # 驗證並修正 theme
            theme = result.get("theme", "")
            if theme not in valid_themes:
                # 嘗試模糊匹配
                lower_theme = theme.lower()
                matched = next(
                    (t for t in valid_themes if t.lower() == lower_theme), None
                )
                result["theme"] = matched or valid_themes[0]

            # 確保所有主題都有分數
            fs = result.get("fit_scores", {})
            for t in valid_themes:
                if t not in fs:
                    fs[t] = 2.0
                else:
                    fs[t] = round(float(fs[t]), 1)
            result["fit_scores"] = fs

            result["quality_score"] = round(float(result.get("quality_score", 7.0)), 1)
            if "focus_x" in result and result["focus_x"] is not None:
                try:
                    result["focus_x"] = round(max(0.1, min(0.9, float(result["focus_x"]))), 3)
                except (TypeError, ValueError):
                    result["focus_x"] = None
            if "focus_y" in result and result["focus_y"] is not None:
                try:
                    result["focus_y"] = round(max(0.1, min(0.85, float(result["focus_y"]))), 3)
                except (TypeError, ValueError):
                    result["focus_y"] = None
            return result

        except json.JSONDecodeError as e:
            if attempt < retries:
                time.sleep(1)
                continue
            return {"error": f"JSON 解析失敗：{e}"}
        except Exception as e:
            err_str = str(e)
            if "quota" in err_str.lower() or "rate" in err_str.lower():
                # 配額限制：等待後重試
                wait = 10 * (attempt + 1)
                time.sleep(wait)
                continue
            if attempt < retries:
                time.sleep(2)
                continue
            return {"error": str(e)}

    return None


# ═══════════════════════════════════════════════════════════════
# 批次分析（背景工作主函式）
# ═══════════════════════════════════════════════════════════════

def analyze_photos_batch(
    ctx,                      # JobContext（來自 jobs.py）
    catalog_path: Path,
    photos_dir: Path,
    themes: list[dict],
    api_key: str,
    model_name: str = os.environ.get("MV_GEMINI_MODEL", "gemini-2.5-flash"),
    max_workers: int = 3,
    filenames_filter: list[str] = None,
):
    """
    批次分析 catalog 中所有 analyzed=False 的照片。
    - ctx: JobContext（用於 log / progress 回報）
    - filenames_filter: 若指定，只分析這些檔名（否則分析全部待分析的）
    """
    genai = _import_genai()
    if genai is None:
        ctx.log("❌ 找不到 google-generativeai 套件，請執行：pip install google-generativeai")
        raise RuntimeError("缺少 google-generativeai 套件")

    if not api_key:
        ctx.log("❌ 未設定 Gemini API Key，請在「⚙️ 專案設定」填寫。")
        raise RuntimeError("未設定 Gemini API Key")

    genai.configure(api_key=api_key)

    # 讀取 catalog
    from lib.photos import load_catalog, save_catalog, normalize_protagonists
    catalog = load_catalog(catalog_path)
    photos = catalog["photos"]

    # 篩選待分析的照片
    pending = [
        p for p in photos
        if not p.get("analyzed")
        and (filenames_filter is None or p["filename"] in set(filenames_filter))
    ]

    if not pending:
        ctx.log("✅ 所有照片已分析完成，無待分析照片。")
        ctx.set_result({"analyzed": 0, "skipped": 0})
        return

    valid_themes = [t["name"] for t in themes]
    prompt = build_prompt(themes)

    ctx.log(f"🤖 Gemini Vision 自動分析啟動")
    ctx.log(f"   模型：{model_name}")
    ctx.log(f"   待分析：{len(pending)} 張")
    ctx.log(f"   主題：{', '.join(valid_themes)}")
    ctx.log(f"   並行數：{max_workers}")
    ctx.log("─" * 50)
    ctx.progress(0, len(pending), "初始化")

    results = {}
    lock = threading.Lock()
    errors = []

    def worker(photo_entry):
        if ctx.is_cancelled():
            return

        fname = photo_entry["filename"]
        abs_path = photo_entry.get("abs_path")
        photo_path = Path(abs_path) if abs_path else photos_dir / fname

        # 優先取用 640px 輕量縮圖，大幅提升 API 上傳速度與分析效率
        cache_dir = catalog_path.parent / ".cache" / "thumbs"
        thumb = photos_lib.get_thumbnail(fname, catalog_path, photos_dir, cache_dir, max_w=640)
        target_path = thumb if (thumb and thumb.exists()) else photo_path

        if not target_path.exists():
            with lock:
                errors.append(fname)
                ctx.log(f"  ⚠️  找不到檔案：{fname}")
            return

        result = analyze_single_photo(genai, model_name, target_path, prompt, valid_themes)
        with lock:
            if result and "error" not in result:
                results[fname] = result
                ctx.log(
                    f"  ✅ {fname[:30]:<30} "
                    f"[{result['theme']:<12}] "
                    f"Q={result['quality_score']:.1f}"
                )
            else:
                errors.append(fname)
                err_msg = (result or {}).get("error", "未知錯誤")
                ctx.log(f"  ❌ {fname[:30]:<30} 失敗：{err_msg}")

            done = len(results) + len(errors)
            ctx.progress(done, len(pending), "分析中")

    # 用 ThreadPoolExecutor 並行分析
    from concurrent.futures import ThreadPoolExecutor, as_completed
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(worker, p): p for p in pending}
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                ctx.log(f"  ❌ 工作執行緒異常：{e}")

    # 將結果寫回 catalog
    ctx.log("─" * 50)
    if ctx.is_cancelled():
        ctx.log("🛑 收到取消請求，正在儲存已完成的進度...")
    else:
        ctx.log("📝 寫入分析結果至 catalog…")

    updated = 0
    catalog = load_catalog(catalog_path)  # 重新讀取以避免並發問題
    photo_index = {p["filename"]: p for p in catalog["photos"]}

    for fname, res in results.items():
        entry = photo_index.get(fname)
        if not entry:
            continue
        entry["theme"] = res["theme"]
        entry["description"] = res.get("description", "")
        entry["quality_score"] = res["quality_score"]
        entry["fit_scores"] = res["fit_scores"]
        if res.get("focus_x") is not None:
            entry["focus_x"] = res["focus_x"]
        if res.get("focus_y") is not None:
            entry["focus_y"] = res["focus_y"]
        if res.get("protagonists"):
            entry["protagonists"] = normalize_protagonists(res["protagonists"])
        entry["analyzed"] = True
        entry["auto_tagged"] = False
        entry["analyzed_by"] = f"gemini/{model_name}"
        updated += 1

    save_catalog(catalog_path, catalog)

    ctx.progress(len(pending), len(pending), "完成")
    ctx.log(f"\n🎉 分析完成！成功 {updated} 張，失敗 {len(errors)} 張。")
    if errors:
        ctx.log(f"   失敗檔案：{', '.join(errors[:10])}")

    ctx.set_result({
        "analyzed": updated,
        "failed": len(errors),
        "total_pending": len(pending),
    })
