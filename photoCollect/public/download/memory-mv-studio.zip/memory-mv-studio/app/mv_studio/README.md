# MV Studio — 本地網頁製作工具（多專案版）

用網頁介面取代「手改好幾支 Python 檔案裡的寫死路徑」這件事。每首歌是一個獨立專案，
彼此的素材路徑、主題標籤、時間軸、照片標記完全隔離，可以同時管理好幾首歌的製作進度。

## 啟動方式

```bash
cd <MV Studio 安裝資料夾>
./venv/bin/python3 mv_studio/server.py
```

開啟瀏覽器：http://localhost:8787　（不需要另外安裝套件，沿用專案 venv 裡已有的
Pillow / Whisper / numpy / pypinyin）

## 資料夾結構

```
mv_studio/
  server.py           -- HTTP 路由
  lib/                -- 後端邏輯模組
    store.py           專案登錄 / project.json 讀寫
    themes.py          主題標籤關鍵字建議
    lyrics.py          SRT 解析、時間軸建置
    photos.py          照片 catalog 掃描/標記/縮圖
    subagent_batch.py  CLI Subagent 多代理批次任務生成、640px 縮圖快取與 JSON 結果匯入
    manifest.py        時間軸照片分配（三優先策略）
    jobs.py            背景工作追蹤（歌詞對齊 / 渲染都跑很久）
    render.py          渲染引擎（Ken Burns + 硬字幕 + FFmpeg）
  static/             -- 前端（純 vanilla JS，hash router）
  projects/
    index.json         所有專案的登錄清單
    <project_id>/
      project.json      這個專案的設定
      lyrics.txt         貼上的歌詞文字
      generated.srt      對齊產生的字幕
      lyrics_map.json    每行歌詞 + 指派的主題
      content_plan.json  時間軸規劃
      photo_catalog.json 照片標記結果
      ordered_photos.json / ordered_photos_detail.json
      jobs/*.json        背景工作狀態
      output/*.mp4       渲染輸出
```

## 使用流程（六個分頁）

1. **專案設定**：填音樂檔路徑、照片資料夾路徑、片頭/片尾素材與時長、時間槽切分參數。
2. **歌詞對齊**：貼上歌詞文字 → 選 Whisper 模型大小 → 開始對齊（背景執行，會跑數十秒到數分鐘，
   可以切去別的分頁，回來再看進度）→ 完成後可預覽/微調每一句字幕的起訖時間與文字。
3. **內容規劃**：
   - 新專案的主題標籤預設是「空白」的（不會塞入跟這首歌無關的範例分類）。可以自己打、
     按「載入參考範例（親子活動類歌曲）」套用舊專案的樣板再修改，或用下一步的分析功能。
   - 按「分析歌詞產生建議」：純本地文字分析（找出歌詞中重複出現、排除掉常見虛詞/代名詞的
     詞組），列出候選主題名稱＋關鍵字＋範例歌詞行，覺得合適就直接改名/調關鍵字後一鍵加入。
     這是關鍵字比對層級的分析，不是真正的語意理解，建議產生後自己看一遍再調整；
     若想要更貼切的分類，也可以在對話中請 Claude 讀完整首歌詞後幫忙設計，直接寫入
     `project.json` 的 `themes` 欄位。
   - 對每一行歌詞指派主題（可以按「依關鍵字自動建議」用目前的主題標籤跑一輪比對，再手動微調）。
   - 按「建立時間軸」產生 `content_plan.json`。
4. **照片分析（雙模式 AI 視覺分析中樞）**：
   - **🚀 模式 1：Agent 多代理視覺分析（Subagent 模式・免 API Key・推薦）**：
     - 點擊「**⚡ 1. 準備 Subagent 批次任務**」：自動掃描新照片、產生 `640px` 輕量快取縮圖，並依據專案自訂的主題標籤將待分析照片切分為多個 Subagent 分組（寫入 `subagent_task.json`）。
     - 點擊「**📋 一鍵複製對話指令**」貼給對話中的 Agent（Antigravity / Claude），或直接在終端機執行：
       ```bash
       ./venv/bin/python3 analyze_batch_photos.py scan --project <project_id>
       ./venv/bin/python3 analyze_batch_photos.py import --project <project_id> --input /tmp/sub1.json
       ```
     - **自動即時同步**：當 CLI 匯入完成時，網頁端每 3 秒自動偵測 `photo_catalog.json` 變更並即時刷新照片網格與主題覆蓋率；亦支援在網頁上直接貼上或上傳 `.json` 結果檔。
   - **🔑 模式 2：Gemini API Key 直接分析**：使用 Google AI Studio API Key 於背景執行緒並行呼叫 Gemini Vision 模型分析。
5. **照片分配**：整條時間軸用卡片呈現，點卡片可換照片、改時長，
   或按「重新自動分配」用三優先演算法重新跑一次（會覆蓋手動調整）。
6. **開始渲染**：一鍵觸發渲染，進度條 + log 即時更新，完成後可直接在網頁預覽播放或下載。

## 重要限制 / 建議

- Claude 要能幫忙「視覺分析」照片或「讀歌詞設計主題」，對應的檔案／資料夾必須在目前對話
  session 存取得到的路徑內（例如放進這個 MV 專案資料夾底下），使用者電腦上未連結的路徑
  （如 `~/Downloads`）Claude 讀不到，但網頁工具本身（在使用者自己的終端機執行）不受此限制。
- 歌詞對齊使用 Whisper，第一次執行會下載模型、且 CPU 轉錄有一定耗時，模型愈大愈準但愈慢，
  建議先用 `medium` 試跑。
- 渲染沿用原本 `make_parent_child_mv.py` 的畫面效果（Ken Burns 縮放平移、圓體硬字幕、
  淡入淡出），序列處理每個片段以避免 Apple Silicon 硬體編碼器並發上限問題，合併時
  優先用 VideoToolbox 硬體加速，失敗會自動退回 CPU 軟體編碼。
- 舊的單一寫死路徑腳本（`prepare_content_plan.py`、`build_photo_manifest.py`、
  `make_parent_child_mv.py` 等）都還在專案根目錄，不受影響，可以繼續用 CLI 方式操作；
  這個網頁工具是另一套資料格式（每個專案獨立資料夾），兩者不共用同一份 JSON。
