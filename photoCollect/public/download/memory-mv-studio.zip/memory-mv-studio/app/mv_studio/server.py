#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mv_studio/server.py
====================
本地端 MV 製作輔助工具 — 多專案版本。

不需安裝任何額外套件（僅使用 Python 標準庫 + 專案既有的 Pillow），
每首歌是一個獨立「專案」，各自的素材路徑、主題標籤、時間軸、照片標記都互相隔離。

啟動方式：
    ./venv/bin/python3 mv_studio/server.py
    然後開啟瀏覽器 http://localhost:8787
"""

import sys

# Windows 終端機預設可能是 Big5/cp950：統一輸出 UTF-8，避免中文／emoji 亂碼或 UnicodeEncodeError
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import os
import json
import argparse
import mimetypes
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

STUDIO_DIR = Path(__file__).resolve().parent
ROOT = STUDIO_DIR.parent
STATIC_DIR = STUDIO_DIR / "static"

sys.path.insert(0, str(STUDIO_DIR))
from lib import store, themes as themes_lib, lyrics as lyrics_lib, photos as photos_lib, manifest as manifest_lib, jobs as jobs_lib, render as render_lib, subagent_batch as subagent_lib, beats as beats_lib, fs_browser as fs_lib, event_prep as event_lib, gphotos as gphotos_lib  # noqa: E402

SERVER_PORT = 8787

# 安全設定：非本機連線只能存取「手機上傳」相關路徑，避免管理介面／檔案瀏覽 API 暴露在區網或公網
MAX_UPLOAD_BYTES = int(os.environ.get("MV_MAX_UPLOAD_MB", "60")) * 1024 * 1024
UPLOAD_EXTS = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp", ".gif"}
_REMOTE_ALLOWED_PREFIXES = ("/upload/", "/api/upload/", "/thumb/")


def _is_local_client(handler) -> bool:
    # 經 Cloudflare Tunnel / ngrok 等反向代理進來的請求，來源 IP 也會是 127.0.0.1，
    # 因此只要帶有代理標頭就一律視為外部連線
    for h in ("CF-Connecting-IP", "X-Forwarded-For", "X-Real-IP", "Forwarded", "Ngrok-Trace-Id"):
        if handler.headers.get(h):
            return False
    ip = (handler.client_address or ("",))[0]
    return ip in ("127.0.0.1", "::1", "localhost") or ip.startswith("::ffff:127.")


def _remote_path_allowed(path: str) -> bool:
    return any(path.startswith(pfx) for pfx in _REMOTE_ALLOWED_PREFIXES)
try:
    from lib import auto_analyze as auto_analyze_lib
except ImportError:
    auto_analyze_lib = None


def venv_python() -> str:
    for cand in (ROOT / "venv" / "bin" / "python3", ROOT / "venv" / "bin" / "python",
                 ROOT / "venv" / "Scripts" / "python.exe"):
        if cand.exists():
            return str(cand)
    return sys.executable


# ═══════════════════════════════════════════════════════════════
# 🔧 專案輔助
# ═══════════════════════════════════════════════════════════════

def photos_dir_of(proj: dict) -> Path:
    p = proj.get("photos_dir") or str(store.project_dir(proj["id"]) / "photos")
    return Path(p)


def cache_dir_of(project_id: str) -> Path:
    return store.project_dir(project_id) / ".cache" / "thumbs"


def load_lyrics_map(project_id: str, proj: dict) -> dict:
    """讀取（或從 SRT 初始化）逐行歌詞 + 主題標籤。"""
    lm_path = store.lyrics_map_file(project_id)
    srt_path = store.resolved_srt_file(proj)

    srt_entries = lyrics_lib.parse_srt(srt_path)
    srt_by_idx = {e["idx"]: e for e in srt_entries}

    if lm_path.exists():
        saved = json.loads(lm_path.read_text(encoding="utf-8"))
        saved_by_idx = {e["idx"]: e for e in saved.get("entries", [])}
    else:
        saved_by_idx = {}

    merged = []
    for idx, e in srt_by_idx.items():
        prev = saved_by_idx.get(idx, {})
        merged.append({
            "idx": idx,
            "start": e["start"],
            "end": e["end"],
            "text": e["text"],
            "theme": prev.get("theme"),
        })
    merged.sort(key=lambda e: e["idx"])
    return {"entries": merged}


def save_lyrics_map(project_id: str, data: dict):
    store.lyrics_map_file(project_id).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# ═══════════════════════════════════════════════════════════════
# 🌐 HTTP Handler
# ═══════════════════════════════════════════════════════════════

class Handler(BaseHTTPRequestHandler):
    server_version = "MVStudio/2.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("[mv_studio] " + (fmt % args) + "\n")

    # ---- 共用工具 ----
    def _send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _err(self, message, code=400):
        self._send_json({"error": message}, code=code)

    def _send_file(self, path: Path, content_type=None):
        if not path.exists():
            self._err(f"找不到檔案：{path.name}", 404)
            return
        ctype = content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def _send_file_ranged(self, path: Path, content_type: str):
        """支援 HTTP Range 的檔案傳輸（給 <video> 預覽拖曳進度用）。"""
        if not path.exists():
            self._err("找不到檔案", 404)
            return
        file_size = path.stat().st_size
        range_header = self.headers.get("Range")
        if not range_header:
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(file_size))
            self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            with open(path, "rb") as f:
                shutil_copy(f, self.wfile)
            return

        try:
            units, rng = range_header.split("=")
            start_s, end_s = rng.split("-")
            start = int(start_s) if start_s else 0
            end = int(end_s) if end_s else file_size - 1
            end = min(end, file_size - 1)
        except Exception:
            start, end = 0, file_size - 1

        length = end - start + 1
        self.send_response(206)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Range", f"bytes {start}-{end}/{file_size}")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            remaining = length
            chunk = 65536
            while remaining > 0:
                data = f.read(min(chunk, remaining))
                if not data:
                    break
                self.wfile.write(data)
                remaining -= len(data)

    def _read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    # ---- 路由分派 ----
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if not _is_local_client(self) and not _remote_path_allowed(path):
            return self._err("此功能僅限在執行 MV Studio 的電腦上操作", 403)
        qs = parse_qs(parsed.query)
        try:
            if path in ("/", ""):
                return self._send_file(STATIC_DIR / "index.html", "text/html; charset=utf-8")
            if path == "/app.js":
                return self._send_file(STATIC_DIR / "app.js", "application/javascript; charset=utf-8")
            if path == "/style.css":
                return self._send_file(STATIC_DIR / "style.css", "text/css; charset=utf-8")

            if path == "/api/projects":
                return self._send_json({"projects": store.list_projects()})

            if path == "/api/fs/list":
                target_path = (qs.get("path") or [None])[0]
                mode = (qs.get("mode") or ["all"])[0]
                show_all = (qs.get("show_all") or ["0"])[0] in ("1", "true", "yes")
                pid = (qs.get("project_id") or [None])[0]
                extra_shortcuts = []
                if pid:
                    try:
                        p = store.get_project(pid)
                        if p.get("photos_dir"):
                            extra_shortcuts.append({"label": "📸 目前照片資料夾", "path": p["photos_dir"], "icon": "📸"})
                        if p.get("music_file"):
                            extra_shortcuts.append({"label": "🎵 目前音樂所在目錄", "path": str(Path(p["music_file"]).parent), "icon": "🎵"})
                    except Exception:
                        pass
                res = fs_lib.list_directory(
                    target_path=target_path,
                    mode=mode,
                    show_all_files=show_all,
                    extra_shortcuts=extra_shortcuts,
                )
                return self._send_json(res)

            parts = [p for p in path.split("/") if p]
            # 攝影師 / 學員手機上傳專屬頁面：/upload/<token>
            if len(parts) == 2 and parts[0] == "upload":
                return self._send_file(STATIC_DIR / "upload.html", "text/html; charset=utf-8")

            # 取得上傳頁面活動資訊與進度：/api/upload/<token>/info
            if len(parts) == 4 and parts[0] == "api" and parts[1] == "upload" and parts[3] == "info":
                pid, proj = event_lib.find_project_by_upload_token(unquote(parts[2]))
                if not pid or not proj:
                    return self._err("找不到此活動上傳代碼，請向主辦方確認最新連結", 404)
                stats = event_lib.get_collection_stats(pid, proj, port=SERVER_PORT)
                return self._send_json({"project_id": pid, **stats})

            # /api/projects/<id>/...
            if len(parts) >= 3 and parts[0] == "api" and parts[1] == "projects":
                project_id = parts[2]
                sub = "/".join(parts[3:])
                return self.route_project_get(project_id, sub, qs)

            if len(parts) >= 3 and parts[0] == "thumb":
                project_id, filename = parts[1], unquote("/".join(parts[2:]))
                return self.serve_thumb(project_id, filename)
            if len(parts) >= 3 and parts[0] == "image":
                project_id, filename = parts[1], unquote("/".join(parts[2:]))
                return self.serve_image(project_id, filename)

            return self._err("Not found", 404)
        except FileNotFoundError as e:
            try: self._err(str(e), 404)
            except: pass
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try: self._err(str(e), 500)
            except: pass

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if not _is_local_client(self) and not _remote_path_allowed(path):
            return self._err("此功能僅限在執行 MV Studio 的電腦上操作", 403)
        qs = parse_qs(parsed.query)
        try:
            parts = [p for p in path.split("/") if p]
            # 處理手機/網頁端二進位單張或多張照片串流上傳：/api/upload/<token>/file
            if len(parts) == 4 and parts[0] == "api" and parts[1] == "upload" and parts[3] == "file":
                token = unquote(parts[2])
                pid, proj = event_lib.find_project_by_upload_token(token)
                if not pid or not proj:
                    return self._err("無效的活動上傳代碼", 404)
                length = int(self.headers.get("Content-Length", 0))
                if length <= 0:
                    return self._err("上傳內容為空")
                if length > MAX_UPLOAD_BYTES:
                    return self._err(f"單張照片超過上限 {MAX_UPLOAD_BYTES // (1024 * 1024)} MB", 413)
                fname = Path((qs.get("filename") or ["photo.jpg"])[0]).name or "photo.jpg"
                if Path(fname).suffix.lower() not in UPLOAD_EXTS:
                    return self._err("只接受照片檔（JPG / PNG / HEIC / WEBP / GIF）", 415)
                raw_data = self.rfile.read(length)
                uploader = (qs.get("uploader") or ["熱心夥伴"])[0]
                theme = (qs.get("theme") or ["auto"])[0]
                prots = (qs.get("protagonists") or [""])[0]
                note = (qs.get("note") or [""])[0]
                res = event_lib.handle_uploaded_photos(
                    project_id=pid,
                    proj=proj,
                    uploaded_files=[{"filename": fname, "data": raw_data}],
                    uploader=uploader,
                    selected_theme=theme,
                    protagonists_raw=prots,
                    note=note,
                )
                return self._send_json(res)

            body = self._read_json_body()
            if path == "/api/projects":
                proj = store.create_project(body.get("name", "未命名專案"), body.get("song_title", ""))
                return self._send_json(proj)

            if path == "/api/fs/native_pick":
                res = fs_lib.native_pick_path(
                    mode=body.get("mode", "dir"),
                    initial_dir=body.get("initial_dir"),
                    default_name=body.get("default_name"),
                )
                return self._send_json(res)

            parts = [p for p in path.split("/") if p]
            if len(parts) >= 3 and parts[0] == "api" and parts[1] == "projects":
                project_id = parts[2]
                sub = "/".join(parts[3:])
                return self.route_project_post(project_id, sub, body)

            return self._err("Not found", 404)
        except FileNotFoundError as e:
            try: self._err(str(e), 404)
            except: pass
        except (ValueError, KeyError) as e:
            try: self._err(str(e), 400)
            except: pass
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try: self._err(str(e), 500)
            except: pass

    def do_DELETE(self):
        parsed = urlparse(self.path)
        if not _is_local_client(self):
            return self._err("此功能僅限在執行 MV Studio 的電腦上操作", 403)
        parts = [p for p in parsed.path.split("/") if p]
        try:
            if len(parts) == 3 and parts[0] == "api" and parts[1] == "projects":
                store.archive_project(parts[2])
                return self._send_json({"ok": True})
            self._err("Not found", 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try: self._err(str(e), 500)
            except: pass

    # ---- 靜態媒體 ----
    def serve_thumb(self, project_id, filename):
        proj = store.get_project(project_id)
        thumb = photos_lib.get_thumbnail(
            filename, store.catalog_file(project_id), photos_dir_of(proj), cache_dir_of(project_id)
        )
        if thumb:
            self._send_file(thumb, "image/jpeg")
        else:
            self._err("無法產生縮圖 / 找不到照片", 404)

    def serve_image(self, project_id, filename):
        proj = store.get_project(project_id)
        src = photos_lib.resolve_photo_path(filename, store.catalog_file(project_id), photos_dir_of(proj))
        if src and src.exists():
            self._send_file(src)
        else:
            # 支援未下載的遠端照片（如 Google 相簿）：提供 1280px 高清預覽快取
            preview = photos_lib.get_thumbnail(
                filename, store.catalog_file(project_id), photos_dir_of(proj), cache_dir_of(project_id), max_w=1280
            )
            if preview and preview.exists():
                self._send_file(preview, "image/jpeg")
            else:
                self._err("找不到照片", 404)

    # ---- /api/projects/<id>/... GET ----
    def route_project_get(self, project_id, sub, qs):
        proj = store.get_project(project_id)

        if sub == "":
            return self._send_json(proj)

        if sub == "event":
            return self._send_json(event_lib.get_collection_stats(project_id, proj, port=SERVER_PORT))

        if sub == "lyrics/text":
            lt = proj.get("lyrics_text_file")
            text = Path(lt).read_text(encoding="utf-8") if lt and Path(lt).exists() else ""
            return self._send_json({"text": text})

        if sub == "lyrics/align/status":
            return self._send_json(jobs_lib.read_status(store.job_file(project_id, "align")))

        if sub == "lyrics/srt":
            entries = lyrics_lib.parse_srt(store.resolved_srt_file(proj))
            return self._send_json({"entries": entries})

        if sub == "lyrics_map":
            return self._send_json({**load_lyrics_map(project_id, proj), "themes": proj.get("themes", [])})

        if sub == "themes":
            return self._send_json({"themes": proj.get("themes", []), "template": store.DEFAULT_THEME_TEMPLATE})

        if sub == "themes/candidates":
            data = load_lyrics_map(project_id, proj)
            candidates = themes_lib.generate_candidate_themes(data["entries"], proj.get("themes", []))
            return self._send_json({"candidates": candidates})

        if sub == "content_plan":
            cp_path = store.content_plan_file(project_id)
            if not cp_path.exists():
                return self._err("尚未建立內容規劃，請先在「內容規劃」分頁執行建立時間軸", 404)
            return self._send_json(json.loads(cp_path.read_text(encoding="utf-8")))

        if sub == "photos":
            return self.api_get_photos(project_id, proj)

        if sub == "photos/picker":
            theme = (qs.get("theme") or [None])[0]
            return self.api_get_picker(project_id, proj, theme)

        if sub == "photos/auto_analyze/status":
            return self._send_json(jobs_lib.read_status(store.job_file(project_id, "auto_analyze")))

        if sub == "photos/subagent/status":
            return self._send_json(subagent_lib.get_subagent_status(project_id, proj))

        if sub == "photos/gphotos/status":
            return self._send_json(gphotos_lib.get_selected_download_status(project_id))

        if sub == "manifest":
            return self.api_get_manifest(project_id, proj)

        if sub == "render/status":
            return self._send_json(jobs_lib.read_status(store.job_file(project_id, "render")))

        if sub == "render/preview":
            out = store.resolved_output_file(proj)
            return self._send_file_ranged(out, "video/mp4")

        if sub == "render/download":
            out = store.resolved_output_file(proj)
            if not out.exists():
                return self._err("尚未渲染出影片", 404)
            from urllib.parse import quote as urlquote
            ascii_name = out.name.encode("ascii", "ignore").decode("ascii") or "output.mp4"
            utf8_name  = urlquote(out.name, safe="")          # RFC 5987
            disposition = (
                f'attachment; filename="{ascii_name}"; '
                f"filename*=UTF-8''{utf8_name}"
            )
            self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Content-Disposition", disposition)
            self.send_header("Content-Length", str(out.stat().st_size))
            self.end_headers()
            with open(out, "rb") as f:
                shutil_copy(f, self.wfile)
            return

        return self._err("Not found", 404)

    # ---- /api/projects/<id>/... POST ----
    def route_project_post(self, project_id, sub, body):
        proj = store.get_project(project_id)

        if sub == "":
            updated = store.update_project(project_id, body)
            return self._send_json(updated)

        if sub == "event/prepare":
            res = event_lib.prepare_collection_environment(
                project_id=project_id,
                proj=proj,
                event_patch=body.get("event_info"),
                sync_themes=bool(body.get("sync_themes", True)),
                generate_cards=bool(body.get("generate_cards", True)),
                port=SERVER_PORT,
            )
            return self._send_json(res)

        if sub == "event/extract_doc":
            doc_path = (body.get("path") or "").strip()
            if not doc_path:
                return self._err("請提供檔案路徑")
            try:
                txt = event_lib.extract_document_text(doc_path)
            except RuntimeError as e:   # 例如 .doc 在非 macOS、PDF 沒裝 pypdf：訊息已寫明怎麼辦
                return self._err(str(e), 400)
            return self._send_json({"ok": True, "text": txt, "filename": Path(doc_path).name})

        if sub == "lyrics/text":
            path = store.project_dir(project_id) / "lyrics.txt"
            path.write_text(body.get("text", ""), encoding="utf-8")
            store.update_project(project_id, {"lyrics_text_file": str(path)})
            return self._send_json({"ok": True, "lyrics_text_file": str(path)})

        if sub == "lyrics/align/start":
            return self.start_align_job(project_id, proj, body)

        if sub == "lyrics/srt":
            entries = body.get("entries", [])
            lyrics_lib.write_srt(entries, store.resolved_srt_file(proj))
            return self._send_json({"ok": True, "count": len(entries)})

        if sub == "lyrics_map/assign":
            return self.api_lyrics_map_assign(project_id, proj, body)

        if sub == "lyrics_map/suggest":
            return self.api_lyrics_map_suggest(project_id, proj, body)

        if sub == "themes":
            valid = themes_lib.validate_themes(body.get("themes", []))
            store.update_project(project_id, {"themes": valid})
            return self._send_json({"themes": valid})

        if sub == "themes/template":
            tmpl = [dict(t) for t in store.DEFAULT_THEME_TEMPLATE]
            store.update_project(project_id, {"themes": tmpl})
            return self._send_json({"themes": tmpl})

        if sub == "themes/candidates/add":
            name = (body.get("name") or "").strip()
            if not name:
                return self._err("需要主題名稱")
            keywords = [k.strip() for k in body.get("keywords", []) if k and k.strip()]
            themes = list(proj.get("themes", []))
            if any(t["name"] == name for t in themes):
                return self._err(f"主題「{name}」已存在")
            themes.append({"name": name, "keywords": keywords})
            valid = themes_lib.validate_themes(themes)
            store.update_project(project_id, {"themes": valid})
            return self._send_json({"themes": valid})

        if sub == "content_plan/build":
            return self.api_build_content_plan(project_id, proj, body)

        if sub == "photos/scan":
            return self.api_photos_scan(project_id, proj)

        if sub == "photos/detect_focus":
            return self.api_photos_detect_focus(project_id, proj, body)

        if sub == "photos/update":
            return self.api_photos_update(project_id, proj, body)

        if sub == "photos/auto_analyze/start":
            return self.api_start_auto_analyze(project_id, proj, body)

        if sub == "photos/auto_analyze/cancel":
            return self.api_cancel_auto_analyze(project_id, proj)

        if sub == "photos/subagent/prepare":
            return self.api_subagent_prepare(project_id, proj, body)

        if sub == "photos/subagent/import":
            return self.api_subagent_import(project_id, proj, body)

        if sub == "photos/gphotos/import":
            url = (body.get("url") or "").strip()
            if not url:
                return self._err("缺少 Google 相簿分享網址 (url)")
            try:
                res = gphotos_lib.import_gphotos_to_catalog(project_id, url)
                return self._send_json(res)
            except Exception as e:
                return self._err(str(e), 500)

        if sub == "photos/gphotos/download_selected":
            try:
                res = gphotos_lib.download_selected_photos(project_id)
                return self._send_json(res)
            except Exception as e:
                return self._err(str(e), 500)

        if sub == "manifest/assign":
            return self.api_manifest_assign(project_id, proj, body)

        if sub == "manifest/duration":
            return self.api_manifest_duration(project_id, proj, body)

        if sub == "manifest/autobuild":
            return self.api_manifest_autobuild(project_id, proj, body)

        if sub == "render/start":
            return self.start_render_job(project_id, proj)

        return self._err("Not found", 404)

    # ═══════════════════════════════════════════════════════════
    # 歌詞對齊
    # ═══════════════════════════════════════════════════════════

    def start_align_job(self, project_id, proj, body):
        music_file = proj.get("music_file")
        lyrics_file = proj.get("lyrics_text_file")
        if not music_file or not Path(music_file).exists():
            return self._err("請先在專案設定填寫有效的音樂檔路徑（music_file）")
        if not lyrics_file or not Path(lyrics_file).exists():
            return self._err("請先在歌詞對齊分頁貼上歌詞文字（會存成 lyrics.txt）")

        model = body.get("model", "medium")
        pdir = store.project_dir(project_id)
        script = ROOT / "align_lyrics_dp.py"
        cmd = [venv_python(), str(script), str(music_file), str(lyrics_file), "--model", model]

        def target(ctx):
            jobs_lib.run_subprocess_streamed(ctx, cmd, cwd=pdir)
            base_name = Path(music_file).stem
            generated = pdir / f"{base_name}_generated.srt"
            if not generated.exists():
                raise RuntimeError("對齊完成，但找不到產生的 SRT 檔案")
            target_srt = store.resolved_srt_file(proj)
            generated.replace(target_srt)
            store.update_project(project_id, {
                "srt_file": str(target_srt),
                "status": {**proj.get("status", {}), "lyrics_aligned": True},
            })
            ctx.set_result({"srt_file": str(target_srt)})

        started = jobs_lib.start_job(store.job_file(project_id, "align"), target)
        if not started:
            return self._err("已經有一個對齊工作正在執行中")
        return self._send_json({"ok": True, "started": True})

    # ═══════════════════════════════════════════════════════════
    # 內容規劃 / 主題標籤
    # ═══════════════════════════════════════════════════════════

    def api_lyrics_map_assign(self, project_id, proj, body):
        idx = body.get("idx")
        theme = body.get("theme")
        if idx is None:
            return self._err("需要 idx")
        data = load_lyrics_map(project_id, proj)
        found = None
        for e in data["entries"]:
            if e["idx"] == idx:
                e["theme"] = theme
                found = e
                break
        if found is None:
            return self._err(f"找不到 idx={idx}", 404)
        save_lyrics_map(project_id, data)
        return self._send_json({"ok": True, "entry": found})

    def api_lyrics_map_suggest(self, project_id, proj, body):
        overwrite = bool(body.get("overwrite", False))
        data = load_lyrics_map(project_id, proj)
        themes_lib.suggest_all(data["entries"], proj.get("themes", []), overwrite=overwrite)
        save_lyrics_map(project_id, data)
        return self._send_json(data)

    def api_build_content_plan(self, project_id, proj, body):
        music_file = proj.get("music_file")
        if not music_file or not Path(music_file).exists():
            return self._err("請先在專案設定填寫有效的音樂檔路徑")

        data = load_lyrics_map(project_id, proj)
        entries = data["entries"]
        if not entries:
            return self._err("尚無歌詞時間軸，請先完成歌詞對齊")

        total_duration = lyrics_lib.get_media_duration(music_file)
        slot_params = {**store.DEFAULT_SLOT_PARAMS, **(proj.get("slot_params") or {})}
        if "beat_snap" in body:
            slot_params["beat_snap"] = bool(body["beat_snap"])

        beat_info = {"bpm": 0.0, "beats": [], "strong_beats": []}
        if slot_params.get("beat_snap", True):
            beat_info = beats_lib.analyze_audio_beats(
                music_file,
                cache_dir=store.project_dir(project_id) / ".cache" / "beats",
            )

        slots = lyrics_lib.build_timeline(
            entries, total_duration, slot_params,
            proj.get("title_card_file", "片頭.png"), float(proj.get("title_card_duration", 3.9)),
            proj.get("outro_file", "片尾.png"), float(proj.get("outro_duration", 8.0)),
            beats=beat_info.get("beats", []) if slot_params.get("beat_snap", True) else None,
        )
        theme_reqs = lyrics_lib.compute_theme_requirements(slots)
        beat_snapped_count = sum(1 for s in slots if s.get("beat_snapped"))

        plan = {
            "song_title": proj.get("song_title"),
            "photos_dir": str(photos_dir_of(proj)),
            "total_duration": total_duration,
            "bpm": beat_info.get("bpm", 0.0),
            "beats_count": len(beat_info.get("beats", [])),
            "beat_snap_enabled": bool(slot_params.get("beat_snap", True)),
            "beat_snapped_slots": beat_snapped_count,
            "theme_requirements": theme_reqs,
            "timeline": slots,
        }
        store.content_plan_file(project_id).write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
        store.update_project(project_id, {"status": {**proj.get("status", {}), "content_planned": True}})
        return self._send_json({
            "ok": True,
            "total_slots": len(slots),
            "total_duration": total_duration,
            "bpm": beat_info.get("bpm", 0.0),
            "beats_count": len(beat_info.get("beats", [])),
            "beat_snapped_slots": beat_snapped_count,
            "theme_requirements": theme_reqs,
        })

    # ═══════════════════════════════════════════════════════════
    # 照片
    # ═══════════════════════════════════════════════════════════

    def api_get_photos(self, project_id, proj):
        catalog = photos_lib.load_catalog(store.catalog_file(project_id))
        ps = catalog["photos"]
        stats = {
            "total": len(ps),
            "analyzed": sum(1 for p in ps if p.get("analyzed")),
            "pending": sum(1 for p in ps if not p.get("analyzed")),
        }
        return self._send_json({"photos": ps, "stats": stats, "themes": proj.get("themes", []), "photos_dir": str(photos_dir_of(proj))})

    def api_photos_scan(self, project_id, proj):
        catalog_path = store.catalog_file(project_id)
        catalog = photos_lib.load_catalog(catalog_path)
        batch_id = photos_lib.next_batch_id(catalog)
        result = photos_lib.scan_new_photos(photos_dir_of(proj), catalog_path, batch_id)
        return self._send_json(result)

    def api_photos_detect_focus(self, project_id, proj, body):
        """批次自動偵測照片中的人臉/主體視覺焦點 (focus_x, focus_y)"""
        overwrite = bool(body.get("overwrite", True))
        res = photos_lib.auto_detect_focus_batch(
            store.catalog_file(project_id), photos_dir_of(proj), overwrite=overwrite
        )
        return self._send_json({"ok": True, **res})

    def api_photos_update(self, project_id, proj, body):
        filename = body.get("filename")
        if not filename:
            return self._err("缺少 filename")
        valid_themes = [t["name"] for t in proj.get("themes", [])]
        entry = photos_lib.update_photo(store.catalog_file(project_id), filename, body, valid_themes)
        catalog = photos_lib.load_catalog(store.catalog_file(project_id))
        analyzed_count = sum(1 for p in catalog["photos"] if p.get("analyzed"))
        store.update_project(project_id, {"status": {**proj.get("status", {}), "photos_analyzed": analyzed_count}})
        return self._send_json({"ok": True, "photo": entry})

    def api_get_picker(self, project_id, proj, theme):
        catalog = photos_lib.load_catalog(store.catalog_file(project_id))
        plan_path = store.content_plan_file(project_id)
        used = {}
        if plan_path.exists():
            plan = json.loads(plan_path.read_text(encoding="utf-8"))
            assignments = manifest_lib.load_assignments(
                store.ordered_photos_detail_file(project_id), plan, catalog.get("photos", [])
            )
            used = manifest_lib.slots_in_use_count(assignments)

        items = []
        for p in catalog["photos"]:
            if not p.get("analyzed"):
                continue
            items.append({
                "filename": p["filename"],
                "theme": p.get("theme"),
                "quality_score": p.get("quality_score"),
                "fit_score": (p.get("fit_scores") or {}).get(theme) if theme else None,
                "used_count": used.get(p["filename"], 0),
                "protagonists": p.get("protagonists", []),
                "focus_x": p.get("focus_x", 0.5),
                "focus_y": p.get("focus_y", 0.38),
                "source": p.get("source", "local"),
                "downloaded": bool(p.get("downloaded", False)),
            })
        if theme:
            items.sort(key=lambda x: (x["theme"] != theme, -(x["fit_score"] or 0), x["used_count"]))
        else:
            items.sort(key=lambda x: x["used_count"])
        return self._send_json({"items": items})

    def api_start_auto_analyze(self, project_id, proj, body):
        """啟動背景工作：用 Gemini Vision API 自動分析照片。"""
        if auto_analyze_lib is None:
            return self._err("找不到 auto_analyze 模組，請確認 lib/auto_analyze.py 存在")

        api_key = (body.get("api_key") or "").strip()
        if not api_key:
            # 嘗試從 project 設定讀取
            api_key = (proj.get("gemini_api_key") or os.environ.get("GEMINI_API_KEY", "")).strip()
        if not api_key:
            return self._err("請提供 Gemini API Key（可在「⚙️ 專案設定」→「AI 分析設定」儲存）")

        themes = proj.get("themes", [])
        if not themes:
            return self._err("請先在「🗂️ 內容規劃」分頁設定主題標籤，AI 才知道要分類成哪些主題")

        catalog_path = store.catalog_file(project_id)
        photos_dir = photos_dir_of(proj)
        model_name = body.get("model") or proj.get("gemini_model") or os.environ.get("MV_GEMINI_MODEL", "gemini-2.5-flash")
        max_workers = int(body.get("max_workers", 3))
        filenames = body.get("filenames")  # 可選：只分析特定檔案

        def target(ctx):
            auto_analyze_lib.analyze_photos_batch(
                ctx,
                catalog_path=catalog_path,
                photos_dir=photos_dir,
                themes=themes,
                api_key=api_key,
                model_name=model_name,
                max_workers=max_workers,
                filenames_filter=filenames,
            )
            # 更新 project status
            cat = photos_lib.load_catalog(catalog_path)
            analyzed_count = sum(1 for p in cat["photos"] if p.get("analyzed"))
            store.update_project(project_id, {
                "status": {**proj.get("status", {}), "photos_analyzed": analyzed_count}
            })

        started = jobs_lib.start_job(store.job_file(project_id, "auto_analyze"), target)
        if not started:
            return self._err("已有一個自動分析工作正在執行中，請等待完成")
        return self._send_json({"ok": True, "started": True, "model": model_name})

    def api_cancel_auto_analyze(self, project_id, proj):
        """取消執行中的自動分析工作"""
        ok = jobs_lib.cancel_job(store.job_file(project_id, "auto_analyze"))
        return self._send_json({"ok": ok})

    def api_subagent_prepare(self, project_id, proj, body):
        """準備 Subagent 批次分析任務（自動掃描新照片、產生縮圖、切分 Shards 與 Prompt）"""
        themes = proj.get("themes", [])
        if not themes:
            return self._err("請先在「🗂️ 內容規劃」分頁設定主題標籤（或載入範例模板），Subagent 才知道要分類成哪些主題")
        max_per_agent = int(body.get("max_per_agent", 15))
        max_photos = int(body.get("max_photos", 0))
        reanalyze_all = bool(body.get("reanalyze_all", False))
        task_data = subagent_lib.prepare_subagent_task(
            project_id=project_id,
            proj=proj,
            scan_first=True,
            max_per_agent=max_per_agent,
            max_photos=max_photos,
            reanalyze_all=reanalyze_all,
        )
        return self._send_json({
            "ok": True,
            "task_file": task_data["task_file"],
            "stats": task_data["stats"],
            "theme_coverage": task_data["theme_coverage"],
            "agent_chat_prompt": task_data["agent_chat_prompt"],
            "cli_commands": task_data["cli_commands"],
            "shards": [
                {
                    "shard_id": s["shard_id"],
                    "photo_count": s["photo_count"],
                    "filenames": s["filenames"],
                    "prompt": s["prompt"],
                }
                for s in task_data["shards"]
            ],
        })

    def api_subagent_import(self, project_id, proj, body):
        """從網頁或 API 匯入 Subagent 分析完成的 JSON 結果"""
        analyses = []
        if isinstance(body.get("analyses"), list):
            analyses.extend(body["analyses"])
        if body.get("raw_json"):
            try:
                analyses.extend(subagent_lib.parse_raw_json_input(body["raw_json"]))
            except Exception as e:
                return self._err(f"JSON 格式解析失敗：{e}")
        if isinstance(body.get("files"), list):
            for fp in body["files"]:
                p = Path(fp)
                if p.exists():
                    analyses.extend(subagent_lib.parse_raw_json_input(p.read_text(encoding="utf-8")))
        if not analyses:
            return self._err("找不到有效的 analyses 分析資料，請確認 JSON 格式包含 analyses 陣列或照片物件清單")

        overwrite = bool(body.get("overwrite", True))
        res = subagent_lib.import_subagent_analyses(
            project_id=project_id,
            proj=proj,
            analyses=analyses,
            overwrite=overwrite,
            source_label="subagent",
        )
        return self._send_json(res)

    # ═══════════════════════════════════════════════════════════
    # 時間軸 / Manifest
    # ═══════════════════════════════════════════════════════════

    def _plan(self, project_id):
        plan_path = store.content_plan_file(project_id)
        if not plan_path.exists():
            raise FileNotFoundError("尚未建立內容規劃，請先在「內容規劃」分頁執行建立時間軸")
        return json.loads(plan_path.read_text(encoding="utf-8"))

    def api_get_manifest(self, project_id, proj):
        plan = self._plan(project_id)
        catalog = photos_lib.load_catalog(store.catalog_file(project_id))
        catalog_photos = catalog.get("photos", [])
        assignments = manifest_lib.load_assignments(
            store.ordered_photos_detail_file(project_id), plan, catalog_photos
        )
        by_slot = {a["slot_id"]: a for a in assignments}
        catalog_idx = photos_lib.catalog_index_by_filename(catalog)

        slots_out = []
        for slot in plan["timeline"]:
            a = by_slot.get(slot["slot_id"], {})
            filename = a.get("filename") or slot.get("assigned_photo")
            cat_entry = catalog_idx.get(filename) if filename else None
            slots_out.append({
                "slot_id": slot["slot_id"],
                "start": slot["start"], "end": slot["end"],
                "duration": a.get("duration", slot["duration"]),
                "theme": slot["theme"], "subtitle": slot.get("subtitle"),
                "is_gap": slot.get("is_gap", False),
                "is_fixed": bool(slot.get("assigned_photo")),
                "beat_snapped": bool(slot.get("beat_snapped", False)),
                "beat_offset_ms": slot.get("beat_offset_ms", 0),
                "filename": filename, "reason": a.get("reason"),
                "quality_score": (cat_entry or {}).get("quality_score"),
                "protagonists": (cat_entry or {}).get("protagonists", []),
                "focus_x": (cat_entry or {}).get("focus_x", 0.5),
                "focus_y": (cat_entry or {}).get("focus_y", 0.38),
                "missing": filename in (None, "__MISSING__"),
            })
        total_cal = round(sum(s["duration"] for s in slots_out), 3)
        protagonist_stats = manifest_lib.compute_protagonist_stats(assignments, catalog_idx)
        gphotos_status = gphotos_lib.get_selected_download_status(project_id)
        return self._send_json({
            "song_title": plan.get("song_title"),
            "total_duration": plan.get("total_duration"),
            "total_duration_calc": total_cal,
            "bpm": plan.get("bpm", 0.0),
            "beat_snapped_slots": plan.get("beat_snapped_slots", 0),
            "protagonist_stats": protagonist_stats,
            "gphotos_status": gphotos_status,
            "slots": slots_out,
        })

    def api_manifest_assign(self, project_id, proj, body):
        slot_id = body.get("slot_id")
        filename = body.get("filename")
        if slot_id is None or not filename:
            return self._err("需要 slot_id 與 filename")
        plan = self._plan(project_id)
        catalog = photos_lib.load_catalog(store.catalog_file(project_id))
        catalog_photos = catalog.get("photos", [])
        assignments = manifest_lib.load_assignments(
            store.ordered_photos_detail_file(project_id), plan, catalog_photos
        )
        found = None
        for a in assignments:
            if a["slot_id"] == slot_id:
                a["filename"] = filename
                a["reason"] = "MANUAL"
                found = a
                break
        if found is None:
            return self._err(f"找不到 slot_id={slot_id}", 404)
        detail = manifest_lib.save_assignments(
            store.ordered_photos_detail_file(project_id), store.ordered_photos_file(project_id),
            plan, assignments, catalog_photos=catalog_photos
        )
        catalog_idx = photos_lib.catalog_index_by_filename(catalog)
        protagonist_stats = manifest_lib.compute_protagonist_stats(assignments, catalog_idx)
        return self._send_json({
            "ok": True,
            "slot": found,
            "total_duration_calc": detail["total_duration"],
            "protagonist_stats": protagonist_stats,
        })

    def api_manifest_duration(self, project_id, proj, body):
        slot_id = body.get("slot_id")
        duration = body.get("duration")
        if slot_id is None or duration is None:
            return self._err("需要 slot_id 與 duration")
        try:
            duration = round(float(duration), 3)
        except (TypeError, ValueError):
            return self._err("duration 必須是數字")
        if duration <= 0:
            return self._err("duration 必須大於 0")
        plan = self._plan(project_id)
        catalog = photos_lib.load_catalog(store.catalog_file(project_id))
        catalog_photos = catalog.get("photos", [])
        assignments = manifest_lib.load_assignments(
            store.ordered_photos_detail_file(project_id), plan, catalog_photos
        )
        found = None
        for a in assignments:
            if a["slot_id"] == slot_id:
                a["duration"] = duration
                found = a
                break
        if found is None:
            return self._err(f"找不到 slot_id={slot_id}", 404)
        detail = manifest_lib.save_assignments(
            store.ordered_photos_detail_file(project_id), store.ordered_photos_file(project_id),
            plan, assignments, catalog_photos=catalog_photos
        )
        return self._send_json({"ok": True, "slot": found, "total_duration_calc": detail["total_duration"]})

    def api_manifest_autobuild(self, project_id, proj, body=None):
        body = body or {}
        plan = self._plan(project_id)
        catalog = photos_lib.load_catalog(store.catalog_file(project_id))
        catalog_photos = catalog.get("photos", [])
        slot_params = {**store.DEFAULT_SLOT_PARAMS, **(proj.get("slot_params") or {})}
        protagonist_weight = float(body.get("protagonist_weight", slot_params.get("protagonist_weight", 2.5)))
        assignments, stats = manifest_lib.assign_photos(
            plan["timeline"], catalog_photos, protagonist_weight=protagonist_weight
        )
        detail = manifest_lib.save_assignments(
            store.ordered_photos_detail_file(project_id), store.ordered_photos_file(project_id),
            plan, assignments, stats, catalog_photos=catalog_photos
        )
        store.update_project(project_id, {"status": {**proj.get("status", {}), "manifest_built": True}})
        return self._send_json({"ok": True, "stats": stats, "total_duration_calc": detail["total_duration"]})

    # ═══════════════════════════════════════════════════════════
    # 渲染
    # ═══════════════════════════════════════════════════════════

    def start_render_job(self, project_id, proj):
        ordered_path = store.ordered_photos_file(project_id)
        if not ordered_path.exists():
            return self._err("尚未完成照片分配，請先在「照片分配」分頁建立時間軸")
        ordered_photos = json.loads(ordered_path.read_text(encoding="utf-8"))
        srt_file = store.resolved_srt_file(proj)
        srt_entries = lyrics_lib.parse_srt(srt_file)
        music_file = Path(proj["music_file"])
        output_file = store.resolved_output_file(proj)
        pdir = photos_dir_of(proj)

        def target(ctx):
            try:
                gphotos_lib.download_selected_photos(project_id, ctx=ctx)
            except Exception as e:
                ctx.log(f"⚠️ 下載 Google 相簿原圖時警告：{e}")
            result = render_lib.render_project(pdir, srt_file, music_file, output_file, ordered_photos, srt_entries, ctx)
            store.update_project(project_id, {
                "output_file": str(output_file),
                "status": {**proj.get("status", {}), "rendered": True},
            })
            ctx.set_result(result)

        started = jobs_lib.start_job(store.job_file(project_id, "render"), target)
        if not started:
            return self._err("已經有一個渲染工作正在執行中")
        return self._send_json({"ok": True, "started": True})


def shutil_copy(fsrc, fdst, chunk=65536):
    while True:
        data = fsrc.read(chunk)
        if not data:
            break
        fdst.write(data)


def main():
    global SERVER_PORT
    parser = argparse.ArgumentParser(description="MV Studio 本地網頁工具（多專案版）")
    parser.add_argument("--host", type=str, default="127.0.0.1",
                        help="預設只開放本機；活動現場要讓手機上傳時請加 --lan")
    parser.add_argument("--lan", action="store_true",
                        help="開放區網連線（0.0.0.0）。非本機連線只能使用 /upload 手機上傳頁")
    parser.add_argument("--port", type=int, default=8787)
    args = parser.parse_args()
    SERVER_PORT = args.port
    if args.lan:
        args.host = "0.0.0.0"

    store._ensure_dirs()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    lan_ip = event_lib.get_lan_ip()
    print("=" * 60)
    print("  🎬 MV Studio 本地網頁工具（含活動前籌備與即時照片募集）")
    print("=" * 60)
    print(f"  💻 本機操作介面：http://localhost:{args.port}")
    if args.host == "0.0.0.0":
        print(f"  📱 區網手機上傳：http://{lan_ip}:{args.port}/upload/<活動代碼>")
    else:
        print("  🔒 目前只開放本機。活動現場需要手機上傳時，請改用 --lan 啟動")
    print("  按 Ctrl+C 停止伺服器")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 伺服器已停止。")


if __name__ == "__main__":
    main()
