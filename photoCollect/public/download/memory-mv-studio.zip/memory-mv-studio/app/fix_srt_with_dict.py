import re
import sys

def fix_srt(input_path, output_path):
    with open(input_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Split into blocks
    blocks = content.strip().split('\n\n')
    
    corrections = {
        "啊 人生如夢": "啊！人生如夢",
        "啊 夢如人生": "啊！夢如人生",
        "這半徑的修煙": "這班進德修業",
        "我們的班": "喚醒我們",
        "照問西四神道之真": "朝聞夕死聖道之真",
        "存信揚心十天成神": "存心養性事天成神",
        "揚心無主席又真心": "妙行無住希有正信",
        "真法延藏也盤揚心": "正法眼藏涅槃妙心",
        "選之歌弦中揚之門": "玄之又玄眾妙之門",
        "命運終身對等你": "芸芸眾生歸根復命",
        "改歌奉勸來我盡": "大道無情",
        "上揚萬物雖名得道": "長養萬物 雖名得道",
        "為花終生": "為化眾生",
        "風動幡動皆為動心": "風動幡動皆為動心",
        "無上妙道無所住心": "無上妙道無所住心",
        "無寂無力是能成成": "不即不離始能真成",
        "黃天無情唯一的師父": "皇天無親唯德是輔",
        "歌隨音樂獨化終身": "各隨因緣渡化眾生",
        "靜靜默寫無天所身": "精進莫懈無忝所生",
        "詞曲 李宗盛": "" # Hallucination
    }

    new_blocks = []
    for block in blocks:
        lines = block.split('\n')
        if len(lines) >= 3:
            idx = lines[0]
            timing = lines[1]
            text = '\n'.join(lines[2:])
            
            # Direct match
            if text in corrections:
                text = corrections[text]
            else:
                # Substring matching in case of minor differences
                for wrong, right in corrections.items():
                    if wrong in text:
                        text = text.replace(wrong, right)
            
            if text.strip() == "":
                continue # Skip empty subtitles if any
                
            new_blocks.append(f"{idx}\n{timing}\n{text}")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(new_blocks) + '\n')

if __name__ == '__main__':
    fix_srt(sys.argv[1], sys.argv[2])
