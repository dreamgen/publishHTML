#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mvctl.py — 照片回憶 MV 製作流程的「單一指令入口」
=====================================================
給 AI Agent（Claude / Gemini / Codex …）與命令列使用者共用。
所有資料都存在 MV Studio 專案資料夾（mv_studio/projects/<id>/），
網頁介面（serve）與指令列看到的是同一份資料，可以隨時切換。

常用流程：
  python mvctl.py doctor                              # 環境健檢
  python mvctl.py new --name 家庭日 --music song.mp3 --lyrics lyrics.txt --photos ./photos
  python mvctl.py status <ID>                         # 判斷目前在哪個階段、下一步做什麼
  python mvctl.py event <ID> --schedule schedule.txt  # 階段 0：活動前籌備（選用）
  python mvctl.py align <ID>                          # 階段 1：歌詞強制對齊 → 人工把關點 1
  python mvctl.py themes <ID> --from-lyrics           # 階段 2：產生主題建議（或 --set）
  python mvctl.py map <ID> --suggest                  #          逐行歌詞指派主題
  python mvctl.py plan <ID>                           #          產生 content_plan.json
  python mvctl.py scan <ID>                           # 階段 3：掃描照片 + 產生 Subagent 任務
  python mvctl.py import <ID> result1.json ...        #          匯入視覺分析結果
  python mvctl.py manifest <ID>                       # 階段 4：三優先排程 → 人工把關點 2
  python mvctl.py render <ID>                         # 階段 5：渲染輸出 MP4
  python mvctl.py serve [--lan]                       # 開啟網頁介面（--lan 才允許手機上傳）

雲端收照片（選用）：
  python mvctl.py link <ID> --event <同步網址> --key <同步金鑰>   # 連結雲端活動並帶入流程表／小隊／拍攝清單
  python mvctl.py sync <ID> [--watch [--interval 300]]            # 下載雲端新照片（--watch 持續同步）
  python mvctl.py push-requirements <ID>                          # 把各主題需要張數回寫雲端拍攝清單
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# Windows 終端機預設可能是 Big5/cp950，emoji 與中文會變亂碼甚至拋 UnicodeEncodeError，統一改 UTF-8
_ORIG_ENCODING = getattr(sys.stdout, "encoding", "") or ""   # reconfigure 之前的編碼，供 doctor 判斷終端機狀況
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ROOT = Path(__file__).resolve().parent
STUDIO_DIR = ROOT / "mv_studio"
sys.path.insert(0, str(STUDIO_DIR))

from lib import store, lyrics as lyrics_lib, photos as photos_lib, manifest as manifest_lib  # noqa: E402
from lib import themes as themes_lib, portable  # noqa: E402
from lib import cloud_sync  # noqa: E402


# ───────────────────────────────────────────────────────────────
# 共用工具
# ───────────────────────────────────────────────────────────────

class ConsoleCtx:
    """模擬 jobs.JobContext，讓背景工作函式可在命令列直接執行。"""

    def __init__(self):
        self.result = None
        self._last_pct = -1

    def log(self, line: str):
        print(line, flush=True)

    def progress(self, done: int, total: int, phase: str = ""):
        pct = int(done * 100 / total) if total else 100
        if pct // 10 != self._last_pct // 10:
            print(f"   … {phase} {done}/{total} ({pct}%)", flush=True)
            self._last_pct = pct

    def set_result(self, result: dict):
        self.result = result

    def is_cancelled(self) -> bool:
        return False


def die(msg: str, code: int = 1):
    print(f"❌ {msg}")
    sys.exit(code)


def get_proj(pid: str) -> dict:
    try:
        return store.get_project(pid)
    except Exception:
        die(f"找不到專案 {pid}（用 `python mvctl.py projects` 查看所有專案）")


def photos_dir_of(proj: dict) -> Path:
    return Path(proj.get("photos_dir") or str(store.project_dir(proj["id"]) / "photos"))


def venv_python() -> str:
    for cand in (ROOT / "venv" / "bin" / "python3", ROOT / "venv" / "Scripts" / "python.exe"):
        if cand.exists():
            return str(cand)
    return sys.executable


def load_lyrics_map(pid: str, proj: dict) -> dict:
    lm_path = store.lyrics_map_file(pid)
    srt_entries = lyrics_lib.parse_srt(store.resolved_srt_file(proj))
    saved = {}
    if lm_path.exists():
        saved = {e["idx"]: e for e in json.loads(lm_path.read_text(encoding="utf-8")).get("entries", [])}
    merged = [{"idx": e["idx"], "start": e["start"], "end": e["end"], "text": e["text"],
               "theme": saved.get(e["idx"], {}).get("theme")} for e in srt_entries]
    merged.sort(key=lambda e: e["idx"])
    return {"entries": merged}


def save_lyrics_map(pid: str, data: dict):
    store.lyrics_map_file(pid).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def set_status(pid: str, **kv):
    proj = store.get_project(pid)
    store.update_project(pid, {"status": {**proj.get("status", {}), **kv}})


# ───────────────────────────────────────────────────────────────
# doctor
# ───────────────────────────────────────────────────────────────

def cmd_doctor(args):
    ok = True

    def line(flag, name, detail=""):
        nonlocal ok
        mark = {True: "✅", False: "❌", None: "⚠️ "}[flag]
        if flag is False:
            ok = False
        print(f"{mark} {name}{('：' + detail) if detail else ''}")

    v = sys.version_info
    line(v >= (3, 10), "Python", f"{v.major}.{v.minor}.{v.micro}（需要 3.10 以上）")
    for tool in ("ffmpeg", "ffprobe"):
        line(bool(shutil.which(tool)), tool, shutil.which(tool) or "未安裝 → macOS: brew install ffmpeg／Windows: winget install Gyan.FFmpeg／Linux: apt install ffmpeg")
    for mod, need, why in (("PIL", True, "Pillow，照片合成"), ("numpy", True, "節拍偵測"),
                           ("pypinyin", True, "歌詞同音字對齊"), ("whisper", True, "歌詞時間軸轉錄（openai-whisper）"),
                           ("pillow_heif", False, "讀取 iPhone HEIC 照片"),
                           ("google.generativeai", False, "網頁版 Gemini 自動分析（Agent 模式不需要）")):
        try:
            __import__(mod)
            line(True, mod, why)
        except Exception:
            line(False if need else None, mod, f"未安裝（{why}）")
    # 字型：實際檢查繁體字能否畫出（日文字型沒有「啟」等繁體字，會變方框）
    fc = portable.choose_cjk_font()
    if fc is None:
        line(False, "中文字型", "找不到任何中文字型，字幕會變方框 → 執行 mvctl fonts 下載 Noto Sans TC")
    elif fc.missing:
        line(False, "中文字型", f"{fc} 缺繁體字「{''.join(fc.missing)}」→ 執行 mvctl fonts 下載 Noto Sans TC，或設定 MV_FONT")
    else:
        bundled = str(fc.path).startswith(str(portable.APP_FONT_DIR))
        line(True if bundled else None, "中文字型", f"{fc}（繁體字檢驗通過）" + ("" if bundled else "；建議執行 mvctl fonts 改用內建 Noto Sans TC，各電腦字幕外觀一致"))
    enc = portable.final_encoder_args()
    line(True, "最終編碼器", " ".join(enc[:2]) + "（可用 MV_FINAL_ENCODER=cpu|videotoolbox|nvenc 覆寫）")
    line(True, "專案資料夾", str(store.PROJECTS_DIR))
    if portable.IS_WIN:
        # OneDrive 會把檔案「依需求下載」，大量照片與 venv 放在裡面會同步到卡住、檔案被鎖
        low = str(ROOT).lower()
        od = os.environ.get("OneDrive", "").lower()
        in_od = "onedrive" in low or (od and low.startswith(od))
        line(None if in_od else True, "安裝路徑",
             f"{ROOT} 位於 OneDrive 底下，同步會拖慢甚至鎖住檔案 → 建議改裝到 C:\\MVStudio（設定環境變數 MV_HOME）" if in_od
             else f"{ROOT}（不在 OneDrive 內）")
        cp = 0
        try:
            import ctypes
            cp = ctypes.windll.kernel32.GetConsoleOutputCP()   # 65001 = UTF-8
        except Exception:
            pass
        orig = _ORIG_ENCODING.lower().replace("-", "")
        if orig != "utf8" or (cp and cp != 65001):
            line(None, "終端機編碼", f"Python 預設編碼 {_ORIG_ENCODING or '未知'}、主控台碼頁 {cp or '未知'}，中文可能顯示成亂碼（Big5/cp950）→ "
                 "PowerShell 先執行 [Console]::OutputEncoding=[System.Text.Encoding]::UTF8 與 $env:PYTHONUTF8=1（用 setup.ps1／setup.bat 啟動會自動設定）")
        else:
            line(True, "終端機編碼", "UTF-8")
    print("\n" + ("🎉 環境就緒" if ok else "請先修正 ❌ 項目再開始製作"))
    sys.exit(0 if ok else 1)


# ───────────────────────────────────────────────────────────────
# 專案管理
# ───────────────────────────────────────────────────────────────

def cmd_projects(args):
    items = store.list_projects()
    if not items:
        print("（尚無專案，用 `python mvctl.py new --name ...` 建立）")
    for p in items:
        print(f"{p.get('id')}\t{p.get('name')}\t歌曲：{p.get('song_title', '')}")


def cmd_new(args):
    proj = store.create_project(args.name, args.song or args.name)
    pid = proj["id"]
    patch = {}
    if args.music:
        patch["music_file"] = str(Path(args.music).expanduser().resolve())
    if args.photos:
        patch["photos_dir"] = str(Path(args.photos).expanduser().resolve())
    else:
        (store.project_dir(pid) / "photos").mkdir(parents=True, exist_ok=True)
    if args.lyrics:
        dst = store.project_dir(pid) / "lyrics.txt"
        shutil.copyfile(Path(args.lyrics).expanduser(), dst)
        patch["lyrics_text_file"] = str(dst)
    if args.output:
        patch["output_file"] = str(Path(args.output).expanduser().resolve())
    if patch:
        store.update_project(pid, patch)
    print(f"✅ 已建立專案 {pid}")
    print(f"   資料夾：{store.project_dir(pid)}")
    cmd_status(argparse.Namespace(project=pid))


def cmd_set(args):
    get_proj(args.project)
    patch = {}
    for kv in args.pairs:
        if "=" not in kv:
            die(f"格式錯誤：{kv}（應為 key=value）")
        k, v = kv.split("=", 1)
        if k in ("music_file", "photos_dir", "output_file", "lyrics_text_file", "srt_file", "title_card_file", "outro_file") and v:
            v = str(Path(v).expanduser().resolve()) if k not in ("title_card_file", "outro_file") else v
        elif k in ("title_card_duration", "outro_duration"):
            v = float(v)
        patch[k] = v
    store.update_project(args.project, patch)
    print(f"✅ 已更新：{', '.join(patch)}")


def cmd_status(args):
    pid = args.project
    proj = get_proj(pid)
    pdir = store.project_dir(pid)
    music = Path(proj.get("music_file") or "")
    srt = store.resolved_srt_file(proj)
    plan = store.content_plan_file(pid)
    catalog_path = store.catalog_file(pid)
    ordered = store.ordered_photos_file(pid)
    out = store.resolved_output_file(proj)
    cat = photos_lib.load_catalog(catalog_path) if catalog_path.exists() else {"photos": []}
    fixed_names = {proj.get("title_card_file", "片頭.png"), proj.get("outro_file", "片尾.png")}
    real = [p for p in cat["photos"] if p.get("filename") not in fixed_names]
    n_total = len(real)
    n_done = sum(1 for p in real if p.get("analyzed"))
    on_disk = 0
    pd = photos_dir_of(proj)
    if pd.exists():
        on_disk = sum(1 for f in pd.iterdir() if f.suffix.lower() in photos_lib.PHOTO_EXTS and f.name not in fixed_names)

    rows = [
        ("音樂檔", music.is_file(), str(music) if str(music) not in ("", ".") else "未設定"),
        ("歌詞 lyrics.txt", bool(proj.get("lyrics_text_file")) and Path(proj["lyrics_text_file"]).exists(), proj.get("lyrics_text_file") or "未設定"),
        ("主題標籤", bool(proj.get("themes")), ", ".join(t["name"] for t in proj.get("themes", [])) or "未設定"),
        ("階段1 字幕 SRT", srt.exists(), str(srt)),
        ("階段2 content_plan", plan.exists(), str(plan)),
        ("階段3 照片分析", n_total > 0 and n_done == n_total and n_total >= on_disk, f"已分析 {n_done} / 已收錄 {n_total} / 資料夾內 {on_disk} 張"),
        ("階段4 ordered_photos", ordered.exists(), str(ordered)),
        ("階段5 成品 MP4", out.exists(), str(out)),
    ]
    print(f"📁 {proj.get('name')}（{pid}）")
    for name, done, detail in rows:
        print(f"  {'✅' if done else '⬜'} {name}：{detail}")
    cloud = proj.get("cloud")
    if cloud:
        ev_name = (proj.get("event_info") or {}).get("event_name") or cloud.get("event_id")
        n_cloud = sum(1 for p in real if p.get("source") == "cloud")
        print(f"  ☁️ 雲端收照片：已連結「{ev_name}」，最後同步 {cloud.get('last_sync_at') or '尚未同步'}（雲端來源照片 {n_cloud} 張）")

    # 下一步建議（依序找第一個未完成）
    if cloud and n_total == 0 and on_disk == 0:
        nxt = "雲端已連結但還沒有照片：python mvctl.py sync {pid}（活動進行中可加 --watch 持續同步）"
    elif not music.is_file() or not proj.get("lyrics_text_file"):
        nxt = "補齊音樂與歌詞：python mvctl.py set {pid} music_file=<mp3>；歌詞用 new --lyrics 或 set lyrics_text_file=<txt>"
    elif not srt.exists():
        nxt = "階段 1：python mvctl.py align {pid}"
    elif not proj.get("themes"):
        nxt = "階段 2：python mvctl.py themes {pid} --from-lyrics（或 --set）"
    elif not plan.exists():
        nxt = "階段 2：python mvctl.py map {pid} --suggest → python mvctl.py plan {pid}"
    elif n_total < on_disk or n_done < n_total or n_total == 0:
        nxt = "階段 3：python mvctl.py scan {pid} → 視覺分析 → python mvctl.py import {pid} <json…>"
    elif not ordered.exists():
        nxt = "階段 4：python mvctl.py manifest {pid}"
    elif not out.exists():
        nxt = "階段 5：python mvctl.py render {pid}"
    else:
        nxt = "已完成。若有新照片或修改，重跑 scan → manifest → render"
    print("\n👉 下一步：" + nxt.format(pid=pid))


# ───────────────────────────────────────────────────────────────
# 階段 0：活動前籌備
# ───────────────────────────────────────────────────────────────

def _read_text_arg(v):
    if not v:
        return None
    p = Path(v).expanduser()
    if p.exists():
        if p.suffix.lower() in (".docx", ".doc", ".pdf", ".rtf"):
            from lib import event_prep
            try:
                return event_prep.extract_document_text(p)
            except (RuntimeError, OSError) as e:
                die(str(e))
        return p.read_text(encoding="utf-8", errors="ignore")
    return v


def cmd_event(args):
    from lib import event_prep
    pid = args.project
    proj = get_proj(pid)
    patch = {k: v for k, v in {
        "event_name": args.event_name, "event_date": args.date, "event_end_date": args.end_date, "event_location": args.location,
        "organizer": args.organizer, "slogan": args.slogan,
        "schedule_text": _read_text_arg(args.schedule), "handbook_text": _read_text_arg(args.handbook),
        "promo_copy": _read_text_arg(args.promo), "public_base_url": args.public_url,
    }.items() if v}
    res = event_prep.prepare_collection_environment(pid, proj, event_patch=patch, port=args.port)
    print(json.dumps({k: res.get(k) for k in ("upload", "themes", "expected_groups", "cards") if k in res},
                     ensure_ascii=False, indent=2))
    print("\n📱 手機上傳需要以 `python mvctl.py serve --lan` 啟動伺服器（同一個 Wi-Fi）。")


# ───────────────────────────────────────────────────────────────
# 階段 1：歌詞強制對齊
# ───────────────────────────────────────────────────────────────

def cmd_align(args):
    pid = args.project
    proj = get_proj(pid)
    music = proj.get("music_file")
    lyrics = proj.get("lyrics_text_file")
    if not music or not Path(music).exists():
        die("尚未設定有效的 music_file")
    if not lyrics or not Path(lyrics).exists():
        die("尚未設定歌詞檔 lyrics_text_file")
    pdir = store.project_dir(pid)
    cmd = [venv_python(), str(ROOT / "align_lyrics_dp.py"), music, lyrics, "--model", args.model]
    print("▶ " + " ".join(cmd))
    subprocess.run(cmd, cwd=pdir, check=True)
    generated = pdir / f"{Path(music).stem}_generated.srt"
    if not generated.exists():
        die("對齊完成但找不到產生的 SRT")
    target = store.resolved_srt_file(proj)
    generated.replace(target)
    store.update_project(pid, {"srt_file": str(target)})
    set_status(pid, lyrics_aligned=True)
    print(f"✅ 字幕：{target}")
    calib = list(pdir.glob("*_校對用.mp4"))
    print("🔍 人工把關點 1：請播放校對影片（開啟字幕軌）確認時間軸，"
          f"必要時直接修改 {target.name} 再進行下一步。" + (f"\n   校對影片：{calib[0]}" if calib else ""))


# ───────────────────────────────────────────────────────────────
# 階段 2：主題與時間軸規劃
# ───────────────────────────────────────────────────────────────

def cmd_themes(args):
    pid = args.project
    proj = get_proj(pid)
    themes = list(proj.get("themes", []))
    if args.template:
        themes = [dict(t) for t in store.DEFAULT_THEME_TEMPLATE]
    if args.set:
        themes = []
        for chunk in args.set.split("|"):
            chunk = chunk.strip()
            if not chunk:
                continue
            name, _, kws = chunk.partition("=")
            themes.append({"name": name.strip(), "keywords": [k.strip() for k in kws.split(",") if k.strip()]})
    if args.from_lyrics:
        entries = load_lyrics_map(pid, proj)["entries"]
        cands = themes_lib.generate_candidate_themes(entries, themes)
        print("💡 歌詞高頻意象建議（可用 --set 正式採用）：")
        for c in cands:
            print(f"   - {c.get('name')}：{', '.join(c.get('keywords', []))}")
    if args.template or args.set:
        themes = themes_lib.validate_themes(themes)
        store.update_project(pid, {"themes": themes})
    print("目前主題：" + (", ".join(f"{t['name']}({'/'.join(t.get('keywords', [])[:4])})" for t in themes) or "（未設定）"))


def cmd_map(args):
    pid = args.project
    proj = get_proj(pid)
    data = load_lyrics_map(pid, proj)
    if args.suggest:
        themes_lib.suggest_all(data["entries"], proj.get("themes", []), overwrite=args.overwrite)
    for a in args.assign or []:
        idx, _, theme = a.partition("=")
        for e in data["entries"]:
            if str(e["idx"]) == idx.strip():
                e["theme"] = theme.strip()
    save_lyrics_map(pid, data)
    for e in data["entries"]:
        print(f"{e['idx']:>3} [{e.get('theme') or '—'}] {e['start']:.1f}s {e['text']}")
    missing = sum(1 for e in data["entries"] if not e.get("theme"))
    if missing:
        print(f"\n⚠️ 尚有 {missing} 行未指定主題（未指定者會歸入 General，通常沒有對應照片，只能借用其他主題）。用 --assign 3=Intro 補上。")


def cmd_plan(args):
    from lib import beats as beats_lib
    pid = args.project
    proj = get_proj(pid)
    music = proj.get("music_file")
    if not music or not Path(music).exists():
        die("尚未設定有效的 music_file")
    entries = load_lyrics_map(pid, proj)["entries"]
    if not entries:
        die("尚無歌詞時間軸，請先執行 align")
    total = lyrics_lib.get_media_duration(music)
    sp = {**store.DEFAULT_SLOT_PARAMS, **(proj.get("slot_params") or {})}
    if args.no_beat_snap:
        sp["beat_snap"] = False
    beat_info = {"bpm": 0.0, "beats": []}
    if sp.get("beat_snap", True):
        beat_info = beats_lib.analyze_audio_beats(music, cache_dir=store.project_dir(pid) / ".cache" / "beats")
    slots = lyrics_lib.build_timeline(
        entries, total, sp,
        proj.get("title_card_file", "片頭.png"), float(proj.get("title_card_duration", 3.9)),
        proj.get("outro_file", "片尾.png"), float(proj.get("outro_duration", 8.0)),
        beats=beat_info.get("beats", []) if sp.get("beat_snap", True) else None,
    )
    reqs = lyrics_lib.compute_theme_requirements(slots)
    plan = {
        "song_title": proj.get("song_title"), "photos_dir": str(photos_dir_of(proj)),
        "total_duration": total, "bpm": beat_info.get("bpm", 0.0),
        "beats_count": len(beat_info.get("beats", [])), "beat_snap_enabled": bool(sp.get("beat_snap", True)),
        "beat_snapped_slots": sum(1 for s in slots if s.get("beat_snapped")),
        "theme_requirements": reqs, "timeline": slots,
    }
    store.content_plan_file(pid).write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    set_status(pid, content_planned=True)
    err = abs(sum(s["duration"] for s in slots) - total)
    print(f"✅ content_plan：{len(slots)} 個時槽，總長 {total:.2f}s（誤差 {err:.3f}s），BPM {plan['bpm']}")
    print("📋 各主題照片需求（請據此確認照片是否足夠）：")
    for t, r in reqs.items():
        print(f"   {t:<14} 需要 {r['photos_needed']:>3} 張，共 {r['total_seconds']:.1f} 秒")
    fixed = [proj.get("title_card_file", "片頭.png"), proj.get("outro_file", "片尾.png")]
    pd = photos_dir_of(proj)
    for f in fixed:
        if not (pd / f).exists():
            print(f"⚠️ 照片資料夾缺少固定素材 {f}（可用 event 指令自動產生，或自行放入 1920×1080 圖）")
    if proj.get("cloud"):   # 已連結雲端：自動把各主題需求張數回寫給攝影師看的拍攝清單，失敗只警告
        try:
            res = cloud_sync.push_requirements(pid)
            print(f"☁️ 已回寫雲端拍攝清單：送出 {res['sent']} 個主題，更新 {res['updated']} 筆")
        except Exception as e:
            print(f"⚠️ 回寫雲端失敗（不影響本地流程，稍後可執行 push-requirements）：{e}")


# ───────────────────────────────────────────────────────────────
# 雲端收照片：link / sync / push-requirements
# ───────────────────────────────────────────────────────────────

def cmd_link(args):
    proj = get_proj(args.project)
    try:
        res = cloud_sync.link(args.project, args.event, args.key)
    except cloud_sync.SyncError as e:
        die(str(e))
    p = res["proj"]
    ev = p.get("event_info") or {}
    segs = res["first"].get("segments") or []
    print(f"✅ 已連結雲端活動：{ev.get('event_name')}（{p['cloud']['event_id']}）")
    from lib import event_prep
    print(f"   日期：{event_prep.event_date_text(ev) or '—'}　地點：{ev.get('event_location') or '—'}　主辦：{ev.get('organizer') or '—'}")
    print(f"   環節 {len(segs)} 個：" + "、".join(f"{s['start']}-{s['end']} {s['name']}" for s in segs))
    print(f"   小隊 {len(ev.get('expected_groups') or [])} 個：" + ("、".join(ev.get("expected_groups") or []) or "—"))
    print(f"   拍攝清單 {len(ev.get('shot_checklist') or [])} 項")
    print("   主題標籤：" + (", ".join(t["name"] for t in p.get("themes", [])) or "（未設定）"))
    if res["cards_error"]:
        print(f"⚠️ 片頭／片尾圖卡產生失敗（可稍後用 event 指令補做）：{res['cards_error']}")
    else:
        print(f"   片頭／片尾圖卡已產生於 {p.get('photos_dir')}")
    print(f"👉 下一步：python mvctl.py sync {args.project}")


def _print_sync_summary(res: dict):
    print(f"📥 新增 {res['added']}、略過 {res['skipped']}、排除 {res['excluded']}" + (f"、失敗 {res['failed']}" if res["failed"] else ""))
    if res["by_segment"]:
        print("   各環節（theme_hint）：" + "、".join(f"{k} {v}" for k, v in sorted(res["by_segment"].items(), key=lambda kv: -kv[1])))
    if res["by_group"]:
        print("   各小隊：" + "、".join(f"{k} {v}" for k, v in sorted(res["by_group"].items(), key=lambda kv: -kv[1])))
    if res["failed"]:
        print("   ⚠️ 有照片下載失敗，再執行一次 sync 會補抓。")


def cmd_sync(args):
    get_proj(args.project)
    interval = max(10, int(args.interval))
    while True:
        try:
            res = cloud_sync.sync_once(args.project, log=print)
            _print_sync_summary(res)
            if res["added"] and not args.watch:
                print(f"👉 下一步：python mvctl.py scan {args.project} --focus（新照片進入視覺分析）")
        except cloud_sync.SyncAuthError as e:
            die(str(e))
        except cloud_sync.SyncError as e:
            if not args.watch:
                die(str(e))
            print(f"⚠️ {e}（{interval} 秒後重試）")
        if not args.watch:
            return
        print(f"⏳ {time.strftime('%H:%M:%S')} 完成，{interval} 秒後再同步（Ctrl+C 結束）", flush=True)
        try:
            time.sleep(interval)
        except KeyboardInterrupt:
            print("\n👋 已停止同步。")
            return


def cmd_push_requirements(args):
    get_proj(args.project)
    try:
        res = cloud_sync.push_requirements(args.project)
    except cloud_sync.SyncError as e:
        die(str(e))
    print(f"✅ 已送出 {res['sent']} 個主題的需求張數，雲端更新 {res['updated']} 筆拍攝清單")


# ───────────────────────────────────────────────────────────────
# 階段 3：照片分析
# ───────────────────────────────────────────────────────────────

def cmd_scan(args):
    cmd = [sys.executable, str(ROOT / "analyze_batch_photos.py"), "scan", "--project", args.project]
    subprocess.run(cmd, check=True)
    from lib import photos as pl
    proj = get_proj(args.project)
    if args.focus:
        res = pl.auto_detect_focus_batch(store.catalog_file(args.project), photos_dir_of(proj), overwrite=False)
        print(f"🎯 人臉焦點偵測：{res}")


def cmd_import(args):
    cmd = [sys.executable, str(ROOT / "analyze_batch_photos.py"), "import", "--project", args.project, "--input", *args.files]
    subprocess.run(cmd, check=True)


# ───────────────────────────────────────────────────────────────
# 階段 4：排程
# ───────────────────────────────────────────────────────────────

def cmd_manifest(args):
    pid = args.project
    proj = get_proj(pid)
    plan_path = store.content_plan_file(pid)
    if not plan_path.exists():
        die("尚未建立 content_plan，請先執行 plan")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    catalog = photos_lib.load_catalog(store.catalog_file(pid))
    photos = [p for p in catalog.get("photos", []) if p.get("analyzed")]
    if not photos:
        die("catalog 中沒有已分析的照片，請先完成階段 3")
    sp = {**store.DEFAULT_SLOT_PARAMS, **(proj.get("slot_params") or {})}
    assignments, stats = manifest_lib.assign_photos(plan["timeline"], catalog.get("photos", []),
                                                    protagonist_weight=float(args.protagonist_weight or sp.get("protagonist_weight", 2.5)))
    reasons = {}
    for a in assignments:
        r = (a.get("reason") or "").split(":")[0] or "?"
        reasons[r] = reasons.get(r, 0) + 1
    print(f"📊 分配來源：{reasons}")
    print(f"📊 統計：{json.dumps(stats, ensure_ascii=False)[:600]}")
    empty = sum(1 for a in assignments if str(a.get("reason") or "").startswith("EMPTY") or a.get("filename") in (None, "__MISSING__"))
    if args.report:
        print("（--report 模式：未寫入檔案）")
        return
    detail = manifest_lib.save_assignments(store.ordered_photos_detail_file(pid), store.ordered_photos_file(pid),
                                           plan, assignments, stats, catalog_photos=catalog.get("photos", []))
    set_status(pid, manifest_built=True)
    print(f"✅ ordered_photos.json 已寫入（總長 {detail.get('total_duration')}s）")
    if empty:
        print(f"❌ 有 {empty} 個時槽沒有照片（EMPTY），請補照片後重跑 scan → import → manifest")
    print("🔍 人工把關點 2：開啟 `python mvctl.py serve` →「照片分配」分頁檢查人物出場均衡與副歌靈魂照片，"
          "或使用 `python mvctl.py assign <ID> <slot_id> <檔名>` 手動替換。")


def cmd_assign(args):
    pid = args.project
    plan = json.loads(store.content_plan_file(pid).read_text(encoding="utf-8"))
    catalog = photos_lib.load_catalog(store.catalog_file(pid))
    assignments = manifest_lib.load_assignments(store.ordered_photos_detail_file(pid), plan, catalog.get("photos", []))
    hit = False
    for a in assignments:
        if str(a["slot_id"]) == str(args.slot_id):
            a["filename"], a["reason"], hit = args.filename, "MANUAL", True
    if not hit:
        die(f"找不到 slot_id={args.slot_id}")
    manifest_lib.save_assignments(store.ordered_photos_detail_file(pid), store.ordered_photos_file(pid),
                                  plan, assignments, catalog_photos=catalog.get("photos", []))
    print(f"✅ 時槽 {args.slot_id} → {args.filename}")


# ───────────────────────────────────────────────────────────────
# 階段 5：渲染
# ───────────────────────────────────────────────────────────────

def cmd_render(args):
    from lib import render as render_lib
    pid = args.project
    proj = get_proj(pid)
    ordered_path = store.ordered_photos_file(pid)
    if not ordered_path.exists():
        die("尚未完成排程，請先執行 manifest")
    ordered = json.loads(ordered_path.read_text(encoding="utf-8"))
    srt = store.resolved_srt_file(proj)
    out = Path(args.output).expanduser().resolve() if args.output else store.resolved_output_file(proj)
    if not getattr(args, "ignore_missing_glyphs", False):
        _check_render_font(proj)
    ctx = ConsoleCtx()
    try:
        from lib import gphotos as gphotos_lib
        gphotos_lib.download_selected_photos(pid, ctx=ctx)
    except Exception as e:  # Google 相簿為選用功能
        print(f"（略過 Google 相簿原圖下載：{e}）")
    result = render_lib.render_project(photos_dir_of(proj), srt, Path(proj["music_file"]), out,
                                       ordered, lyrics_lib.parse_srt(srt), ctx)
    store.update_project(pid, {"output_file": str(out)})
    set_status(pid, rendered=True)
    print(f"🎉 完成：{out}\n{json.dumps(ctx.result or result or {}, ensure_ascii=False)}")


def cmd_fonts(args):
    """下載 Noto Sans TC（SIL OFL 開源授權）到安裝資料夾，並檢查繁體字顯示。"""
    target = portable.APP_FONT_DIR / portable.NOTO_TC_FILE
    if target.exists() and not args.force:
        print(f"✅ 已有內建字型：{target}")
    else:
        print("⬇️ 下載 Noto Sans TC（約 12 MB，SIL Open Font License）…")
        try:
            dest = portable.download_noto_tc()
            print(f"✅ 已下載：{dest}")
        except Exception as e:
            print(f"⚠️ 下載失敗：{e}\n   可改用系統繁體字型（macOS 蘋方、Windows 微軟正黑體），或手動下載後設定 MV_FONT")
    sample = args.text or portable.TC_PROBE
    fc = portable.choose_cjk_font(sample)
    if fc is None:
        die("找不到任何中文字型")
    if fc.missing:
        die(f"字型 {fc} 仍缺：{''.join(fc.missing)}")
    print(f"🔤 將使用：{fc}，「{sample}」全部可正常顯示")


def _check_render_font(proj):
    """渲染前檢查：全部字幕文字都要畫得出來，否則停下來（避免整支影片出現方框字）。"""
    srt = store.resolved_srt_file(proj)
    text = "".join(e.get("text", "") for e in lyrics_lib.parse_srt(srt)) if srt.exists() else ""
    title_bits = " ".join(str(v) for v in (proj.get("event_info") or {}).values() if isinstance(v, str))
    fc = portable.choose_cjk_font(text + title_bits)
    if fc is None or fc.missing:
        missing = "".join(fc.missing) if fc else "（全部中文）"
        die(f"字幕字型缺字：{missing}。請執行 `mvctl fonts` 下載 Noto Sans TC，或設定 MV_FONT 指向繁體中文字型；"
            f"確定要照樣輸出請加 --ignore-missing-glyphs")
    print(f"🔤 字幕字型檢查通過：{fc}")


def cmd_serve(args):
    cmd = [venv_python(), str(STUDIO_DIR / "server.py"), "--port", str(args.port)]
    if args.lan:
        cmd.append("--lan")
    os.execv(cmd[0], cmd) if os.name != "nt" else sys.exit(subprocess.call(cmd))


# ───────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="照片回憶 MV 製作流程 CLI（MV Studio）")
    sp = ap.add_subparsers(dest="cmd", required=True)

    sp.add_parser("doctor", help="檢查執行環境")
    sp.add_parser("projects", help="列出專案")

    p = sp.add_parser("new", help="建立新專案")
    p.add_argument("--name", required=True)
    p.add_argument("--song")
    p.add_argument("--music")
    p.add_argument("--lyrics", help="正確歌詞 .txt")
    p.add_argument("--photos", help="照片資料夾（不指定則用專案內 photos/）")
    p.add_argument("--output", help="輸出 MP4 路徑")

    p = sp.add_parser("set", help="修改專案設定 key=value")
    p.add_argument("project")
    p.add_argument("pairs", nargs="+")

    p = sp.add_parser("status", help="顯示階段進度與下一步")
    p.add_argument("project")

    p = sp.add_parser("event", help="階段 0：活動前籌備（主題、小隊、拍攝清單、片頭片尾、上傳連結）")
    p.add_argument("project")
    p.add_argument("--event-name")
    p.add_argument("--date", help="開始日期 YYYY-MM-DD")
    p.add_argument("--end-date", help="多日活動的最後一天 YYYY-MM-DD（單日活動不用）")
    p.add_argument("--location")
    p.add_argument("--organizer")
    p.add_argument("--slogan")
    p.add_argument("--schedule", help="流程表文字或檔案（每行 HH:MM-HH:MM 環節名稱；多日活動每天前加一行日期如 11/20 或 Day 2）")
    p.add_argument("--handbook", help="活動手冊文字或檔案（含小隊名單）")
    p.add_argument("--promo", help="宣傳文案文字或檔案")
    p.add_argument("--public-url", help="Cloudflare Tunnel / ngrok 公網網址（選用）")
    p.add_argument("--port", type=int, default=8787)

    p = sp.add_parser("align", help="階段 1：歌詞強制對齊")
    p.add_argument("project")
    p.add_argument("--model", default="medium", help="Whisper 模型 small/medium/large（預設 medium）")

    p = sp.add_parser("themes", help="階段 2：設定主題標籤")
    p.add_argument("project")
    p.add_argument("--set", help='例："Intro=報到,相見|Game=闖關,遊戲|Outro=合照,謝謝"')
    p.add_argument("--template", action="store_true", help="套用範例模板")
    p.add_argument("--from-lyrics", action="store_true", help="分析歌詞給主題建議")

    p = sp.add_parser("map", help="階段 2：逐行歌詞指派主題")
    p.add_argument("project")
    p.add_argument("--suggest", action="store_true")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--assign", nargs="*", help="例：3=Intro 7=Game")

    p = sp.add_parser("plan", help="階段 2：產生 content_plan.json")
    p.add_argument("project")
    p.add_argument("--no-beat-snap", action="store_true")

    p = sp.add_parser("scan", help="階段 3：掃描照片、產生 subagent_task.json")
    p.add_argument("project")
    p.add_argument("--focus", action="store_true", help="同時自動偵測人臉焦點")

    p = sp.add_parser("import", help="階段 3：匯入視覺分析 JSON")
    p.add_argument("project")
    p.add_argument("files", nargs="+")

    p = sp.add_parser("manifest", help="階段 4：三優先排程")
    p.add_argument("project")
    p.add_argument("--report", action="store_true", help="只顯示覆蓋率，不寫檔")
    p.add_argument("--protagonist-weight", type=float)

    p = sp.add_parser("assign", help="階段 4：手動指定某時槽照片")
    p.add_argument("project")
    p.add_argument("slot_id")
    p.add_argument("filename")

    p = sp.add_parser("render", help="階段 5：渲染 MP4")
    p.add_argument("project")
    p.add_argument("--output")
    p.add_argument("--ignore-missing-glyphs", action="store_true", help="字幕有缺字仍照樣輸出（不建議）")

    p = sp.add_parser("fonts", help="下載內建 Noto Sans TC 並檢查繁體字是否能正常顯示")
    p.add_argument("--force", action="store_true", help="重新下載")
    p.add_argument("--text", help="額外要檢查的文字，例如活動名稱或歌詞")

    p = sp.add_parser("link", help="連結雲端收照片活動（同步網址＋同步金鑰）")
    p.add_argument("project")
    p.add_argument("--event", required=True, help="同步網址 https://<主機>/api/sync/<event_id>")
    p.add_argument("--key", required=True, help="同步金鑰")

    p = sp.add_parser("sync", help="從雲端下載新照片到專案照片資料夾")
    p.add_argument("project")
    p.add_argument("--watch", action="store_true", help="持續同步（Ctrl+C 結束）")
    p.add_argument("--interval", type=int, default=300, help="--watch 的間隔秒數（預設 300，最少 10）")

    p = sp.add_parser("push-requirements", help="把 content_plan 的各主題需求張數回寫雲端拍攝清單")
    p.add_argument("project")

    p = sp.add_parser("serve", help="啟動 MV Studio 網頁介面")
    p.add_argument("--port", type=int, default=8787)
    p.add_argument("--lan", action="store_true", help="開放同 Wi-Fi 手機上傳")

    args = ap.parse_args()
    {
        "doctor": cmd_doctor, "projects": cmd_projects, "new": cmd_new, "set": cmd_set, "status": cmd_status,
        "event": cmd_event, "align": cmd_align, "themes": cmd_themes, "map": cmd_map, "plan": cmd_plan,
        "scan": cmd_scan, "import": cmd_import, "manifest": cmd_manifest, "assign": cmd_assign,
        "render": cmd_render, "serve": cmd_serve, "fonts": cmd_fonts,
        "link": cmd_link, "sync": cmd_sync, "push-requirements": cmd_push_requirements,
    }[args.cmd](args)


if __name__ == "__main__":
    main()
