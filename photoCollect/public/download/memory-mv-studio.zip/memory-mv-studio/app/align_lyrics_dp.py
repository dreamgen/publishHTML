#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
歌詞自動精準對位工具 (DP + Pinyin 增強版)
用途：將音訊 (mp3, wav, m4a, flac 等) 利用 Whisper 轉錄，配合歌詞 TXT 進行字元/拼音雙重全域動態規劃對齊 (Dynamic Programming Alignment)。
     能完美處理中文同音異字、語音辨識錯誤，生成時間軸 100% 精準對齊的繁體中文 SRT 字幕及校對影片。
"""

import os
import re
import sys

# Windows 終端機預設可能是 Big5/cp950：統一輸出 UTF-8，避免中文／emoji 亂碼或 UnicodeEncodeError
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import json
import argparse
import subprocess
import numpy as np
from pypinyin import lazy_pinyin

# ── 預設設定 ──────────────────────────────────────────────
DEFAULT_MODEL_SIZE   = "medium"
DEFAULT_LANGUAGE     = "zh"
AUDIO_EXTENSIONS     = ('.mp3', '.wav', '.m4a', '.flac', '.aac', '.ogg')

def get_media_duration(file_path):
    """獲取音訊或影片檔案的精確長度（秒）"""
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(file_path)
    ]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", check=True)
        return float(result.stdout.strip())
    except Exception:
        return 0.0

def format_srt_timestamp(seconds: float) -> str:
    """將秒數格式化為 SRT 時間戳格式 (HH:MM:SS,mmm)"""
    if seconds < 0:
        seconds = 0.0
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    if ms >= 1000:
        s += 1
        ms -= 1000
    if s >= 60:
        m += 1
        s -= 60
    if m >= 60:
        h += 1
        m -= 60
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def load_lyrics(lyrics_path: str) -> list[str]:
    """讀取歌詞檔案，並過濾結構標籤 (如 [Intro], [Verse])"""
    encodings = ["utf-8", "big5", "gb18030", "utf-16", "utf-8-sig"]
    content = None
    for enc in encodings:
        try:
            with open(lyrics_path, "r", encoding=enc) as f:
                content = f.read()
            break
        except (UnicodeDecodeError, LookupError):
            continue
            
    if content is None:
        with open(lyrics_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
            
    raw_lines = content.splitlines()
    clean_lines = []
    for line in raw_lines:
        l = line.strip()
        if not l:
            continue
        # 過濾結構標籤
        if l.startswith('[') and l.endswith(']'):
            continue
        if l.startswith('(') and l.endswith(')'):
            continue
        clean_lines.append(l)
    return clean_lines

def build_chars_from_words(segments):
    """將 Whisper segments (含 word_timestamps) 展開成帶有時間戳記的單個字元流"""
    T_chars = []
    for segment in segments:
        if "words" in segment and segment["words"]:
            for w in segment["words"]:
                word_text = w["word"].strip()
                # 僅保留中文字元與英文字母/數字
                word_clean = [c for c in word_text if c.isalnum() or '\u4e00' <= c <= '\u9fff']
                if not word_clean:
                    continue
                w_start = w["start"]
                w_end = w["end"]
                n = len(word_clean)
                duration = max(0.01, w_end - w_start)
                for idx, c in enumerate(word_clean):
                    c_start = w_start + idx * (duration / n)
                    c_end = w_start + (idx + 1) * (duration / n)
                    T_chars.append({
                        "char": c,
                        "start": c_start,
                        "end": c_end
                    })
        else:
            # 降級使用 segment-level 轉錄文字
            seg_text = segment["text"].strip()
            seg_clean = [c for c in seg_text if c.isalnum() or '\u4e00' <= c <= '\u9fff']
            if not seg_clean:
                continue
            s_start = segment["start"]
            s_end = segment["end"]
            n = len(seg_clean)
            duration = max(0.01, s_end - s_start)
            for idx, c in enumerate(seg_clean):
                c_start = s_start + idx * (duration / n)
                c_end = s_start + (idx + 1) * (duration / n)
                T_chars.append({
                    "char": c,
                    "start": c_start,
                    "end": c_end
                })
    return T_chars

# 拼音快取優化
pinyin_cache = {}
def get_char_pinyin(c):
    if c not in pinyin_cache:
        p = lazy_pinyin(c)
        pinyin_cache[c] = p[0] if p else ""
    return pinyin_cache[c]

def score_match(c_target, c_trans):
    """計算兩個字元之間的匹配得分（支援字元一致與拼音同音匹配）"""
    if c_target == c_trans:
        return 2.0
    if c_target.lower() == c_trans.lower():
        return 2.0
    # 僅對中文字元進行同音字匹配
    if '\u4e00' <= c_target <= '\u9fff' and '\u4e00' <= c_trans <= '\u9fff':
        py_target = get_char_pinyin(c_target)
        py_trans = get_char_pinyin(c_trans)
        if py_target and py_target == py_trans:
            return 1.5 # 拼音同音匹配
    return -1.0 # 錯字懲罰

def align_lyrics_dp(clean_lines, T_chars):
    """
    使用 Needleman-Wunsch 演算法進行全域動態規劃對齊，
    將轉錄字元流 (T_chars) 對位至基準歌詞字元流 (L_chars)。
    """
    # 建立基準歌詞字元清單
    L_chars = []
    for line_idx, line in enumerate(clean_lines):
        for char in line:
            if char.isalnum() or '\u4e00' <= char <= '\u9fff':
                L_chars.append((char, line_idx))

    N = len(L_chars)
    M = len(T_chars)
    
    if N == 0 or M == 0:
        return {}

    print(f"🔗 正在進行全域 DP 序列對齊 (歌詞字數: {N}, 轉錄字數: {M})...")
    
    # 建立與填寫 DP 表
    dp = np.zeros((N + 1, M + 1), dtype=np.float32)
    for i in range(1, N + 1):
        dp[i, 0] = dp[i-1, 0] - 1.5
    for j in range(1, M + 1):
        dp[0, j] = dp[0, j-1] - 1.5

    for i in range(1, N + 1):
        c_t = L_chars[i-1][0]
        for j in range(1, M + 1):
            c_tr = T_chars[j-1]["char"]
            match_score = score_match(c_t, c_tr)
            
            score_diag = dp[i-1, j-1] + match_score
            score_up = dp[i-1, j] - 1.5
            score_left = dp[i, j-1] - 1.5
            
            dp[i, j] = max(score_diag, score_up, score_left)

    # 進行 Traceback 尋找最佳路徑
    i, j = N, M
    alignment = []
    while i > 0 or j > 0:
        if i > 0 and j > 0:
            c_t = L_chars[i-1][0]
            c_tr = T_chars[j-1]["char"]
            match_score = score_match(c_t, c_tr)
            if abs(dp[i, j] - (dp[i-1, j-1] + match_score)) < 1e-4:
                alignment.append((i-1, j-1))
                i -= 1
                j -= 1
                continue
        if i > 0 and abs(dp[i, j] - (dp[i-1, j] - 1.5)) < 1e-4:
            alignment.append((i-1, None))
            i -= 1
            continue
        if j > 0 and abs(dp[i, j] - (dp[i, j-1] - 1.5)) < 1e-4:
            alignment.append((None, j-1))
            j -= 1
            continue

    alignment.reverse()

    # 依歌詞行索引分組收集對應的轉錄時間戳記
    line_mappings = {}
    for L_idx, T_idx in alignment:
        if L_idx is not None and T_idx is not None:
            _, line_idx = L_chars[L_idx]
            t_char = T_chars[T_idx]
            if line_idx not in line_mappings:
                line_mappings[line_idx] = []
            line_mappings[line_idx].append(t_char)

    return line_mappings

def generate_srt(clean_lines, line_mappings, out_srt_path):
    """將對齊後的時間戳記寫出為標準 SRT 格式，並防範時間重疊與極短區間"""
    subtitles = []
    
    # 1. 提取所有對齊成功的字幕行
    for line_idx, line in enumerate(clean_lines):
        if line_idx in line_mappings and line_mappings[line_idx]:
            mapped = line_mappings[line_idx]
            start = min(c["start"] for c in mapped)
            end = max(c["end"] for c in mapped)
            
            # 確保有最小顯示時長 (例如 1.0 秒)
            if end - start < 1.0:
                end = start + 1.0
                
            subtitles.append({
                "line_idx": line_idx,
                "start": start,
                "end": end,
                "text": line
            })
            
    # 2. 避免字幕區間重疊 (Overlap Resolution)
    for idx in range(len(subtitles) - 1):
        curr_sub = subtitles[idx]
        next_sub = subtitles[idx + 1]
        if curr_sub["end"] > next_sub["start"]:
            # 若重疊，將當前字幕的結束時間調整為下一個字幕的開始時間
            overlap = curr_sub["end"] - next_sub["start"]
            if overlap < 0.5:
                curr_sub["end"] = next_sub["start"]
            else:
                # 較大的重疊，平分邊界
                mid = (curr_sub["end"] + next_sub["start"]) / 2
                curr_sub["end"] = mid
                next_sub["start"] = mid
                
    # 3. 輸出為檔案
    with open(out_srt_path, "w", encoding="utf-8") as f:
        for idx, sub in enumerate(subtitles, 1):
            f.write(f"{idx}\n")
            f.write(f"{format_srt_timestamp(sub['start'])} --> {format_srt_timestamp(sub['end'])}\n")
            f.write(f"{sub['text']}\n\n")
            
    print(f"💾 已成功寫出精確對齊之 SRT 字幕檔：{out_srt_path}")

def generate_calibration_video(audio_path, srt_path, output_mp4):
    """利用 FFmpeg 快速產出包含時間碼與外掛字幕的校對用 MP4 影片"""
    print("\n⏳ 正在生成校對專用影片...")
    duration = get_media_duration(audio_path)
    if duration <= 0:
        duration = 240.0 # 預設 4 分鐘
        
    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", f"testsrc=duration={duration:.3f}:size=1280x720:rate=30",
        "-i", audio_path,
        "-i", srt_path,
        "-map", "0:v",
        "-map", "1:a",
        "-map", "2:s",
        *(["-c:v", "h264_videotoolbox", "-b:v", "4000k"] if sys.platform == "darwin" else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "28"]), "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "128k",
        "-c:s", "mov_text",
        "-shortest",
        output_mp4
    ]
    
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print(f"🎉 校對影片製作成功！")
        print(f"💾 輸出檔案位置：{os.path.abspath(output_mp4)}")
        print(f"💡 說明：播放影片時開啟字幕軌 (Subtitles)，即可在画面上核對歌詞與運行時間碼。")
    except Exception as e:
        print(f"⚠️ 警告：無法使用 FFmpeg 建立校對影片（跳過此步）。")

def main():
    parser = argparse.ArgumentParser(description="歌詞自動精準對位工具 (DP + Pinyin 增強版)")
    parser.add_argument("audio", nargs="?", help="輸入的音訊檔案路徑 (支援 mp3, wav, m4a, flac 等)")
    parser.add_argument("lyrics", nargs="?", help="基準歌詞 TXT 檔案路徑")
    parser.add_argument("--model", default=DEFAULT_MODEL_SIZE, help=f"Whisper 模型大小，預設為 '{DEFAULT_MODEL_SIZE}'")
    parser.add_argument("--raw-json", help="使用已轉錄的 Whisper raw json 檔案，跳過轉錄流程")
    
    args = parser.parse_args()
    
    audio_file = args.audio
    lyrics_file = args.lyrics
    
    # 自動搜尋音訊檔案
    if not audio_file:
        audios = sorted([f for f in os.listdir(".") if f.lower().endswith(AUDIO_EXTENSIONS)])
        if len(audios) == 1:
            audio_file = audios[0]
        elif len(audios) > 1:
            audio_file = audios[0] # 預設使用第一個
            
    if not audio_file:
        print(f"❌ 錯誤：在此目錄下找不到音訊檔案！")
        exit(1)
        
    # 自動搜尋歌詞檔案
    if not lyrics_file:
        base_name = os.path.splitext(audio_file)[0]
        possible_lyrics = [
            f"{base_name}_歌詞.txt",
            f"{base_name}歌詞.txt",
            f"{base_name}.txt",
        ]
        for candidate in possible_lyrics:
            if os.path.exists(candidate):
                lyrics_file = candidate
                break
        if not lyrics_file:
            txts = sorted([f for f in os.listdir(".") if f.lower().endswith(".txt") and not f.endswith("_report.txt")])
            if txts:
                lyrics_file = txts[0]
                
    if not lyrics_file or not os.path.exists(lyrics_file):
        print(f"❌ 錯誤：找不到基準歌詞 TXT 檔案！")
        exit(1)
        
    base_name_only = os.path.splitext(os.path.basename(audio_file))[0]
    out_srt = f"{base_name_only}_generated.srt"
    out_video = f"{base_name_only}_校對用.mp4"
    
    print("=" * 60)
    print("     🎵 歌詞自動精準校對與對齊工具 (DP+Pinyin 版) 🎵")
    print("=" * 60)
    print(f"  - 音訊檔案：'{audio_file}'")
    print(f"  - 歌詞檔案：'{lyrics_file}'")
    print(f"  - 模型大小：'{args.model}'")
    print("-" * 60)
    
    # 載入歌詞
    clean_lines = load_lyrics(lyrics_file)
    print(f"📖 已載入歌詞：共 {len(clean_lines)} 行")
    
    # 取得轉錄結果
    if args.raw_json and os.path.exists(args.raw_json):
        print(f"📖 正在讀取已轉錄的 raw JSON：{args.raw_json}")
        with open(args.raw_json, "r", encoding="utf-8") as f:
            result = json.load(f)
    else:
        # 使用 lyrics 引導 prompt 來進行轉錄，避開首段幻聽或漏字
        prompt_lyrics = " ".join(clean_lines[:4])
        print(f"🎙️ 載入 Whisper '{args.model}' 模型並開始轉錄 (初期提示詞: '{prompt_lyrics[:40]}...')...")
        
        import whisper
        model = whisper.load_model(args.model)
        result = model.transcribe(
            audio_file,
            language=DEFAULT_LANGUAGE,
            verbose=False,
            word_timestamps=True,
            initial_prompt=prompt_lyrics
        )
        
        # 暫存一份 raw json
        raw_json_cache = f"{base_name_only}_raw.json"
        with open(raw_json_cache, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"💾 已儲存 Whisper 轉錄快取至：{raw_json_cache}")
        
    # 解析字元流
    T_chars = build_chars_from_words(result["segments"])
    
    # DP 動態規劃對齊
    line_mappings = align_lyrics_dp(clean_lines, T_chars)
    
    # 產出 SRT
    generate_srt(clean_lines, line_mappings, out_srt)
    
    # 產出影片
    generate_calibration_video(audio_file, out_srt, out_video)
    
    print("\n✨ 對齊作業圓滿完成！")

if __name__ == "__main__":
    main()
