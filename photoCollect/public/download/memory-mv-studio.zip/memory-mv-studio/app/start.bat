@echo off
rem Double-click to start MV Studio in your browser (Windows)
rem For LAN phone upload, run: start.bat --lan
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" serve %*
if errorlevel 1 pause
