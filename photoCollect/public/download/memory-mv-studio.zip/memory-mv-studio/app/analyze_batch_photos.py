#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_batch_photos.py
========================
Phase 2/4: 分批掃描照片並將 Agent / Subagents 的視覺分析結果匯入 photo_catalog.json。
現已完整整合 MV Studio 多專案系統（支援 `--project <project_id>`），同時向下相容舊版根目錄 CLI 模式。

子命令：
  projects -- 列出 MV Studio 中所有專案的 ID、名稱、主題與照片分析進度
  scan     -- 掃描目錄（或指定 MV Studio 專案），產生縮圖與 Subagent 分組任務檔
  prompt   -- 輸出指定專案的 Subagent 視覺分析 Prompt（可指定 --shard）
  import   -- 將一或多個 Subagent 分析的 JSON 結果檔匯入 catalog
  status   -- 顯示目前 catalog 的統計狀態與主題覆蓋率（可指定 --project）
  list     -- 列出所有已收錄照片（可依 --project 與 --theme 過濾）

MV Studio 專案模式執行範例：
  python analyze_batch_photos.py projects
  python analyze_batch_photos.py scan --project proj_parent_child_best
  python analyze_batch_photos.py prompt --project proj_parent_child_best --shard 1
  python analyze_batch_photos.py import --project proj_parent_child_best --input /tmp/sub1.json /tmp/sub2.json
  python analyze_batch_photos.py status --project proj_parent_child_best

舊版單一目錄模式執行範例：
  python analyze_batch_photos.py scan --dir /path/to/photos --batch-id 1
  python analyze_batch_photos.py import --input scan_batch01.json
"""

import os
import json
import argparse
import sys

# Windows 終端機預設可能是 Big5/cp950：統一輸出 UTF-8，避免中文／emoji 亂碼或 UnicodeEncodeError
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
from pathlib import Path
from datetime import datetime, timezone, timedelta

ROOT_DIR = Path(__file__).resolve().parent
STUDIO_DIR = ROOT_DIR / "mv_studio"
if STUDIO_DIR.exists():
    sys.path.insert(0, str(STUDIO_DIR))
    from lib import store as studio_store, photos as studio_photos, subagent_batch as subagent_lib  # noqa: E402
else:
    studio_store = None
    studio_photos = None
    subagent_lib = None

# ═══════════════════════════════════════════════════════════════
# 🔧 舊版單一專案設定（向下相容）
# ═══════════════════════════════════════════════════════════════

CATALOG_FILE = ROOT_DIR / "photo_catalog.json"
CATALOG_VERSION = "1.1"

ALL_THEMES = [
    "Intro", "English", "Manners", "Emotions",
    "Classics", "Quiz", "BeachClean", "WarmWords", "Outro"
]
PHOTO_EXTS = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".gif", ".webp"}

SLIDE_DEFAULT_THEMES: dict[str, str] = {
    "投影片1": "Intro",
    "投影片2": "Intro",
    "投影片3": "Emotions",
    "投影片4": "Emotions",
    "投影片5": "BeachClean",
    "投影片6": "WarmWords",
    "快樂成長營-1": "Intro",
    "快樂成長營-2": "Intro",
    "圖片 1":  "WarmWords",
    "圖片3":   "WarmWords",
    "圖片4":   "WarmWords",
    "圖片5":   "WarmWords",
}

SKIP_FILENAMES = {"片頭.png", "片尾.png", "ordered_photos.json", "ordered_photos_detail.json", ".DS_Store"}


def _now_tw() -> str:
    return datetime.now(tz=timezone(timedelta(hours=8))).isoformat(timespec="seconds")


def _resolve_studio_project(project_arg: str) -> tuple[str, dict]:
    """支援以完整 project_id、前綴或專案名稱模糊查找 MV Studio 專案。"""
    if studio_store is None:
        print("❌ 找不到 mv_studio 模組。")
        sys.exit(1)
    try:
        proj = studio_store.get_project(project_arg)
        return proj["id"], proj
    except FileNotFoundError:
        pass

    # 嘗試以前綴或名稱搜尋
    for p in studio_store.list_projects():
        if p["id"].startswith(project_arg) or p.get("name") == project_arg or p.get("song_title") == project_arg:
            return p["id"], p

    print(f"❌ 找不到 MV Studio 專案：'{project_arg}'")
    print("💡 請執行 `python analyze_batch_photos.py projects` 查看所有可用專案。")
    sys.exit(1)


# ═══════════════════════════════════════════════════════════════
# 🛠️ 舊版 Catalog 讀寫與 EXIF 工具
# ═══════════════════════════════════════════════════════════════

def load_catalog() -> dict:
    if CATALOG_FILE.exists():
        return json.loads(CATALOG_FILE.read_text(encoding="utf-8"))
    return {
        "catalog_version": CATALOG_VERSION,
        "last_updated": _now_tw(),
        "total_photos": 0,
        "photos": [],
    }


def save_catalog(catalog: dict):
    catalog["last_updated"] = _now_tw()
    catalog["total_photos"] = len(catalog["photos"])
    CATALOG_FILE.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")


def catalog_filenames(catalog: dict) -> set[str]:
    return {p["filename"] for p in catalog["photos"]}


def get_exif_time(path: Path) -> str | None:
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS
        img = Image.open(path)
        exif_data = img._getexif()
        if exif_data:
            for tag_id, value in exif_data.items():
                if TAGS.get(tag_id) == "DateTimeOriginal":
                    dt = datetime.strptime(str(value), "%Y:%m:%d %H:%M:%S")
                    return dt.isoformat(timespec="seconds")
    except Exception:
        pass
    return None


def get_file_mtime(path: Path) -> str:
    ts = path.stat().st_mtime
    dt = datetime.fromtimestamp(ts, tz=timezone(timedelta(hours=8)))
    return dt.isoformat(timespec="seconds")


def get_image_dims(path: Path) -> tuple[int, int] | None:
    try:
        from PIL import Image
        with Image.open(path) as img:
            return img.size
    except Exception:
        return None


def detect_slide_theme(stem: str) -> str | None:
    for key, theme in SLIDE_DEFAULT_THEMES.items():
        if stem == key or stem.startswith(key):
            return theme
    return None


# ═══════════════════════════════════════════════════════════════
# 🗂️ projects 子命令（列出 MV Studio 專案）
# ═══════════════════════════════════════════════════════════════

def cmd_projects(args):
    if studio_store is None:
        print("❌ 找不到 mv_studio 目錄。")
        return
    projects = studio_store.list_projects()
    if not projects:
        print("📭 目前 MV Studio 中尚無任何專案。")
        return

    print("\n🎬 MV Studio 專案清單")
    print("=" * 80)
    print(f"  {'專案 ID':<26} {'專案名稱 / 曲名':<22} {'已分析/總數':<12} {'主題數'}")
    print("─" * 80)
    for p in projects:
        pid = p["id"]
        cat = studio_photos.load_catalog(studio_store.catalog_file(pid))
        total = len(cat.get("photos", []))
        analyzed = sum(1 for x in cat.get("photos", []) if x.get("analyzed"))
        themes = [t["name"] for t in p.get("themes", [])]
        title = p.get("song_title") or p.get("name") or pid
        print(f"  {pid:<26} {title[:20]:<22} {f'{analyzed}/{total}':<12} {len(themes)} ({', '.join(themes[:4])}{'…' if len(themes) > 4 else ''})")
        if p.get("photos_dir"):
            print(f"     📁 照片目錄：{p['photos_dir']}")
    print("=" * 80)
    print("💡 執行範例：python analyze_batch_photos.py scan --project <專案ID>\n")


# ═══════════════════════════════════════════════════════════════
# 📋 scan 子命令（支援 --project 與舊版 --dir）
# ═══════════════════════════════════════════════════════════════

def cmd_scan(args):
    if args.project:
        pid, proj = _resolve_studio_project(args.project)
        task_data = subagent_lib.prepare_subagent_task(
            project_id=pid,
            proj=proj,
            scan_first=True,
            max_per_agent=args.max_per_agent,
            max_photos=args.max_photos,
            reanalyze_all=args.reanalyze,
        )
        stats = task_data["stats"]
        shards = task_data["shards"]
        print("\n" + "=" * 72)
        print(f"  🚀 MV Studio Subagent 批次視覺分析準備完成")
        print("=" * 72)
        print(f"  專案名稱：{proj.get('name')} ({pid})")
        print(f"  照片目錄：{task_data['photos_dir']}")
        if task_data.get("scan_info"):
            print(f"  本次新掃描加入：{task_data['scan_info']['added_pending']} 張")
        print(f"  Catalog 狀態：共 {stats['total_photos']} 張（已分析 {stats['analyzed_photos']} 張，待分析 {stats['pending_photos']} 張）")
        print(f"  建議派發 Subagent 數：{stats['recommended_subagents']} 個（每組上限 {stats['max_per_agent']} 張）")
        print(f"  任務定義檔：{task_data['task_file']}")
        print("─" * 72)

        if not shards:
            print("  ✅ 所有照片皆已完成分析！若要重新分析請加上 `--reanalyze`。")
            return

        print("  📦 Subagent 分組明細（已預先建立 640px 高速縮圖 thumb_path）：")
        for s in shards:
            preview = ", ".join(s["filenames"][:4])
            if len(s["filenames"]) > 4:
                preview += f" ... 共 {s['photo_count']} 張"
            print(f"    • Shard #{s['shard_id']}: {s['photo_count']:>2} 張  [{preview}]")

        print("─" * 72)
        print("  🤖 下一步指令：")
        print(f"  1. 查看各組 Subagent Prompt：")
        print(f"     python analyze_batch_photos.py prompt --project {pid} --shard 1")
        print(f"  2. 匯入 Subagent 分析完成的 JSON（支援一次傳入多個檔案）：")
        print(f"     python analyze_batch_photos.py import --project {pid} --input /tmp/sub1.json /tmp/sub2.json")
        print("=" * 72 + "\n")
        return

    # ── 舊版 --dir 邏輯 ──
    if not args.dir:
        print("❌ 請指定 `--project <MV Studio 專案ID>` 或 `--dir <照片目錄路徑>`")
        sys.exit(1)

    photo_dir = Path(args.dir)
    if not photo_dir.exists():
        print(f"❌ 找不到目錄：{photo_dir}")
        sys.exit(1)

    batch_id = args.batch_id
    catalog = load_catalog()
    known = catalog_filenames(catalog)

    new_photos = []
    for f in sorted(photo_dir.iterdir()):
        if f.name in SKIP_FILENAMES:
            continue
        if f.suffix.lower() not in PHOTO_EXTS:
            continue
        if f.name in known:
            continue
        new_photos.append(f)

    if not new_photos:
        print(f"✅ 目錄 '{photo_dir.name}' 中所有照片已在 catalog 中，無新照片。")
        print(f"   目前 catalog 共有 {len(catalog['photos'])} 張照片。")
        return

    print(f"\n🔍 掃描目錄：{photo_dir}")
    print(f"   發現 {len(new_photos)} 張新照片（Batch #{batch_id}）\n")

    scan_results = []
    for idx, f in enumerate(new_photos, 1):
        stem = f.stem
        slide_theme = detect_slide_theme(stem)
        is_slide = slide_theme is not None
        exif_time = get_exif_time(f)
        mtime = get_file_mtime(f)
        dims = get_image_dims(f)
        size_kb = round(f.stat().st_size / 1024, 1)

        entry = {
            "filename": f.name,
            "abs_path": str(f.resolve()),
            "batch_id": batch_id,
            "is_slide": is_slide,
            "slide_default_theme": slide_theme,
            "exif_time": exif_time,
            "file_mtime": mtime,
            "dims": list(dims) if dims else None,
            "size_kb": size_kb,
        }
        scan_results.append(entry)

        if is_slide:
            status = f"📊 投影片（預設主題：{slide_theme}）"
        else:
            status = f"📷 拍攝時間：{exif_time or mtime}"

        w, h = (dims if dims else ("?", "?"))
        print(f"  [{idx:02d}] {f.name}")
        print(f"       {status}")
        print(f"       尺寸：{w}×{h}  大小：{size_kb} KB\n")

    scan_output = {
        "batch_id": batch_id,
        "batch_dir": str(photo_dir.resolve()),
        "scanned_at": _now_tw(),
        "new_photos": scan_results,
        "analyses": []
    }
    scan_file = ROOT_DIR / f"scan_batch{batch_id:02d}.json"
    scan_file.write_text(json.dumps(scan_output, ensure_ascii=False, indent=2), encoding="utf-8")

    print("─" * 60)
    print(f"📄 掃描結果已存至：{scan_file}")
    print(f"   完成後執行：python analyze_batch_photos.py import --input {scan_file}")

    auto_slides = [p for p in scan_results if p["is_slide"]]
    if auto_slides:
        auto_import_slides(auto_slides, catalog)
        save_catalog(catalog)
        print(f"   ✅ 已自動匯入 {len(auto_slides)} 張投影片。")


def auto_import_slides(slides: list[dict], catalog: dict):
    known = catalog_filenames(catalog)
    for s in slides:
        if s["filename"] in known:
            continue
        theme = s["slide_default_theme"]
        fit_scores = {t: (10.0 if t == theme else 2.0) for t in ALL_THEMES}
        catalog["photos"].append({
            "filename": s["filename"],
            "abs_path": s["abs_path"],
            "exif_time": s.get("exif_time"),
            "file_mtime": s.get("file_mtime"),
            "dims": s.get("dims"),
            "size_kb": s.get("size_kb"),
            "batch_id": s["batch_id"],
            "is_slide": True,
            "theme": theme,
            "description": f"課程投影片（{theme}）",
            "quality_score": 9.0,
            "fit_scores": fit_scores,
            "analyzed": True,
            "auto_tagged": True,
        })


# ═══════════════════════════════════════════════════════════════
# 📝 prompt 子命令（輸出 Subagent 專屬 Prompt）
# ═══════════════════════════════════════════════════════════════

def cmd_prompt(args):
    pid, proj = _resolve_studio_project(args.project)
    task_file = studio_store.project_dir(pid) / "subagent_task.json"
    if not task_file.exists():
        task_data = subagent_lib.prepare_subagent_task(project_id=pid, proj=proj, scan_first=True)
    else:
        task_data = json.loads(task_file.read_text(encoding="utf-8"))

    shards = task_data.get("shards", [])
    if not shards:
        print("✅ 目前沒有待分析的照片 Shard。")
        return

    for s in shards:
        if args.shard is not None and s["shard_id"] != args.shard:
            continue
        if args.shard is None:
            print(f"\n{'=' * 30} SHARD #{s['shard_id']} ({s['photo_count']} 張) {'=' * 30}")
        print(s["prompt"])


# ═══════════════════════════════════════════════════════════════
# 📥 import 子命令（支援 --project 多檔案匯入 & 舊版單檔匯入）
# ═══════════════════════════════════════════════════════════════

def cmd_import(args):
    input_files = args.input if isinstance(args.input, list) else [args.input]

    if args.project:
        pid, proj = _resolve_studio_project(args.project)
        all_analyses = []
        for fpath in input_files:
            p = Path(fpath)
            if not p.exists():
                print(f"❌ 找不到輸入檔案：{p}")
                sys.exit(1)
            raw = p.read_text(encoding="utf-8")
            extracted = subagent_lib.parse_raw_json_input(raw)
            print(f"📄 從 {p.name} 讀取到 {len(extracted)} 筆分析結果")
            all_analyses.extend(extracted)

        if not all_analyses:
            print("⚠️  未在輸入檔案中找到有效的 analyses 資料。")
            return

        res = subagent_lib.import_subagent_analyses(
            project_id=pid,
            proj=proj,
            analyses=all_analyses,
            overwrite=not args.no_overwrite,
            source_label="subagent",
        )
        print("\n" + "=" * 68)
        print(f"  🎉 已匯入 MV Studio 專案：{proj.get('name')} ({pid})")
        print("=" * 68)
        print(f"  新增分析：{res['imported_new']} 張  |  更新既有：{res['updated_existing']} 張  |  略過：{res['skipped']} 張")
        print(f"  Catalog 總進度：{res['total_analyzed']} / {res['total_in_catalog']} 張已分析（剩餘待分析：{res['pending_remaining']} 張）")
        if res["errors"]:
            print(f"  ⚠️  錯誤 ({len(res['errors'])})：{', '.join(res['errors'][:5])}")
        print("─" * 68)
        print(f"  {'主題':<14} {'已分析張數':>10} {'時槽需求':>10} {'狀態'}")
        print("  " + "─" * 52)
        for theme, cov in res["theme_coverage"].items():
            need_str = f"{cov['photos_needed']} 張" if cov["photos_needed"] > 0 else "—"
            if cov["photos_needed"] > 0:
                status_str = "✅ 足夠" if cov["sufficient"] else f"⚠️  缺 {cov['deficit']} 張 (將啟用 P2/P3)"
            else:
                status_str = "✅ 已收錄" if cov["analyzed_count"] > 0 else "—"
            print(f"  {theme:<14} {cov['analyzed_count']:>8} 張 {need_str:>10}   {status_str}")
        print("=" * 68)
        print("💡 MV Studio 網頁介面已同步更新，可直接至「📷 照片分析」或「🎞️ 照片挑選」分頁查看！\n")
        return

    # ── 舊版根目錄匯入邏輯 ──
    input_path = Path(input_files[0])
    if not input_path.exists():
        print(f"❌ 找不到輸入檔案：{input_path}")
        sys.exit(1)

    data = json.loads(input_path.read_text(encoding="utf-8"))
    batch_id = data.get("batch_id", 0)
    analyses = data.get("analyses", [])

    if not analyses:
        print(f"⚠️  {input_path.name} 中 analyses 欄位為空，無資料可匯入。")
        return

    catalog = load_catalog()
    known = catalog_filenames(catalog)
    added = 0
    skipped = 0

    for a in analyses:
        fname = a.get("filename", "")
        if not fname:
            skipped += 1
            continue
        if fname in known:
            skipped += 1
            continue

        abs_path = a.get("abs_path") or str(Path(data.get("batch_dir", "")) / fname)
        p = Path(abs_path)
        exif_time = get_exif_time(p) if p.exists() else a.get("exif_time")
        mtime = get_file_mtime(p) if p.exists() else a.get("file_mtime")
        dims = get_image_dims(p) if p.exists() else a.get("dims")
        size_kb = round(p.stat().st_size / 1024, 1) if p.exists() else a.get("size_kb")

        theme = a.get("theme", "")
        if theme not in ALL_THEMES:
            theme = "WarmWords"

        fit_scores = a.get("fit_scores", {})
        for t in ALL_THEMES:
            fit_scores.setdefault(t, 1.0)

        quality_score = float(a.get("quality_score", 7.0))

        catalog["photos"].append({
            "filename": fname,
            "abs_path": abs_path,
            "exif_time": exif_time,
            "file_mtime": mtime,
            "dims": list(dims) if dims else None,
            "size_kb": size_kb,
            "batch_id": batch_id,
            "is_slide": a.get("is_slide", False),
            "theme": theme,
            "description": a.get("description", ""),
            "quality_score": quality_score,
            "fit_scores": fit_scores,
            "analyzed": True,
            "auto_tagged": False,
        })
        known.add(fname)
        added += 1
        print(f"  ✅ 匯入：{fname}  [{theme}]  Q={quality_score:.1f}")

    save_catalog(catalog)
    print(f"\n📦 Batch #{batch_id} 匯入完成：新增 {added} 張，略過 {skipped} 張。")
    print(f"   catalog 現有 {len(catalog['photos'])} 張照片。")


# ═══════════════════════════════════════════════════════════════
# 📊 status 子命令（支援 --project 與舊版）
# ═══════════════════════════════════════════════════════════════

def cmd_status(args):
    if args.project:
        pid, proj = _resolve_studio_project(args.project)
        st = subagent_lib.get_subagent_status(pid, proj)
        s = st["stats"]
        print(f"\n📚 MV Studio 專案 [{proj.get('name')}] ({pid}) 照片狀態")
        print(f"   最後更新：{st.get('catalog_last_updated')}")
        print(f"   照片總數：{s['total']}  |  已分析：{s['analyzed']} (Subagent: {s['subagent_analyzed']})  |  待分析：{s['pending']}")
        print()
        print(f"  {'主題':<14} {'已分析':>8} {'時槽需求':>8} {'缺口':>6}")
        print("  " + "─" * 44)
        for t, cov in st["theme_coverage"].items():
            need = cov["photos_needed"]
            deficit = f"-{cov['deficit']}" if cov["deficit"] > 0 else "✓"
            print(f"  {t:<14} {cov['analyzed_count']:>6} 張 {need:>6} 張 {deficit:>6}")
        print()
        return

    if not CATALOG_FILE.exists():
        print("❌ catalog 尚未建立。請先執行 scan 子命令（或加上 --project 指定 MV Studio 專案）。")
        return

    catalog = load_catalog()
    photos = catalog["photos"]
    total = len(photos)
    analyzed = sum(1 for p in photos if p.get("analyzed"))
    slides = sum(1 for p in photos if p.get("is_slide"))
    by_theme: dict[str, list] = {t: [] for t in ALL_THEMES}
    by_batch: dict[int, int] = {}

    for p in photos:
        t = p.get("theme", "?")
        if t in by_theme:
            by_theme[t].append(p["filename"])
        bid = p.get("batch_id", 0)
        by_batch[bid] = by_batch.get(bid, 0) + 1

    print(f"\n📚 photo_catalog.json 狀態")
    print(f"   版本：{catalog.get('catalog_version')}  更新：{catalog.get('last_updated')}")
    print(f"   照片總數：{total}  已分析：{analyzed}  投影片：{slides}\n")
    for t in ALL_THEMES:
        names = by_theme[t]
        preview = "、".join(names[:3])
        if len(names) > 3:
            preview += f"…等 {len(names)} 張"
        print(f"  {t:<12}  {len(names):>5}  {preview}")


# ═══════════════════════════════════════════════════════════════
# 📋 list 子命令
# ═══════════════════════════════════════════════════════════════

def cmd_list(args):
    if args.project:
        pid, proj = _resolve_studio_project(args.project)
        catalog = studio_photos.load_catalog(studio_store.catalog_file(pid))
    else:
        if not CATALOG_FILE.exists():
            print("❌ catalog 尚未建立。")
            return
        catalog = load_catalog()

    photos = catalog["photos"]
    if args.theme:
        photos = [p for p in photos if p.get("theme") == args.theme]
        print(f"\n🔖 主題 [{args.theme}] 的照片（共 {len(photos)} 張）：\n")
    else:
        print(f"\n📋 所有照片（共 {len(photos)} 張）：\n")

    photos_sorted = sorted(photos, key=lambda p: p.get("exif_time") or p.get("file_mtime") or "")
    for p in photos_sorted:
        slide_mark = "📊" if p.get("is_slide") else ("✅" if p.get("analyzed") else "⏳")
        q = p.get("quality_score")
        q_str = f"{q:4.1f}" if isinstance(q, (int, float)) else "  ? "
        t_str = p.get("theme") or "(未分析)"
        print(f"  {slide_mark} [{t_str:12}] Q={q_str}  {p['filename']}")
        if p.get("description"):
            print(f"       {p['description']}")


# ═══════════════════════════════════════════════════════════════
# 🚀 主程式
# ═══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        prog="analyze_batch_photos.py",
        description="MV 分批照片分析工具（整合 MV Studio 多專案 Subagent 管線）"
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # projects
    sub.add_parser("projects", help="列出 MV Studio 中所有專案")

    # scan
    p_scan = sub.add_parser("scan", help="掃描新照片並準備 Subagent 分組任務")
    p_scan.add_argument("--project", "-p", help="MV Studio 專案 ID 或名稱")
    p_scan.add_argument("--dir", help="照片目錄路徑（舊版單一專案模式）")
    p_scan.add_argument("--batch-id", type=int, default=1, help="批次編號（預設 1）")
    p_scan.add_argument("--max-per-agent", type=int, default=15, help="每個 Subagent 分配照片上限（預設 15）")
    p_scan.add_argument("--max-photos", type=int, default=0, help="本次最多抽樣分析張數（0=全部待分析）")
    p_scan.add_argument("--reanalyze", action="store_true", help="包含已分析過的照片重新分組")

    # prompt
    p_prompt = sub.add_parser("prompt", help="輸出指定 MV Studio 專案的 Subagent Prompt")
    p_prompt.add_argument("--project", "-p", required=True, help="MV Studio 專案 ID 或名稱")
    p_prompt.add_argument("--shard", "-s", type=int, help="只輸出指定 Shard 編號的 Prompt")

    # import
    p_import = sub.add_parser("import", help="將 Subagent 分析結果 JSON 匯入 catalog")
    p_import.add_argument("--project", "-p", help="MV Studio 專案 ID 或名稱")
    p_import.add_argument("--input", "-i", nargs="+", required=True, help="一或多個分析結果 JSON 檔案路徑")
    p_import.add_argument("--no-overwrite", action="store_true", help="不覆蓋已分析過的照片")

    # status
    p_status = sub.add_parser("status", help="顯示 catalog 統計狀態與主題覆蓋率")
    p_status.add_argument("--project", "-p", help="MV Studio 專案 ID 或名稱")

    # list
    p_list = sub.add_parser("list", help="列出 catalog 照片")
    p_list.add_argument("--project", "-p", help="MV Studio 專案 ID 或名稱")
    p_list.add_argument("--theme", help="依主題過濾（可選）")

    args = parser.parse_args()

    if args.cmd == "projects":
        cmd_projects(args)
    elif args.cmd == "scan":
        cmd_scan(args)
    elif args.cmd == "prompt":
        cmd_prompt(args)
    elif args.cmd == "import":
        cmd_import(args)
    elif args.cmd == "status":
        cmd_status(args)
    elif args.cmd == "list":
        cmd_list(args)


if __name__ == "__main__":
    main()
