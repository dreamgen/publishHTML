@echo off
rem Double-click launcher: bypasses the PowerShell execution policy and forwards all arguments to setup.ps1
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
pause
