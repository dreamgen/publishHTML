﻿# MV Studio 安裝／啟動腳本（Windows PowerShell）
# 用法： .\setup.ps1             → 建立 venv、安裝套件、環境健檢
#        .\setup.ps1 serve       → 啟動網頁介面（僅本機）
#        .\setup.ps1 serve --lan → 開放同 Wi-Fi 手機上傳
# 雙擊執行請用 setup.bat（會自動繞過 PowerShell 執行原則）。
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# 讓 Python 與主控台都用 UTF-8，避免繁體中文在 Big5(cp950) 終端機變亂碼
$env:PYTHONUTF8 = "1"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

# OneDrive 會把檔案「依需求下載」並持續同步，照片與 venv 放進去容易卡住或被鎖檔
$here = (Get-Location).Path
if (($here -match "OneDrive") -or ($env:OneDrive -and $here.StartsWith($env:OneDrive, [System.StringComparison]::OrdinalIgnoreCase))) {
  Write-Host "⚠️ 目前安裝路徑位於 OneDrive 底下：$here" -ForegroundColor Yellow
  Write-Host "   建議改裝到 C:\MVStudio（複製整個資料夾過去再執行 setup.bat），否則同步可能拖慢速度或鎖住檔案。" -ForegroundColor Yellow
}

if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Write-Host "⚠️ 尚未安裝 FFmpeg，請執行：winget install Gyan.FFmpeg（安裝後重開 PowerShell）"
}
# 資料夾搬移後 venv 會綁著舊路徑而失效：偵測到就重建
if ((Test-Path venv) -and (Test-Path .venv_path) -and ((Get-Content .venv_path -Raw).Trim() -ne $here)) {
  Write-Host "⚠️ 資料夾已搬移，重新建立虛擬環境..."
  Remove-Item -Recurse -Force venv
}
if (-not (Test-Path venv)) {
  py -3 -m venv venv
  .\venv\Scripts\python.exe -m pip install --upgrade pip
  .\venv\Scripts\python.exe -m pip install -r requirements.txt
  Set-Content -Path .venv_path -Value $here -Encoding UTF8
}
if ($args.Count -gt 0 -and $args[0] -eq "serve") {
  $rest = @(); if ($args.Count -gt 1) { $rest = $args[1..($args.Count-1)] }
  if ($rest -contains "--lan") {
    Write-Host "🛡️ 第一次使用 --lan 時，Windows 防火牆會跳出視窗詢問是否允許 Python 連線，請按「允許存取」（私人網路即可），手機才連得上。" -ForegroundColor Cyan
  }
  Start-Process "http://localhost:8787"
  .\venv\Scripts\python.exe mvctl.py serve @rest
} else {
  .\venv\Scripts\python.exe mvctl.py fonts
  .\venv\Scripts\python.exe mvctl.py doctor
}
