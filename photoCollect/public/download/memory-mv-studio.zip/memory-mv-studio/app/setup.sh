#!/usr/bin/env bash
# MV Studio 安裝／啟動腳本（macOS / Linux）
# 用法： ./setup.sh            → 建立 venv、安裝套件、執行環境健檢
#        ./setup.sh serve      → 啟動網頁介面（僅本機）
#        ./setup.sh serve --lan→ 啟動網頁介面並開放同 Wi-Fi 手機上傳
set -e
cd "$(dirname "$0")"
HERE="$(pwd)"
PY="${PYTHON:-python3}"

if [ -d venv ] && [ -f .venv_path ] && [ "$(cat .venv_path)" != "$HERE" ]; then
  echo "⚠️ 資料夾已搬移，重新建立虛擬環境..."; rm -rf venv
fi
if [ ! -d venv ]; then
  command -v ffmpeg >/dev/null || echo "⚠️ 尚未安裝 FFmpeg：macOS 請執行 brew install ffmpeg；Ubuntu 請執行 sudo apt install ffmpeg"
  "$PY" -m venv venv
  ./venv/bin/pip install --upgrade pip
  ./venv/bin/pip install -r requirements.txt
  echo "$HERE" > .venv_path
fi

if [ "$1" = "serve" ]; then
  shift
  if [ $# -eq 0 ] && ./venv/bin/python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8787/api/projects', timeout=1)" >/dev/null 2>&1; then
    echo "✅ MV Studio 已在執行中：http://localhost:8787"
    (command -v open >/dev/null && open http://localhost:8787) || (command -v xdg-open >/dev/null && xdg-open http://localhost:8787) || true
    exit 0
  fi
  PORT=8787
  EXTRA_ARGS=()
  HAS_PORT=0
  for a in "$@"; do
    if [ "$a" = "--port" ]; then HAS_PORT=1; fi
  done
  if [ "$HAS_PORT" = "0" ]; then
    PORT=$(./venv/bin/python -c "import socket
for p in range(8787, 8820):
    with socket.socket() as s:
        if s.connect_ex(('127.0.0.1', p)) != 0:
            print(p); break
else:
    print(8787)")
    if [ "$PORT" != "8787" ]; then
      echo "ℹ️ 連接埠 8787 已被佔用，自動改用連接埠 $PORT"
      EXTRA_ARGS=(--port "$PORT")
    fi
  fi
  ( sleep 1.5; (command -v open >/dev/null && open "http://localhost:$PORT") || (command -v xdg-open >/dev/null && xdg-open "http://localhost:$PORT") || true ) &
  exec ./venv/bin/python mvctl.py serve "${EXTRA_ARGS[@]}" "$@"
fi
./venv/bin/python mvctl.py doctor
