#!/usr/bin/env bash
# MV Studio 安裝／啟動腳本（macOS / Linux）
# 用法： ./setup.sh            → 建立 venv、安裝套件、執行環境健檢
#        ./setup.sh serve      → 啟動網頁介面（僅本機）
#        ./setup.sh serve --lan→ 啟動網頁介面並開放同 Wi-Fi 手機上傳
set -e
cd "$(dirname "$0")"
HERE="$(pwd)"
PY="${PYTHON:-python3}"

if [ -d venv ] && [ -f .venv_path ] && [ "$(cat .venv_path)" != "$HERE" ]; then
  echo "⚠️ 資料夾已搬移，重新建立虛擬環境..."; rm -rf venv
fi
if [ ! -d venv ]; then
  command -v ffmpeg >/dev/null || echo "⚠️ 尚未安裝 FFmpeg：macOS 請執行 brew install ffmpeg；Ubuntu 請執行 sudo apt install ffmpeg"
  "$PY" -m venv venv
  ./venv/bin/pip install --upgrade pip
  ./venv/bin/pip install -r requirements.txt
  echo "$HERE" > .venv_path
fi

if [ "$1" = "serve" ]; then
  shift
  ( sleep 1.5; (command -v open >/dev/null && open http://localhost:8787) || (command -v xdg-open >/dev/null && xdg-open http://localhost:8787) || true ) &
  exec ./venv/bin/python mvctl.py serve "$@"
fi
./venv/bin/python mvctl.py fonts || echo "（字型下載失敗，稍後可再執行 mvctl fonts）"
./venv/bin/python mvctl.py doctor
