#!/usr/bin/env bash
# 雙擊即可在瀏覽器啟動 MV Studio（macOS Finder 直接雙擊執行）
# 如需開放同 Wi-Fi 手機上傳，請於終端機執行：./start.command --lan
cd "$(dirname "$0")"
if ! ./setup.sh serve "$@"; then
  echo ""
  read -r -p "啟動失敗，按 Enter 鍵關閉視窗..." _
  exit 1
fi
