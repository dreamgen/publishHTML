# 疑難排解

先跑 `mvctl doctor`，大部分問題它會直接指出。

| 症狀 | 原因 | 解法 |
|---|---|---|
| `找不到 ffmpeg` | 未安裝 FFmpeg | macOS `brew install ffmpeg`；Windows `winget install Gyan.FFmpeg`（裝完重開終端機）；Ubuntu `sudo apt install ffmpeg` |
| 字幕或片頭出現方框字（例如「啟」） | 字型缺繁體字：常見於日文字型（ヒラギノ丸ゴ 沒有「啟」，只有「啓」）或系統沒有繁中字型 | 執行 `mvctl fonts`（下載 Noto Sans TC）→ `mvctl doctor` 字型項目要 ✅。`render` 會在開始前列出缺字並停止；`MV_FONT` 指向的字型若缺字也會被自動跳過 |
| 片頭卡、片尾卡的字在抖 | 舊版對文字卡套用緩慢縮放，整數像素取整造成邊緣震顫 | 新版固定素材完全靜態。舊專案請重跑 `mvctl manifest` 再 `render`；片頭片尾檔名請用 `片頭.png`／`片尾.png` |
| 照片運鏡一開始往反方向跳一下、或細微抖動 | 舊版取景框整數取整＋焦點靠邊時逐格卡扣 | 新版已改浮點取景框、Smoothstep 與焦點安全約束，更新程式後重新 `render` 即可 |
| HEIC 照片沒出現在影片裡、被別張替代 | 未安裝 `pillow-heif` | `./venv/bin/pip install pillow-heif`，再重跑 `mvctl scan` 與 `render` |
| 手機直拍照片在影片裡躺著 | 舊版未處理 EXIF 方向 | 可攜版已修正；舊縮圖快取會自動失效，重跑 `scan` 即可 |
| 最終合併失敗、`h264_videotoolbox` 錯誤 | 硬體編碼器不可用 | 會自動退回 libx264；也可設 `MV_FINAL_ENCODER=cpu` |
| 渲染很慢 | 每張照片逐格合成 | 設 `MV_RENDER_WORKERS=4`（記憶體 ≥ 16 GB 時）；Windows / NVIDIA 顯卡可設 `MV_FINAL_ENCODER=nvenc` |
| 節奏快的段落換照片時閃爍、一直閃黑 | 1.4.2 以前每張照片固定淡入淡出 0.5 秒，短照片幾乎都在黑場 | 更新到 1.4.3 以上（拍點溶接／硬切）；想更「卡點」可調高 `render.py` 的 `HARD_CUT_THRESHOLD`，想更柔和可調 `XFADE_RATIO`／`XFADE_MAX` |
| `Broken pipe` / 渲染卡住 | 舊版多執行緒同時用 VideoToolbox | 可攜版片段一律用 CPU 編碼；若仍發生，設 `MV_RENDER_WORKERS=1` |
| Whisper 很慢或記憶體不足 | `medium` 模型約需 5 GB RAM | `mvctl align <ID> --model small`，再到把關點 1 人工修正 |
| 歌詞同音錯字（「路要」→「不要」） | Whisper 幻聽 | 已由 DP + 拼音對齊修正；個別殘留錯字用 `fix_srt_with_dict.py` |
| 手機打不開上傳連結 | 伺服器只開本機，或不同網段 | 用 `mvctl serve --lan`；手機與電腦需同一個 Wi-Fi；公司／學校網路若隔離裝置，改用 Cloudflare Tunnel 並在 `event --public-url` 填入網址 |
| 上傳頁可開但管理頁顯示 403 | 設計如此 | 非本機連線只允許上傳頁，管理請在執行 MV Studio 的電腦上操作 |
| 網頁版「Gemini 自動分析」失敗 | 缺 Key、舊模型已下架、或未安裝 SDK | 設環境變數 `GEMINI_API_KEY`；模型名稱可在專案設定 `gemini_model` 或環境變數 `MV_GEMINI_MODEL` 調整；`pip install google-generativeai`。或改用 Agent 模式（不需 Key） |
| `status` 顯示照片數不一致 | 照片資料夾有新照片未掃描 | `mvctl scan <ID>` |
| 多台相機照片時間順序怪怪的 | 相機時鐘沒對時 | 目前需手動：在把關點 2 調整；後續優化項目見 `review-2026-10.md` |
| 搬移安裝資料夾後無法執行 | venv 綁定舊路徑 | 再跑一次 `./setup.sh`，會偵測並重建 venv |
| `link` 顯示「同步金鑰不正確或已被主辦者重發」 | 金鑰貼錯，或主辦者在管理頁重發了新金鑰 | 回雲端管理頁重新複製「同步網址」與「同步金鑰」再 `mvctl link`；網址可多貼結尾 `/` 或 `/manifest`，會自動修正 |
| `link`／`sync` 顯示「同步網址格式不正確」 | 網址不是 `https://<主機>/api/sync/ev_xxxxxxxxxxxx` | 從管理頁整段複製，不要只貼活動頁或上傳頁的網址 |
| `sync` 顯示「網路錯誤（已重試 3 次）」 | 網路中斷、公司網路擋外連、需 Proxy | 檢查網路；需 Proxy 時設環境變數 `HTTPS_PROXY`；`sync` 可重複執行，已下載的不會重抓 |
| `sync` 部分照片「下載失敗」 | 暫時性網路問題、或照片剛被主辦者排除（404） | 再跑一次 `sync` 會補抓；被排除的照片不需處理 |
| 雲端排除的照片還在 MV 裡 | 排除前已排進 `ordered_photos.json` | `sync` 會把檔案移到 `_excluded/` 並從 catalog 移除；重跑 `scan` → `manifest` 讓排程更新 |
| `scan` 沒有掃到 `sync` 下載的照片 | 設計如此：`sync` 已把照片寫進 catalog（`analyzed=false`），`scan` 只負責產生待分析任務 | 直接看 `scan` 輸出的「待分析」張數；`_excluded/` 子資料夾不會被掃描 |

## Windows 常見問題

| 症狀 | 原因 | 解法 |
|---|---|---|
| 中文／emoji 變成亂碼或 `UnicodeEncodeError` | 終端機是 Big5（cp950） | 用 `setup.bat` 或 `setup.ps1` 啟動（會設 `PYTHONUTF8=1` 與 UTF-8 輸出）；手動：`chcp 65001`，PowerShell 加 `$env:PYTHONUTF8=1; [Console]::OutputEncoding=[System.Text.Encoding]::UTF8`。`mvctl doctor` 會提示 |
| `無法載入檔案 setup.ps1，因為這個系統上已停用指令碼執行` | PowerShell 執行原則 | 改雙擊 `setup.bat`；或 `powershell -NoProfile -ExecutionPolicy Bypass -File setup.ps1`；或 `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| 手機連不上 `serve --lan` 的上傳頁 | Windows 防火牆擋住 Python | 第一次啟動的詢問視窗請按「允許存取」（私人網路）；錯過了就到「Windows Defender 防火牆 → 允許應用程式」勾選 Python；公共 Wi-Fi 被歸類為「公用網路」時也要勾選公用 |
| 安裝很慢、檔案被鎖、`PermissionError` | 安裝在 OneDrive（桌面／文件）底下 | 改裝到 `C:\MVStudio`（複製整個資料夾，重跑 `setup.bat`）；`mvctl doctor` 會顯示 ⚠️ |
| 網頁「選擇資料夾」沒有跳出視窗 | Python 沒有 tkinter（部分精簡安裝） | 會自動改用網頁內建檔案瀏覽器；要用系統視窗請用 python.org 安裝版並勾選 tcl/tk |
| 活動手冊 `.pdf` 讀不到 | 未安裝 pypdf | `venv\Scripts\pip install pypdf`；掃描圖檔的 PDF 沒有文字，請改提供 `.docx` 或 `.txt` |
| 活動手冊 `.doc`／`.rtf` 讀不到 | Windows 沒有內建轉檔工具 | 用 Word 另存成 `.docx` 或 `.txt` |
| `py` 或 `python` 找不到 | 未安裝 Python 或沒加入 PATH | 從 python.org 安裝 3.10+，安裝時勾選「Add python.exe to PATH」與「py launcher」 |
