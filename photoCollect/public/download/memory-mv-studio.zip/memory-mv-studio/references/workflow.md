# 照片回憶 MV 製作流程規格（可攜版）

本文件彙整了跨專案（《路要自己走》、《心靈漣漪》、《同心同德的班級團隊》、《親子保鮮期》、《我們的班歌》及「碧山露營場」媒體庫）的實戰演進經驗，提煉出一套**兼顧「情感敘事」、「時間軸精準度」與「工程穩定性」的照片回憶 MV 標準化製作流程**。

---

## 一、專案演進與關鍵經驗復盤 (Lessons Learned)

在多次迭代中，我們從早期的單一腳本（`make_memory_video.py`），演進到四階段 CLI 管線與 Agent Skill（`SKILL.md`），最終封裝為多專案網頁系統 **`MV Studio`**。以下是解決過的五大核心痛點：

| 痛點領域 | 早期問題 | 最終技術方案與經驗法則 | 對應實作檔案 |
| :--- | :--- | :--- | :--- |
| **1. 歌詞時間軸對齊** | 直接用 Whisper 轉錄歌曲會產生**同音錯字**（「路要自己走」變「不要自己走」）、**簡繁混亂**與**時間偏移（最高達 10 秒）**。 | 改為**「已知歌詞強制對齊（Forced Alignment）」**：以正確歌詞前 4 句作為 `initial_prompt` 引導 Whisper 輸出字詞時間戳（`word_timestamps`），再透過 **Needleman-Wunsch 全域動態規劃（DP）結合 `pypinyin` 同音字加權**（字元相同 `+2.0`、同音字 `+1.5`、錯字 `-1.0`），並自動輸出 `testsrc` 校對影片供人工把關。 | `align_lyrics_dp.py`<br>`fix_srt_with_dict.py` |
| **2. 畫面節奏與間隙閃爍** | 完全照字幕起訖切照片，導致短句照片閃太快（< 1.5s）、長句或間奏畫面停滯、字幕微小間隙造成黑屏或急促跳接。 | 建立**「時間槽（Slot）切分引擎」**：<br>• 字幕間隙 `< 2.0s` 直接併入相鄰句（消除閃爍）<br>• 間隙 `≥ 2.0s` 獨立為無字幕「間奏槽（Gap Slot）」<br>• 單槽目標 `3.5s`（歌詞槽最短 `2.5s`、間奏槽最短 `2.0s`、上限 `5.25s`），過長自動均分，確保總時長誤差 `< 0.05s`。 | `lyrics.py`<br>`prepare_content_plan.py` |
| **3. 照片分批到齊與語意配對** | 活動照片常來自不同攝影師或 LINE 相簿分批上傳；若僅按檔名或隨機排列，畫面與歌詞情境嚴重脫節。 | 設計**「多模態 Catalog + 三優先排程演算法」**：<br>• 支援分批掃描（`batch_id`），提取 EXIF 拍攝時間並產生 `640px` 快取縮圖（網頁顯示用 `320px`）<br>• AI 視覺評定主分類（`theme`）、畫質分（`quality_score`）與全主題適配度矩陣（`fit_scores`）<br>• 依 **P1（同主題未用，按 EXIF 時間排序）→ P2（跨主題高適配未用）→ P3（加權輪替重用）** 分配。 | `photos.py`<br>`auto_analyze.py`<br>`manifest.py` |
| **4. 直橫幅混排與字幕易讀性** | 手機直式照片與相機橫式照片混排會產生突兀黑邊；外掛軟字幕相容性差，一般硬字幕在淺色照片上看不清楚。 | **Pillow 雙層合成 + 圓體描邊硬字幕**：<br>• 背景層放大裁切填滿 `1920x1080` 並套用 `BoxBlur(20)`，前景層等比縮放居中，加上 Ken Burns 縮放與拍點溶接／硬切過場<br>• 採用繁體中文字型（內建 Noto Sans TC Black，並逐字檢驗缺字）`84px`、白字配 `stroke_width=7` 粗黑框，寬度超過 `1800px` 自動等比縮小字級。（早期用日文冬青丸黑體，缺「啟」等繁體字，已淘汰） | `render.py`<br>`make_parent_child_mv.py` |
| **5. Apple Silicon 編碼崩潰與死鎖** | 多執行緒同時呼叫 `h264_videotoolbox` 生成 60+ 個片段會觸發硬體並發上限（`Errno 32 Broken pipe`）；FFmpeg `stderr` 用 `PIPE` 未即時讀取會塞滿緩衝區死鎖。 | **CPU/GPU 混合編碼架構**：<br>• 子片段生成：一律用 CPU `libx264 -preset superfast -crf 18`，且 `stderr` 導向 `TemporaryFile` 避免 pipe 死鎖<br>• 最終合併混音：單一進程 `concat` 才啟用 GPU `h264_videotoolbox -b:v 6000k`（失敗自動 fallback 至 `libx264`），4 分鐘 1080p 成品穩定控制在 `~170MB`。 | `render.py`<br>`render.py` |

---

## 二、照片回憶 MV 全生命週期六階段標準化流程設計（含活動前籌備與即時募集）

為滿足「從活動籌備期就開始佈局、活動當下即時收片、活動結束快速出片」的完整訴求，整體流程向上游延伸至**「階段 0：活動前籌備與即時照片募集」**，共分為**六個解耦階段**：

``mermaid
flowchart TD
    subgraph P0["階段 0：活動前籌備與即時照片募集 (Pre-Event & Live Upload)"]
        A0["🎪 輸入活動名稱 / 流程表 / 宣傳文案 / 活動手冊 (.docx/.pdf/.txt)"]
        A1["🧠 自動萃取：活動環節主題 (Themes) + 預期小隊名單 + 建議拍攝清單"]
        A2["🎨 自動建立照片目錄 + 生成 1920x1080 片頭.png / 片尾.png"]
        A3["📱 產生專屬上傳 URL 與 QR Code (/upload/<token>)"]
        A4["📸 攝影師/家長手機直傳 (EXIF 時間自動匹配流程主題 + <3ms 人臉焦點偵測)"]
        A0 --> A1 --> A2 --> A3 --> A4
    end

    subgraph P1["階段 1：歌詞強制對齊 (Audio-Lyric Alignment)"]
        B1["Whisper 轉錄 (word_timestamps + initial_prompt)"]
        B2["Needleman-Wunsch DP + 拼音同音對齊"]
        B3["🔍 人工把關點 1：觀看 _校對用.mp4 微調 generated.srt"]
        B1 --> B2 --> B3
    end

    subgraph P2["階段 2：敘事主題規劃與節拍對齊時槽切分 (Content Planning & Beat-Snapping)"]
        C1["結合活動環節主題 + 歌詞詞頻分析指派逐行主題 (lyrics_map.json)"]
        C2["🥁 FFmpeg + 多頻段頻譜通量偵測 BPM 與重拍 (beats.py)"]
        C3["時槽切分引擎 (吸收 <2s 間隙 / 間奏與長句切點自動踩拍)"]
        C4["📋 產出 content_plan.json 與「各主題照片需求表」"]
        C1 --> C2 --> C3 --> C4
    end

    subgraph P3["階段 3：分批多模態照片分析 (Photo Cataloging)"]
        D1["增量掃描與手機直傳照片匯集 (提取 EXIF + 人臉焦點 focus_x/y + 640px 縮圖)"]
        D2["AI 視覺分析 (Subagent 多代理並行 / Gemini Vision API)"]
        D3["評定主分類 theme + 畫質 quality_score + fit_scores + 人物標籤 protagonists"]
        D4["🗂️ 更新 photo_catalog.json 並即時監控主題與小隊覆蓋率"]
        D1 --> D2 --> D3 --> D4
    end

    subgraph P4["階段 4：三優先智慧排程與人物出場均衡 (Manifest Scheduling)"]
        E1["P1：同主題未用 (先依低出場率人物稀缺加權選子集，再按 EXIF 時間排序)"]
        E2["P2：跨主題未使用 (fit×0.6 + quality×0.4 + 人物稀缺加權)"]
        E3["P3：高分照片輪替重用 (Round-Robin + 人物均衡加權)"]
        E4["🔍 人工把關點 2：檢視人物出場均衡儀表板與分鏡卡片微調"]
        E5["🎬 產出 ordered_photos.json (含每槽 focus_x, focus_y)"]
        E1 --> E2 --> E3 --> E4 --> E5
    end

    subgraph P5["階段 5：智慧人臉追蹤渲染與混音封裝 (Face-Aware Video Rendering)"]
        F1["Pillow 雙層畫布 + 🎯 朝向人臉焦點平滑推進 (Face-Aware Ken Burns) + 硬字幕"]
        F2["FFmpeg Pipe 逐槽生成暫存片段 (CPU libx264 superfast)"]
        F3["FFmpeg Concat + 混入音軌 (GPU VideoToolbox 6000k)"]
        F4["🎉 輸出最終回憶 MV (.mp4)"]
        F1 --> F2 --> F3 --> F4
    end

    A1 --> C1
    A2 --> C3
    A4 --> D1
    P1 --> P2
    P2 & P3 --> P4
    P4 --> P5
``

---

### 階段 0：活動前籌備與即時照片募集（Pre-Event Planning & Live Photo Collection）

> [!TIP]
> **把 MV 製作起點提前到「活動舉辦前」！**
> 過去常見痛點是活動結束後才開始催照片、某個關卡或某個小隊漏拍、或收到幾百張混亂照片不知如何分類。透過階段 0（`event_prep.py`），在活動前就能把「主題分類、小隊名單、拍攝指南、上傳環境與專屬 URL/QR Code」一次備齊。

1. **輸入活動企劃與手冊資料**：
   - 在 MV Studio「**🎪 活動籌備 & 募集**」分頁輸入或直接透過內建檔案瀏覽器匯入（支援 `.docx` / `.doc` / `.pdf` / `.txt` / `.md` / `.rtf` 自動擷取文字）：
     - **基本資訊**：活動名稱、日期、地點、主辦單位/班級、活動標語（Slogan）。
     - **活動流程表（Schedule）**：例如 `09:00-09:30 報到相見歡`、`10:30-12:00 狀元會考闖關`、`14:00-15:30 親子淨灘`。
     - **宣傳文案（Promo Copy）**與**活動手冊（Handbook）**：包含活動精神、關卡介紹、小隊分組名單。
2. **一鍵智慧建置收集環境（`prepare_collection_environment`）**：
   - **自動萃取活動環節主題與時段**：從流程表解析出 `HH:MM-HH:MM` 時間區間與對應主題標籤（`themes`），自動同步至專案主題清單。
   - **自動萃取小隊 / 主角標籤（`expected_groups`）**：自動掃描手冊中的「第一小隊、第二小隊…」等組別名單，供上傳頁面點選並直接對接階段 4 的「人物出場均衡控制」。
   - **自動產生「📋 攝影師建議拍攝清單（Shot Checklist）」**：明確列出每個時段與每個小隊建議拍攝的畫面重點與目標張數。
   - **自動繪製 `1920×1080` 片頭卡與片尾卡（`generate_event_cards`）**：依活動名稱、標語、日期地點與主辦單位自動生成高質感漸層 `片頭.png` 與 `片尾.png`。
3. **專屬上傳 URL、QR Code 與即時手機直傳入口（`upload.html`）**：
   - 以 `--lan` 啟動後自動產生區網直連網址（`http://<LAN_IP>:8787/upload/<token>`，亦支援設定外部 Cloudflare Tunnel / ngrok 公網網址）、**純 Python 零依賴 SVG QR Code** 以及**一鍵複製 LINE 群組募集公告文案**。
   - 攝影師或家長在手機點開連結後，可查看即時拍攝清單、點選所屬小隊標籤，並從手機相簿一次多選數十張照片批次上傳。
   - **上傳當下自動預處理（`handle_uploaded_photos`）**：
     - 自動防撞名寫入專案 `photos_dir`
     - 自動讀取照片 EXIF 拍攝時間並**對照活動流程表時段預填主題提示**（例如 `10:45` 拍攝的照片預填 `10:30-12:00` 的闖關主題）；照片仍標記為「待分析」，須經階段 3 視覺分析補上真實畫質分後才會進入排程
     - 自動執行 `<3ms` 人臉/主體視覺焦點偵測 `(focus_x, focus_y)` 與寫入 `photo_catalog.json`，MV Studio 後台每 4 秒即時刷新募集進度。
     - 安全限制：非本機連線（含經 Tunnel 轉發者）只能存取上傳頁；單張上限 60 MB（`MV_MAX_UPLOAD_MB`），只收照片格式。

---

### 階段 1：歌詞強制對齊（Audio-Lyric Forced Alignment）

> [!IMPORTANT]
> **為什麼這是成敗關鍵？**
> 照片切換點與硬字幕完全依賴 SRT 時間軸。若時間軸偏移，後續所有視覺排程都會錯位。因此必須先鎖定精準的 `generated.srt`，再進入視覺規劃。

1. **輸入**：音樂檔（`.mp3`）+ 純文字正確歌詞（`.txt`，自動過濾 `[Verse]` 等結構標籤）。
2. **核心處理**（`align_lyrics_dp.py`）：
   - 取歌詞前 4 行作為 `initial_prompt` 餵給 Whisper（`medium` 模型），開啟 `word_timestamps=True` 並快取 `_raw.json`（避免重跑轉錄）。
   - 將轉錄出的字詞展開為單字元時間流 $T_{\text{chars}}$，與基準歌詞字元流 $L_{\text{chars}}$ 執行全域動態規劃（Needleman-Wunsch），利用 `pypinyin` 讓同音異字獲得正向匹配分（`+1.5`），徹底消除 Whisper 幻聽與簡繁問題。
   - **邊界平滑化**：確保單句字幕最短顯示 `1.0s`，並自動消除相鄰句時間重疊（Overlap Resolution）。
3. **人工把關點 1**：
   - 腳本自動合成一支帶時間碼的 `_校對用.mp4`，或於 **`MV Studio 歌詞對齊分頁`** 直接試聽微調起訖秒數。

---

### 階段 2：敘事主題規劃與時槽切分（Content & Slot Planning）

將「歌曲時間線」轉換為「照片需求規格書（`content_plan.json`）」：

1. **主題標籤設計（Thematic Taxonomy）**：
   - **活動型 MV**（如營隊、戶外聯誼）：依「活動關卡/流程」設定主題（例如：`Intro` 報到相見歡、`English` 課程、`BeachClean` 淨灘、`WarmWords` 溫馨互動、`Outro` 大合照）。
   - **情感/成長型 MV**（如畢業、家庭回顧）：可先用 `themes.py` 的 N-gram 實詞提取功能找出高頻意象，或請 AI 讀完歌詞設計 6～9 個情境主題。
2. **時槽切分演算法（Slot Splitting Rules）**（`lyrics.py`）：
   - **片頭與片尾鎖定**：首尾保留給固定圖卡（如 `片頭.png` 3.9s 涵蓋前奏、`片尾.png` 8.0s 涵蓋尾奏致謝）。
   - **微小間隙吸收**：兩句歌詞間隔 `< 2.0s` 時，將後一句的照片切換點提前至前一句結束，避免無意義的短暫空鏡。
   - **長句與間奏拆分**：若單句歌詞或純音樂間奏超過 `5.25s`（`target_slot_duration × 1.5`），自動以 `3.5s` 為目標均分為多個連續時槽（共用同一句字幕或標記為 `is_gap=True`），讓長段落也有豐富的照片流轉。
3. **產出「主題需求統計表」**：
   - 自動計算每個主題需要幾張照片、共佔幾秒，作為下一階段挑選與補拍照片的明確依據。

---

### 階段 3：分批多模態照片分析（Batched Photo Cataloging）

針對回憶照片「來源多、分批到、品質參差」的特性，建立可增量擴充的 `photo_catalog.json`：

1. **無損增量掃描**（`photos.py`）：
   - 比對檔名跳過已收錄照片，僅針對新增照片分配新的 `batch_id`。
   - 優先提取 EXIF `DateTimeOriginal`（若無則退回 macOS `mdls` 或檔案修改時間 `mtime`），並產生 `640px` 輕量縮圖給 AI 判讀（網頁顯示用 `320px`），讀取時依 EXIF Orientation 自動轉正。
2. **雙軌 AI 視覺評分**：
   - **軌道 A（網頁背景批次）**：透過 `auto_analyze.py` 呼叫 Gemini Vision API 多執行緒分析。
   - **軌道 B（Agent 多子代理並行）**：遵循 `photo_analysis_protocol.md`，依照片數量自動派發 2～4 個 Subagents 並行判讀。
3. **結構化評分指標**：
   - `theme`：最契合的單一主分類。
   - `quality_score`（`0.0–10.0`）：評估對焦清晰度、構圖、人物表情張力與光線（過曝、晃動、背影自動降權）。
   - `fit_scores`（每個主題 `0.0–10.0`）：**這是解決某主題照片不足的關鍵設計**——即使一張照片主分類是 `Intro`，若畫面中有親子牽手，其 `WarmWords` 的 `fit_score` 也能拿到 `7.0+`，供後續跨主題調度。

---

### 階段 4：三優先智慧排程與分鏡微調（3-Priority Manifest Scheduling）

由 `manifest.py` 讀取 `content_plan.json` 與 `photo_catalog.json`，為每個時槽指派最佳照片：

$$\text{Composite Score}(p, \text{theme}) = 0.6 \times \text{fit\_scores}[p][\text{theme}] + 0.4 \times \text{quality\_score}[p]$$

| 優先級 | 觸發條件 | 挑選與排序邏輯 | 設計目的 |
| :---: | :--- | :--- | :--- |
| **FIXED** | 時槽已指定固定素材 | 直接鎖定（如 `片頭.png`、`片尾.png`） | 確保品牌包裝與首尾結構固定 |
| **P1（最優）** | 該主題池內仍有**未使用**照片 | 按 **EXIF 拍攝時間升冪** 依序取出 | **核心體驗**：讓同一個活動關卡的照片呈現真實的時間推進感 |
| **P2（次優）** | 該主題照片已用盡，但全局仍有**未使用**照片 | 計算所有未用照片對當前主題的 $\text{Composite Score}$，取最高分者 | 優先讓所有好照片都能出場一次，且畫面語意不違和 |
| **P3（兜底）** | 所有照片皆已出場過一次 | 在該主題池內按 $\text{Composite Score}$ 排序，以 **Round-Robin 輪替**重用 | 當照片總數少於時槽數（例如 40 張配 65 槽）時，高分照片均勻重現，避免連續重複 |

- **覆蓋率健檢與人工把關點 2**：
  - 若某主題 `P3` 重用率過高或出現 `EMPTY`，系統立即提示補充該主題照片。
  - 在 **`MV Studio 照片分配分頁`** 或直接編輯 `ordered_photos.json`，可針對副歌高潮或特定歌詞手動指定「靈魂照片」。

---

### 階段 5：動態視覺渲染與混音封裝（Hybrid Video Rendering）

由 `render.py` 執行高畫質合成，標準規格如下：

1. **雙層背景適應（消滅黑邊）**：
   - 無論直式、橫式或正方形照片，底層一律縮放裁切至 `1920x1080` 並加上 `ImageFilter.BoxBlur(20)`；前景層等比縮放（Scale-to-fit）居中貼合。
2. **動態運鏡（Ken Burns）與轉場**：
   - 照片依片段序號交替拉近（Zoom-in `1.00 → 1.14`）與拉遠（`1.14 → 1.00`），鏡頭從畫布中心平滑移向人臉焦點，並依序號加上四向微幅平移（畫布 1.2%）。
   - **浮點取景框**：每格的取景框是浮點座標，以 `Image.resize(..., BICUBIC, box=浮點框)` 做次像素抗鋸齒重採樣，不做整數取整，避免 1080p 下每格 0～1 像素的跳點。
   - **Smoothstep 緩動**：進度 `e = 3t² − 2t³`，起步與結束都是零速度。
   - **焦點安全約束**：終點（焦點＋平移）先限制在「最大縮放時取景框仍完全在畫布內」的範圍；中心與縮放同步線性前進時，整段路徑每一格自動落在畫布內，**不需逐格 clamp**，因此不會出現撞牆回彈（先反向再鎖死）。
   - **片頭卡／片尾卡完全靜態**：排程標記為 `FIXED`（或檔名「片頭」「片尾」）的片段不運鏡、1:1 輸出，FFmpeg 加 `-tune stillimage`，只保留過場，文字不會震顫。
   - **過場（1.4.3 起）**：相鄰照片以拍點為中心交叉溶接（長度＝較短那張 × `XFADE_RATIO` 0.2，上限 `XFADE_MAX` 0.6s）；任一張 ≤ `HARD_CUT_THRESHOLD`（1.2s）時直接在拍點硬切，快節奏段落不再經過黑場而閃爍。只有整支 MV 的開頭／結尾保留 `0.5s` 黑場淡入淡出。字幕在溶接後才畫，不會跟著淡掉。
   - 片段幀數依累計時間軸計算（`frame_range()`），短照片很多時畫面也不會越來越早於音樂／字幕。
3. **高對比硬字幕與字型**：
   - **繁體中文優先＋缺字檢驗**（`lib/portable.py` 的 `choose_cjk_font`）：候選順序為 `MV_FONT` → 內建 `fonts/NotoSansTC-Variable.ttf`（`mvctl fonts` 下載，可變字型自動調到最粗 Black）→ 使用者字型夾 Noto Sans TC → 蘋方／STHeiti → 微軟正黑體 → Noto Sans CJK（自動挑 TC 字面）→ 最後備援（明體、簡體、日文字型）。每個候選都要實際畫得出「繁體探針字（啟體臺灣說為與這們裡會發歡迎謝錄）＋全部字幕文字」才採用。
   - 曾發生的錯誤：舊版優先用 macOS 日文字型「ヒラギノ丸ゴ ProN」，沒有繁體「啟」（日文作「啓」），字幕出現方框。
   - `mvctl render` 開始前會檢查全部字幕與活動名稱，缺字就停止（除非加 `--ignore-missing-glyphs`）；片頭片尾自動產生也用同一套字型選擇。
   - 基礎字級 `84px`、白色填滿、`stroke_width=7` 黑色描邊，底部留白 `100px`；若單行寬度超過 `1800px` 自動動態縮放字級。
4. **兩階段穩定編碼**：
   - **階段 5a（分片渲染）**：序列透過 stdin pipe 餵入 FFmpeg，使用 `-c:v libx264 -preset superfast -crf 18 -pix_fmt yuv420p` 寫入暫存檔；因為不使用硬體編碼器，片段可平行渲染（`MV_RENDER_WORKERS`，預設 CPU 核心數一半、最多 4）。
   - **階段 5b（合併混音）**：透過 `ffmpeg -f concat` 串接所有片段並混入音軌（`aac 192k`），macOS 預設用 `h264_videotoolbox -b:v 6000k`，其他平台用 `libx264 -crf 20`（可用 `MV_FINAL_ENCODER` 覆寫，失敗自動退回 libx264）。

---

## 三、雙軌操作路徑（網頁 vs. 指令列）

兩條路徑共用同一個專案資料夾 `mv_studio/projects/<ID>/`，可隨時切換。

### 路徑 A：MV Studio 網頁介面（適合視覺化挑選、拖拉換照片）
```bash
cd "$MV_HOME" && ./setup.sh serve          # 只開放本機
cd "$MV_HOME" && ./setup.sh serve --lan    # 活動現場：同 Wi-Fi 手機可上傳
```
開啟 `http://localhost:8787`，依序：⚙️ 專案設定 → 🎵 歌詞對齊 → 🗂️ 內容規劃 → 🔍 照片分析 → 🎞️ 照片分配 → 🎬 開始渲染。

### 路徑 B：`mvctl.py` 指令列（適合 AI Agent 對話式自動化與 Subagent 批次看圖）
```bash
mvctl new --name 家庭日 --music song.mp3 --lyrics lyrics.txt --photos ./photos
mvctl event <ID> --schedule 流程表.txt            # 階段 0（選用）
mvctl align <ID>                                   # 階段 1
mvctl themes <ID> --set "..." && mvctl map <ID> --suggest && mvctl plan <ID>   # 階段 2
mvctl scan <ID> --focus → subagents → mvctl import <ID> sub*.json            # 階段 3
mvctl manifest <ID>                                # 階段 4
mvctl render <ID>                                  # 階段 5
mvctl status <ID>                                  # 任何時候：看進度與下一步
```

> 舊版單一專案腳本（`prepare_content_plan.py`、`build_photo_manifest.py`、`make_parent_child_mv.py`）寫死了《親子保鮮期》的路徑與主題，可攜版已不再收錄，全部改由 `mvctl.py` 呼叫 `mv_studio/lib` 的同一套邏輯。

---

## 四、未來進階擴充建議 (Next-Gen Roadmap)

若未來要讓這套回憶 MV 流程更上一層樓，可基於現有架構擴充以下四個模組：

1. **「照片 + 短影片（Live Photo / MP4）」混合分鏡支援**：
   - 結合 `mp4-3` 與 `碧山露營場` 的經驗，在 `photo_catalog.json` 加入 `media_type: "video"`，抽關鍵影格供 AI 評分；渲染時針對影片素材自動截取最佳秒數區間、統一轉為 `1080p@30fps` 並靜音（或保留環境音 Ducking），與照片片段無縫 `concat`。
2. **Ken Burns 智慧人臉焦點追蹤（Face-Aware Pan & Zoom）— ✅ 已實作（`photos.py` + `render.py`）**：
   - 掃描與 AI 分析時自動記錄主體/人臉的重心座標 `(focus_x, focus_y)`（結合 YCbCr 膚色熱區、空間梯度與人像上中段高斯先驗，單張 `<3ms`，並支援網頁 🎯 準星點擊微調）。渲染時鏡頭由畫布中心平滑推進至人臉焦點 `(target_cx, target_cy)`，徹底避免切頭頂。
3. **人物出場均衡度控制（Protagonist Balancing）— ✅ 已實作（`manifest.py`）**：
   - 支援在照片標記人物/小隊標籤 `protagonists`（如 `["第一小隊", "小明"]`）。在階段 4 的 `P1/P2/P3` 排程中導入「低出場率人物稀缺加權 (`protagonist_weight / (1 + count)`)」，P1 先依稀缺度挑選最佳子集、再嚴格依 EXIF 時間排序，兼顧「人人有鏡頭」與「活動時間流敘事」，並於網頁提供即時出場均衡度儀表板。
4. **音樂節拍對齊（Beat-Snapping 間奏切分）— ✅ 已實作（`beats.py` + `lyrics.py`）**：
   - 透過 FFmpeg 解碼單聲道 PCM 並以 NumPy 多頻段頻譜通量（Multi-band Spectral Flux）+ Ellis (2007) 動態規劃節拍追蹤偵測全曲 BPM 與強弱拍（零額外套件依賴，4 分鐘 MP3 僅需 `0.8s`）。在切分間奏（`is_gap=True`）與長句多槽時自動將切點吸附至最近重拍，同時維持總時長毫秒級零誤差。
