# 照片視覺分析協定（多 Subagent 平行判讀）

在階段 3 需要讓 AI 看照片打分時閱讀本文件。不需要任何外部 API Key。

## 1. 產生任務檔

```bash
mvctl scan <ID> --focus
```

會自動：
1. 增量掃描 `photos_dir`，新照片分配新的 `batch_id`（已收錄的不重複處理；片頭／片尾不列入分析）。
2. 產生 640px 縮圖到 `mv_studio/projects/<ID>/.cache/thumbs/`（已依 EXIF 方向轉正）。
3. 讀取專案主題與 `content_plan.json` 的需求，把待分析照片切成 shards（每組 ≤15 張），寫入 `mv_studio/projects/<ID>/subagent_task.json`，每個 shard 內含完整 `prompt`。
4. `--focus` 會先用演算法估計人臉焦點（focus_x / focus_y），AI 判讀時可覆寫。

要重新分析全部照片：`./venv/bin/python analyze_batch_photos.py scan --project <ID> --reanalyze`。
查看單一 shard 的 prompt：`./venv/bin/python analyze_batch_photos.py prompt --project <ID> --shard 1`。

## 2. 派工規則

| 待分析張數 | 做法 |
|---|---|
| ≤ 15 | 主 agent 自己看（或 1 個 subagent） |
| 16–60 | 依 shard 數派 2～4 個 subagent 平行 |
| > 60 | 每 shard 一個 subagent；同時執行上限依平台而定，超過就分梯次 |

- 把 `shards[i].prompt` **原封不動**交給 subagent，不要自行改寫主題清單或格式。
- 若平台沒有 subagent 功能，主 agent 依 shard 順序自己逐張看圖完成，格式相同。
- subagent 必須**實際開啟每一張 `view_path` 縮圖**再評分，不可依檔名猜測。

## 3. 評分標準（prompt 內已含，摘要於此供檢查）

- `theme`：唯一主分類，必須是專案主題清單中的名稱。
- `quality_score` 0–10：對焦、構圖、表情張力、光線。背影、嚴重模糊、過曝、遮擋給 1–4 分；閉眼、半張臉被切掉明顯降分。
- `fit_scores`：**每個主題都要給分** 0–10。主分類以外的主題也要認真評——例如報到照片裡有親子牽手，「溫馨互動」可給 7 分以上，這是照片不足時跨主題調度的依據。
- `focus_x` / `focus_y` 0–1：主角臉部重心（0.5, 0.36 為畫面中央偏上），運鏡會朝這裡推近。
- `protagonists`：人物或小隊標籤（例：`["第一小隊"]`、`["孩童","家長"]`、`["全員合照"]`），名稱盡量沿用活動手冊中的小隊名稱，供人物出場均衡使用。
- `description`：繁體中文一句話（20 字內）。

## 4. 收回結果與匯入

1. 每個 subagent 回傳的 JSON 存成獨立檔案（例：專案資料夾內 `sub_shard1.json`）。
2. 一次匯入：`mvctl import <ID> sub_shard1.json sub_shard2.json`
3. 匯入器會容錯處理 markdown 圍欄、主題名稱大小寫或近似值；但 filename 必須與清單完全一致。

## 5. 失敗處理

- JSON 格式壞掉或 subagent 逾時：只針對那一組照片由主 agent 重做，不要跳過。
- 匯入後 `mvctl status <ID>` 仍顯示未分析的照片：重跑 `mvctl scan <ID>`，它只會列出剩下的。

## 6. 進入階段 4 前的品質關卡

- 任何在 `content_plan` 需要照片的主題，catalog 內為 0 張 → 告訴使用者「主題 X 目前沒有照片，繼續的話會改用其他主題照片代替」，問要補照片或直接繼續。
- 照片總數少於時槽數 → 會出現重複使用（P3），先告知預估重複比例。
- 同一人物／小隊明顯集中 → 提醒到把關點 2 檢查出場均衡。
