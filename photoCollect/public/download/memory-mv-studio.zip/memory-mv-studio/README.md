# memory-mv-studio — 照片回憶 MV 製作 Skill（可攜版）

一首歌 + 一批活動照片 → 有歌詞字幕、照片依歌詞情境與拍攝時間排列、鏡頭朝人臉推進的回憶 MV。
包含活動前籌備（流程表 → 主題、拍攝清單、片頭片尾、手機上傳 QR）與網頁介面 MV Studio。

## 給使用者：安裝 Skill

| 使用環境 | 安裝方式 |
|---|---|
| Claude（桌面版／網頁版／Cowork） | 設定 → Capabilities → Skills → 上傳 `memory-mv-studio.zip` |
| Claude Code | 解壓到 `~/.claude/skills/memory-mv-studio/`（個人）或專案的 `.claude/skills/` |
| Gemini CLI／Antigravity 等支援 SKILL.md 的 Agent | 解壓到該工具的 skills 資料夾 |

安裝後直接跟 AI 說「幫我用這首歌和這些照片做回憶 MV」即可，第一次會自動把程式安裝到 `~/MVStudio`（Windows：`C:\MVStudio`）。`app/prompts/` 內有三段可直接複製貼上的提示詞（A 安裝、B 製作、C 接續）。

### 電腦需求
- Python 3.10 以上、FFmpeg
- 約 3 GB 磁碟空間（Whisper 語音模型與 PyTorch）、建議 8 GB 以上記憶體
- 中文字型：安裝時會自動下載 Noto Sans TC（繁體中文，開源授權）；下載失敗時改用 macOS 蘋方／Windows 微軟正黑體。**不要**把字幕字型設成日文字型（如「ヒラギノ丸ゴ」），它沒有「啟」等繁體字

## 不透過 AI，自己操作

```bash
cp -R app ~/MVStudio && cd ~/MVStudio
./setup.sh               # Windows：powershell -ExecutionPolicy Bypass -File setup.ps1
./setup.sh serve         # 開啟網頁介面 http://localhost:8787
./setup.sh serve --lan   # 活動現場：讓同 Wi-Fi 的手機上傳照片
```

指令列用法：`./venv/bin/python mvctl.py --help`（Windows：`venv\Scripts\python.exe mvctl.py --help`）。

### 雲端收照片（選用）

若活動使用雲端收照片服務，主辦者會給你「同步網址」與「同步金鑰」：

```bash
mvctl new --name "家庭日"                                    # 照片資料夾用預設即可
mvctl link <ID> --event "https://<主機>/api/sync/ev_xxxxxxxxxxxx" --key "<同步金鑰>"
mvctl sync <ID>                  # 下載新照片；活動中可加 --watch（每 300 秒，--interval 調整）
mvctl push-requirements <ID>     # plan 之後把各主題需要張數回寫雲端（有連結時 plan 會自動做）
```

照片會下載到專案照片資料夾，已下載的自動略過；主辦者在雲端排除的照片會移到照片資料夾的 `_excluded/`。同步金鑰存在專案的 `project.json`，請勿分享該檔案。

## Windows 注意事項

- 安裝：雙擊 `app\setup.bat`（或 PowerShell 執行 `powershell -NoProfile -ExecutionPolicy Bypass -File setup.ps1`），啟動網頁介面：`setup.bat serve`。
- **執行原則**：直接執行 `.\setup.ps1` 若出現「因為這個系統上已停用指令碼執行」，改用 `setup.bat`，或 `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`。
- **防火牆**：第一次 `serve --lan` 時 Windows 會跳出視窗詢問是否允許 Python 連線，請按「允許存取」（勾選私人網路），手機才連得上上傳頁。
- **OneDrive**：不要把 MV Studio 裝在 OneDrive（含「桌面」「文件」被 OneDrive 接管時）；照片與 venv 會被持續同步，速度慢且可能鎖檔。建議 `C:\MVStudio`，`mvctl doctor` 會偵測並警告。
- **Big5 終端機**：舊版 cmd／PowerShell 預設 cp950，中文可能亂碼。用 `setup.bat`／`setup.ps1` 啟動會自動設定 UTF-8；手動執行可先 `chcp 65001`，PowerShell 再加 `$env:PYTHONUTF8=1`。
- 網頁「選擇資料夾」會開啟 Windows 檔案總管選取視窗（需要 Python 內建的 tkinter；沒有時自動改用網頁內建的檔案瀏覽器）。
- 活動手冊：`.docx` 與 `.txt` 直接讀取；`.pdf` 需 `pypdf`（已列在 requirements.txt）；`.doc`／`.rtf`／`.odt` 請先另存成 `.docx`。

## 環境變數（皆為選用）

| 變數 | 用途 |
|---|---|
| `MV_HOME` | 安裝與專案資料位置（預設 `~/MVStudio`；Windows `C:\MVStudio`） |
| `MV_FONT` | 指定字幕字型檔 |
| `MV_FINAL_ENCODER` | `cpu`／`videotoolbox`／`nvenc` |
| `MV_RENDER_WORKERS` | 平行渲染數 |
| `MV_MAX_UPLOAD_MB` | 手機上傳單張上限（預設 60） |
| `GEMINI_API_KEY`、`MV_GEMINI_MODEL` | 網頁版 Gemini 自動分析 |

## 檔案結構

```
memory-mv-studio/
├── SKILL.md                     # AI 執行流程
├── README.md                    # 本文件
├── references/
│   ├── workflow.md              # 六階段完整規格
│   ├── photo_analysis_protocol.md
│   ├── troubleshooting.md
│   └── review-2026-10.md        # 流程 Review 與優化建議
└── app/                         # MV Studio 程式（安裝時複製到 MV_HOME）
    ├── mvctl.py                 # 單一指令入口
    ├── setup.sh / setup.ps1 / setup.bat   # setup.bat 供 Windows 雙擊
    ├── prompts/                 # A-安裝／B-製作／C-接續 提示詞範本
    ├── align_lyrics_dp.py       # 歌詞強制對齊
    ├── analyze_batch_photos.py  # 照片掃描與分析結果匯入
    ├── fix_srt_with_dict.py
    └── mv_studio/               # 網頁伺服器與核心函式庫
```

## 隱私

照片、歌詞與專案資料都只存在本機 `MV_HOME`（使用雲端收照片時，照片會先暫存在主辦者的雲端空間，下載後以活動設定的保存天數自動刪除）。只有在網頁介面主動使用「Gemini 自動分析」時，縮圖才會送到 Google API。分享專案資料夾前請確認 `project.json` 內沒有 API Key。
